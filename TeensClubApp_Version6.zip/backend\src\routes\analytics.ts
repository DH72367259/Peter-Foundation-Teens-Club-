﻿import { Router } from 'express';
import db from '../database/db';
import { authenticate, requireAdmin } from '../middleware/auth';

const router = Router();
router.use(authenticate);
router.use(requireAdmin); // Analytics: ADMIN only

// GET /api/analytics/hobbies
router.get('/hobbies', (_req, res) => {
  const data = db.prepare(`
    SELECT h.name, COUNT(kh.kid_id) as count
    FROM hobbies h
    LEFT JOIN kid_hobbies kh ON kh.hobby_id = h.hobby_id
    LEFT JOIN kids k ON k.kid_id = kh.kid_id AND k.is_deleted = 0
    GROUP BY h.hobby_id ORDER BY count DESC
  `).all();
  res.json(data);
});

// GET /api/analytics/interests
router.get('/interests', (_req, res) => {
  const data = db.prepare(`
    SELECT i.name, COUNT(ki.kid_id) as count
    FROM interests i
    LEFT JOIN kid_interests ki ON ki.interest_id = i.interest_id
    LEFT JOIN kids k ON k.kid_id = ki.kid_id AND k.is_deleted = 0
    GROUP BY i.interest_id ORDER BY count DESC
  `).all();
  res.json(data);
});

// GET /api/analytics/age-groups
router.get('/age-groups', (_req, res) => {
  const data = db.prepare(`
    SELECT
      CASE
        WHEN age_snapshot BETWEEN 10 AND 12 THEN '10–12 yrs'
        WHEN age_snapshot BETWEEN 13 AND 15 THEN '13–15 yrs'
        WHEN age_snapshot BETWEEN 16 AND 18 THEN '16–18 yrs'
        WHEN age_snapshot < 10             THEN 'Under 10'
        ELSE '19–21'
      END as group_name,
      COUNT(*) as count
    FROM kids WHERE is_deleted = 0
    GROUP BY group_name ORDER BY group_name
  `).all();
  res.json(data);
});

// GET /api/analytics/education-levels
router.get('/education-levels', (_req, res) => {
  const data = db.prepare(`
    SELECT COALESCE(education_level, 'Not Specified') as level, COUNT(*) as count
    FROM kids WHERE is_deleted = 0
    GROUP BY education_level ORDER BY count DESC
  `).all();
  res.json(data);
});

// GET /api/analytics/registrations-per-month
router.get('/registrations-per-month', (_req, res) => {
  const data = db.prepare(`
    SELECT strftime('%Y-%m', created_at) as month, COUNT(*) as count
    FROM kids WHERE is_deleted = 0
    GROUP BY month ORDER BY month ASC LIMIT 24
  `).all();
  res.json(data);
});

// GET /api/analytics/gender
router.get('/gender', (_req, res) => {
  const data = db.prepare(`
    SELECT COALESCE(gender, 'Not Specified') as gender, COUNT(*) as count
    FROM kids WHERE is_deleted = 0 GROUP BY gender
  `).all();
  res.json(data);
});

// GET /api/analytics/summary
router.get('/summary', (_req, res) => {
  const totalKids = (db.prepare("SELECT COUNT(*) as c FROM kids WHERE is_deleted=0").get() as any).c;
  const totalParents = (db.prepare("SELECT COUNT(*) as c FROM parents").get() as any).c;
  const thisMonth = (db.prepare(`
    SELECT COUNT(*) as c FROM kids WHERE is_deleted=0
    AND strftime('%Y-%m', created_at) = strftime('%Y-%m', 'now')
  `).get() as any).c;
  const baptised = (db.prepare("SELECT COUNT(*) as c FROM kids WHERE is_deleted=0 AND baptism_confirmed=1").get() as any).c;
  res.json({ totalKids, totalParents, thisMonth, baptised });
});

export default router;

