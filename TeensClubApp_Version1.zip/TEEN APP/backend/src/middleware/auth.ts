import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import db from '../database/db';

const JWT_SECRET = process.env.JWT_SECRET || 'TeensClub_Church_SecretKey_2026!';

export interface AuthUser {
  user_id: string;
  username: string;
  role: 'ADMIN' | 'DATA_ENTRY' | 'MENTOR' | 'SUB' | 'SPIRITUAL_LEADER';
  full_name: string;
}

export interface AuthRequest extends Request {
  user?: AuthUser;
}

export function authenticate(req: AuthRequest, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'No token provided' });
    return;
  }
  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as AuthUser;
    const dbUser = db.prepare(
      'SELECT user_id, username, full_name, role, is_active FROM users WHERE user_id = ?'
    ).get(decoded.user_id) as any;
    if (!dbUser || !dbUser.is_active) {
      res.status(401).json({ error: 'User not found or inactive' });
      return;
    }
    req.user = {
      user_id: dbUser.user_id,
      username: dbUser.username,
      full_name: dbUser.full_name,
      role: dbUser.role,
    };
    next();
  } catch {
    res.status(401).json({ error: 'Invalid or expired token' });
  }
}

export function requireAdmin(req: AuthRequest, res: Response, next: NextFunction): void {
  if (!req.user || req.user.role !== 'ADMIN') {
    res.status(403).json({ error: 'Admin access required' });
    return;
  }
  next();
}

export function requireAdminOrDataEntry(req: AuthRequest, res: Response, next: NextFunction): void {
  if (!req.user || (req.user.role !== 'ADMIN' && req.user.role !== 'DATA_ENTRY' && req.user.role !== 'SUB')) {
    res.status(403).json({ error: 'Data entry access required' });
    return;
  }
  next();
}

export function requireMentor(req: AuthRequest, res: Response, next: NextFunction): void {
  if (!req.user || req.user.role !== 'MENTOR') {
    res.status(403).json({ error: 'Mentor access required' });
    return;
  }
  next();
}

export function generateToken(user: AuthUser): string {
  return jwt.sign(user, JWT_SECRET, { expiresIn: '12h' });
}
