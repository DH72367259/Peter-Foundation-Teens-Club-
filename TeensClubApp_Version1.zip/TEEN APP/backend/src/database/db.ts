import Database, { Database as DatabaseType } from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';

const DB_DIR = process.env.DB_DIR || path.join(process.cwd(), 'data');
const DB_PATH = path.join(DB_DIR, 'teensclub.db');

if (!fs.existsSync(DB_DIR)) {
  fs.mkdirSync(DB_DIR, { recursive: true });
}

const db: DatabaseType = new Database(DB_PATH);

// Enable WAL mode for better concurrent reads
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

export function initializeDatabase(): void {
  db.exec(`
    -- ============================================================
    -- USERS (admin + sub users)
    -- ============================================================
    CREATE TABLE IF NOT EXISTS users (
      user_id     TEXT PRIMARY KEY,
      username    TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      full_name   TEXT NOT NULL,
      role        TEXT NOT NULL CHECK(role IN ('ADMIN','SUB','DATA_ENTRY','MENTOR','SPIRITUAL_LEADER')),
      is_active   INTEGER NOT NULL DEFAULT 1,
      created_at  TEXT NOT NULL DEFAULT (datetime('now')),
      created_by  TEXT
    );

    -- ============================================================
    -- KIDS (main teen registration)
    -- ============================================================
    CREATE TABLE IF NOT EXISTS kids (
      kid_id              TEXT PRIMARY KEY,
      registration_id     TEXT UNIQUE NOT NULL,
      first_name          TEXT NOT NULL,
      last_name           TEXT NOT NULL,
      dob                 TEXT NOT NULL,
      age_snapshot        INTEGER,
      gender              TEXT,
      education_level     TEXT,
      school_name         TEXT,
      grade_year          TEXT,
      phone_normalized    TEXT,
      address             TEXT CHECK(length(address) <= 250),
      ambition_goal       TEXT CHECK(length(ambition_goal) <= 250),
      additional_comments TEXT CHECK(length(additional_comments) <= 250),
      baptism_confirmed   INTEGER NOT NULL DEFAULT 0,
      consent_participate INTEGER NOT NULL DEFAULT 0,
      submission_status   TEXT NOT NULL DEFAULT 'DRAFT' CHECK(submission_status IN ('DRAFT','PENDING','APPROVED','DENIED')),
      submission_note     TEXT,
      submitted_at        TEXT,
      submitted_by        TEXT,
      is_signed           INTEGER NOT NULL DEFAULT 0,
      signed_at           TEXT,
      signed_by           TEXT,
      is_deleted          INTEGER NOT NULL DEFAULT 0,
      created_at          TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at          TEXT NOT NULL DEFAULT (datetime('now')),
      created_by_user_id  TEXT,
      FOREIGN KEY (created_by_user_id) REFERENCES users(user_id)
    );

    CREATE INDEX IF NOT EXISTS idx_kids_reg_id    ON kids(registration_id);
    CREATE INDEX IF NOT EXISTS idx_kids_phone     ON kids(phone_normalized);
    CREATE INDEX IF NOT EXISTS idx_kids_name      ON kids(first_name, last_name);
    CREATE INDEX IF NOT EXISTS idx_kids_deleted   ON kids(is_deleted);

    -- ============================================================
    -- PARENTS / GUARDIANS
    -- ============================================================
    CREATE TABLE IF NOT EXISTS parents (
      parent_id               TEXT PRIMARY KEY,
      full_name               TEXT NOT NULL,
      relationship            TEXT NOT NULL CHECK(relationship IN ('Father','Mother','Guardian','Stepfather','Stepmother')),
      phone_normalized        TEXT,
      email                   TEXT,
      occupation              TEXT,
      education               TEXT,
      expectation_text        TEXT CHECK(length(expectation_text) <= 250),
      emergency_contact_name  TEXT,
      emergency_contact_phone TEXT,
      preferred_contact       TEXT,
      baptism_confirmed       INTEGER NOT NULL DEFAULT 0,
      created_at              TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_parents_phone ON parents(phone_normalized);

    -- ============================================================
    -- KID <-> PARENT LINK (up to 2 parents per kid)
    -- ============================================================
    CREATE TABLE IF NOT EXISTS kid_parent (
      kid_id    TEXT NOT NULL,
      parent_id TEXT NOT NULL,
      PRIMARY KEY (kid_id, parent_id),
      FOREIGN KEY (kid_id)    REFERENCES kids(kid_id)    ON DELETE CASCADE,
      FOREIGN KEY (parent_id) REFERENCES parents(parent_id) ON DELETE CASCADE
    );

    -- ============================================================
    -- HOBBIES reference table
    -- ============================================================
    CREATE TABLE IF NOT EXISTS hobbies (
      hobby_id   INTEGER PRIMARY KEY AUTOINCREMENT,
      name       TEXT UNIQUE NOT NULL
    );

    -- KID <-> HOBBY (many-to-many)
    CREATE TABLE IF NOT EXISTS kid_hobbies (
      kid_id   TEXT NOT NULL,
      hobby_id INTEGER NOT NULL,
      PRIMARY KEY (kid_id, hobby_id),
      FOREIGN KEY (kid_id)   REFERENCES kids(kid_id)   ON DELETE CASCADE,
      FOREIGN KEY (hobby_id) REFERENCES hobbies(hobby_id)
    );

    -- ============================================================
    -- INTERESTS reference table
    -- ============================================================
    CREATE TABLE IF NOT EXISTS interests (
      interest_id INTEGER PRIMARY KEY AUTOINCREMENT,
      name        TEXT UNIQUE NOT NULL
    );

    -- KID <-> INTEREST (many-to-many)
    CREATE TABLE IF NOT EXISTS kid_interests (
      kid_id      TEXT NOT NULL,
      interest_id INTEGER NOT NULL,
      PRIMARY KEY (kid_id, interest_id),
      FOREIGN KEY (kid_id)      REFERENCES kids(kid_id)   ON DELETE CASCADE,
      FOREIGN KEY (interest_id) REFERENCES interests(interest_id)
    );

    -- ============================================================
    -- KID <-> MENTOR assignments
    -- ============================================================
    CREATE TABLE IF NOT EXISTS kid_mentor (
      kid_id      TEXT NOT NULL,
      mentor_id   TEXT NOT NULL,
      assigned_at TEXT NOT NULL DEFAULT (datetime('now')),
      assigned_by TEXT,
      PRIMARY KEY (kid_id, mentor_id),
      FOREIGN KEY (kid_id)    REFERENCES kids(kid_id)    ON DELETE CASCADE,
      FOREIGN KEY (mentor_id) REFERENCES users(user_id)  ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_kid_mentor_mentor ON kid_mentor(mentor_id);

    -- ============================================================
    -- MENTOR SESSION NOTES (per mentor, per kid, per date)
    -- ============================================================
    CREATE TABLE IF NOT EXISTS mentor_notes (
      note_id      TEXT PRIMARY KEY,
      kid_id       TEXT NOT NULL,
      mentor_id    TEXT NOT NULL,
      session_date TEXT NOT NULL,
      discussion   TEXT CHECK(length(discussion)  <= 1000),
      outcome      TEXT CHECK(length(outcome)     <= 500),
      next_steps   TEXT CHECK(length(next_steps)  <= 500),
is_signed        INTEGER NOT NULL DEFAULT 0,
      signed_at        TEXT,
      signed_by        TEXT,
      is_inherited     INTEGER NOT NULL DEFAULT 0,
      original_mentor_id TEXT,
      created_at       TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (kid_id)    REFERENCES kids(kid_id)   ON DELETE CASCADE,
      FOREIGN KEY (mentor_id) REFERENCES users(user_id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_mentor_notes_kid    ON mentor_notes(kid_id);
    CREATE INDEX IF NOT EXISTS idx_mentor_notes_mentor ON mentor_notes(mentor_id);

    -- ============================================================
    -- SPIRITUAL SESSIONS (group classes & 1:1 sessions)
    -- ============================================================
    CREATE TABLE IF NOT EXISTS spiritual_sessions (
      session_id          TEXT PRIMARY KEY,
      session_date        TEXT NOT NULL,
      topic               TEXT NOT NULL,
      session_type        TEXT NOT NULL DEFAULT 'GROUP' CHECK(session_type IN ('GROUP','ONE_ON_ONE_KID','ONE_ON_ONE_MENTOR','SMALL_GROUP','ALL_MENTORS')),
      target_id           TEXT,
      group_note          TEXT,
      is_signed           INTEGER NOT NULL DEFAULT 0,
      signed_at           TEXT,
      signed_by           TEXT,
      addon_text          TEXT,
      addon_is_signed     INTEGER NOT NULL DEFAULT 0,
      addon_signed_at     TEXT,
      addon_signed_by     TEXT,
      one_on_one_attended INTEGER NOT NULL DEFAULT 0,
      created_by          TEXT NOT NULL,
      created_at          TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at          TEXT NOT NULL DEFAULT (datetime('now')),
      is_cancelled        INTEGER NOT NULL DEFAULT 0,
      cancelled_at        TEXT,
      cancelled_by        TEXT,
      cancelled_reason    TEXT,
      proposed_new_date   TEXT,
      proposed_new_topic  TEXT,
      FOREIGN KEY (created_by) REFERENCES users(user_id)
    );

    CREATE INDEX IF NOT EXISTS idx_spiritual_sessions_date ON spiritual_sessions(session_date);

    -- ============================================================
    -- SPIRITUAL ATTENDANCE (per session, per kid)
    -- ============================================================
    CREATE TABLE IF NOT EXISTS spiritual_attendance (
      session_id  TEXT NOT NULL,
      kid_id      TEXT NOT NULL,
      is_present  INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (session_id, kid_id),
      FOREIGN KEY (session_id) REFERENCES spiritual_sessions(session_id) ON DELETE CASCADE,
      FOREIGN KEY (kid_id)     REFERENCES kids(kid_id)                   ON DELETE CASCADE
    );

    -- ============================================================
    -- SPIRITUAL MENTOR ATTENDANCE (per group session, per mentor)
    -- ============================================================
    CREATE TABLE IF NOT EXISTS spiritual_mentor_attendance (
      session_id TEXT NOT NULL,
      mentor_id  TEXT NOT NULL,
      is_present INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (session_id, mentor_id),
      FOREIGN KEY (session_id) REFERENCES spiritual_sessions(session_id) ON DELETE CASCADE,
      FOREIGN KEY (mentor_id)  REFERENCES users(user_id) ON DELETE CASCADE
    );

    -- ============================================================
    -- SPIRITUAL INDIVIDUAL KID NOTES
    -- ============================================================
    CREATE TABLE IF NOT EXISTS spiritual_kid_notes (
      note_id      TEXT PRIMARY KEY,
      session_id   TEXT NOT NULL,
      kid_id       TEXT NOT NULL,
      content      TEXT NOT NULL,
      improvement  TEXT,
      suggestions  TEXT,
      created_by   TEXT NOT NULL,
      created_at   TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (session_id) REFERENCES spiritual_sessions(session_id) ON DELETE CASCADE,
      FOREIGN KEY (kid_id)     REFERENCES kids(kid_id)                   ON DELETE CASCADE,
      FOREIGN KEY (created_by) REFERENCES users(user_id)
    );

    CREATE INDEX IF NOT EXISTS idx_spiritual_kid_notes_kid     ON spiritual_kid_notes(kid_id);
    CREATE INDEX IF NOT EXISTS idx_spiritual_kid_notes_session ON spiritual_kid_notes(session_id);
  `);

  // Seed default admin user if none exists
  const adminExists = db.prepare("SELECT 1 FROM users WHERE role='ADMIN' LIMIT 1").get();
  if (!adminExists) {
    const hash = bcrypt.hashSync('Admin@1234', 10);
    db.prepare(`
      INSERT INTO users (user_id, username, password_hash, full_name, role)
      VALUES (?, 'admin', ?, 'Church Admin', 'ADMIN')
    `).run(uuidv4(), hash);
    console.log('[DB] Default admin created: username=admin  password=Admin@1234');
  }

  // Seed hobbies
  const hobbies = [
    'Cricket','Football','Basketball','Swimming','Badminton',
    'Chess','Carrom','Volleyball','Table Tennis','Athletics',
    'Drawing & Painting','Music (Singing)','Music (Instruments)',
    'Dance','Drama / Theatre','Reading','Writing / Poetry',
    'Cooking / Baking','Gardening','Photography','Cycling',
    'Martial Arts','Video Games','Coding / Technology','Volunteering'
  ];
  const insertHobby = db.prepare("INSERT OR IGNORE INTO hobbies (name) VALUES (?)");
  hobbies.forEach(h => insertHobby.run(h));

  // Seed interests
  const interests = [
    'Science & Technology','Arts & Crafts','Music','Sports',
    'Environment & Nature','Social Service / Volunteering',
    'Spirituality & Faith','Literature & Books','Business & Entrepreneurship',
    'Health & Fitness','Cooking & Culinary Arts','Fashion & Design',
    'Travel & Adventure','Mathematics','Languages','History & Culture'
  ];
  const insertInterest = db.prepare("INSERT OR IGNORE INTO interests (name) VALUES (?)");
  interests.forEach(i => insertInterest.run(i));

  // ─── Migration: expand role CHECK constraint to include SPIRITUAL_LEADER ───
  const usersSql = (db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='users'").get() as any)?.sql || '';
  if (!usersSql.includes('SPIRITUAL_LEADER')) {
    console.log('[DB] Migrating users table to add SPIRITUAL_LEADER role...');
    db.exec(`
      PRAGMA foreign_keys = OFF;
      CREATE TABLE users_backup AS SELECT * FROM users;
      DROP TABLE users;
      CREATE TABLE users (
        user_id       TEXT PRIMARY KEY,
        username      TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        full_name     TEXT NOT NULL,
        role          TEXT NOT NULL CHECK(role IN ('ADMIN','SUB','DATA_ENTRY','MENTOR','SPIRITUAL_LEADER')),
        is_active     INTEGER NOT NULL DEFAULT 1,
        created_at    TEXT NOT NULL DEFAULT (datetime('now')),
        created_by    TEXT
      );
      INSERT INTO users SELECT * FROM users_backup;
      DROP TABLE users_backup;
      PRAGMA foreign_keys = ON;
    `);
    console.log('[DB] Migration complete.');
  }

  // ─── Migration: add sign columns + addon + 1:1-attendance to spiritual_sessions ───
  const spiritCols = (db.prepare("PRAGMA table_info(spiritual_sessions)").all() as any[]).map((c: any) => c.name);
  if (!spiritCols.includes('is_signed')) {
    const newCols = [
      "ALTER TABLE spiritual_sessions ADD COLUMN is_signed           INTEGER NOT NULL DEFAULT 0",
      "ALTER TABLE spiritual_sessions ADD COLUMN signed_at           TEXT",
      "ALTER TABLE spiritual_sessions ADD COLUMN signed_by           TEXT",
      "ALTER TABLE spiritual_sessions ADD COLUMN addon_text          TEXT",
      "ALTER TABLE spiritual_sessions ADD COLUMN addon_is_signed     INTEGER NOT NULL DEFAULT 0",
      "ALTER TABLE spiritual_sessions ADD COLUMN addon_signed_at     TEXT",
      "ALTER TABLE spiritual_sessions ADD COLUMN addon_signed_by     TEXT",
      "ALTER TABLE spiritual_sessions ADD COLUMN one_on_one_attended INTEGER NOT NULL DEFAULT 0",
    ];
    newCols.forEach(sql => db.exec(sql));
    console.log('[DB] Migrated spiritual_sessions: added sign/addon/1:1-attendance columns.');
  }

  // ─── Migration: add sign columns to kids table ───────────────────────────
  const kidCols = (db.prepare("PRAGMA table_info(kids)").all() as any[]).map((c: any) => c.name);
  if (!kidCols.includes('is_signed')) {
    db.exec("ALTER TABLE kids ADD COLUMN is_signed  INTEGER NOT NULL DEFAULT 0");
    db.exec("ALTER TABLE kids ADD COLUMN signed_at  TEXT");
    db.exec("ALTER TABLE kids ADD COLUMN signed_by  TEXT");
    console.log('[DB] Migrated kids: added sign columns.');
  }

  // ─── Migration: add sign columns to mentor_notes table ──────────────────
  const noteCols = (db.prepare("PRAGMA table_info(mentor_notes)").all() as any[]).map((c: any) => c.name);
  if (!noteCols.includes('is_signed')) {
    db.exec("ALTER TABLE mentor_notes ADD COLUMN is_signed  INTEGER NOT NULL DEFAULT 0");
    db.exec("ALTER TABLE mentor_notes ADD COLUMN signed_at  TEXT");
    db.exec("ALTER TABLE mentor_notes ADD COLUMN signed_by  TEXT");
    console.log('[DB] Migrated mentor_notes: added sign columns.');
  }

  // ─── Migration: add baptism_confirmed to parents table ──────────────────
  const parentCols = (db.prepare("PRAGMA table_info(parents)").all() as any[]).map((c: any) => c.name);
  if (!parentCols.includes('baptism_confirmed')) {
    db.exec("ALTER TABLE parents ADD COLUMN baptism_confirmed INTEGER NOT NULL DEFAULT 0");
    console.log('[DB] Migrated parents: added baptism_confirmed column.');
  }

  // ─── Migration: create spiritual_mentor_attendance table ────────────────
  db.exec(`
    CREATE TABLE IF NOT EXISTS spiritual_mentor_attendance (
      session_id TEXT NOT NULL,
      mentor_id  TEXT NOT NULL,
      is_present INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (session_id, mentor_id),
      FOREIGN KEY (session_id) REFERENCES spiritual_sessions(session_id) ON DELETE CASCADE,
      FOREIGN KEY (mentor_id)  REFERENCES users(user_id) ON DELETE CASCADE
    );
  `);

  // ─── Migration: create edit_requests table ──────────────────────────────
  db.exec(`
    CREATE TABLE IF NOT EXISTS edit_requests (
      request_id    TEXT PRIMARY KEY,
      entity_type   TEXT NOT NULL CHECK(entity_type IN ('KID','MENTOR_NOTE','SPIRITUAL_SESSION')),
      entity_id     TEXT NOT NULL,
      entity_label  TEXT,
      requested_by  TEXT NOT NULL,
      requested_at  TEXT NOT NULL DEFAULT (datetime('now')),
      reason        TEXT NOT NULL,
      status        TEXT NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','APPROVED','DENIED')),
      reviewed_by   TEXT,
      reviewed_at   TEXT,
      review_note   TEXT,
      FOREIGN KEY (requested_by) REFERENCES users(user_id)
    );
    CREATE INDEX IF NOT EXISTS idx_edit_requests_status ON edit_requests(status);
    CREATE INDEX IF NOT EXISTS idx_edit_requests_entity ON edit_requests(entity_type, entity_id);
  `);
  console.log('[DB] edit_requests table ready.');

  // ─── Migration: add submission workflow columns to kids ──────────────────
  const kidCols2 = (db.prepare("PRAGMA table_info(kids)").all() as any[]).map((c: any) => c.name);
  if (!kidCols2.includes('submission_status')) {
    db.exec("ALTER TABLE kids ADD COLUMN submission_status TEXT NOT NULL DEFAULT 'DRAFT'");
    db.exec("ALTER TABLE kids ADD COLUMN submission_note  TEXT");
    db.exec("ALTER TABLE kids ADD COLUMN submitted_at     TEXT");
    db.exec("ALTER TABLE kids ADD COLUMN submitted_by     TEXT");
    // Treat all existing records as already approved
    db.exec("UPDATE kids SET submission_status='APPROVED' WHERE is_deleted=0");
    console.log('[DB] Migrated kids: added submission_status columns (existing records set to APPROVED).');
  }

  // ─── Migration: add is_inherited to mentor_notes ─────────────────────────
  const noteCols2 = (db.prepare("PRAGMA table_info(mentor_notes)").all() as any[]).map((c: any) => c.name);
  if (!noteCols2.includes('is_inherited')) {
    db.exec("ALTER TABLE mentor_notes ADD COLUMN is_inherited     INTEGER NOT NULL DEFAULT 0");
    db.exec("ALTER TABLE mentor_notes ADD COLUMN original_mentor_id TEXT");
    console.log('[DB] Migrated mentor_notes: added is_inherited column.');
  }

  // ─── Migration: add mentor_edit_user_id to kids ─────────────────────────
  const kidCols3 = (db.prepare("PRAGMA table_info(kids)").all() as any[]).map((c: any) => c.name);
  if (!kidCols3.includes('mentor_edit_user_id')) {
    db.exec("ALTER TABLE kids ADD COLUMN mentor_edit_user_id TEXT");
    console.log('[DB] Migrated kids: added mentor_edit_user_id column.');
  }

  // ─── Migration: notifications table ─────────────────────────────────────
  db.exec(`
    CREATE TABLE IF NOT EXISTS notifications (
      notification_id TEXT PRIMARY KEY,
      user_id         TEXT NOT NULL,
      type            TEXT NOT NULL,
      message         TEXT NOT NULL,
      entity_id       TEXT,
      entity_label    TEXT,
      is_read         INTEGER NOT NULL DEFAULT 0,
      created_at      TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(user_id)
    );
    CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read);
  `);

  // ─── Migration: session_requests table ─────────────────────────────────────
  db.exec(`
    CREATE TABLE IF NOT EXISTS session_requests (
      request_id        TEXT PRIMARY KEY,
      requested_by      TEXT NOT NULL,
      request_type      TEXT NOT NULL CHECK(request_type IN ('ONE_ON_ONE_SL','ONE_ON_ONE_KID')),
      kid_ids           TEXT,
      message           TEXT NOT NULL,
      status            TEXT NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','APPROVED','DENIED')),
      reviewed_by       TEXT,
      reviewed_at       TEXT,
      review_note       TEXT,
      approved_session_id TEXT,
      created_at        TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at        TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (requested_by) REFERENCES users(user_id)
    );
    CREATE INDEX IF NOT EXISTS idx_session_requests_status ON session_requests(status);
    CREATE INDEX IF NOT EXISTS idx_session_requests_requester ON session_requests(requested_by);
  `);

  // ─── Migration: session_reminder_log table (prevents duplicate reminders) ────
  db.exec(`
    CREATE TABLE IF NOT EXISTS session_reminder_log (
      session_id    TEXT NOT NULL,
      reminder_type TEXT NOT NULL CHECK(reminder_type IN ('1WEEK','1DAY')),
      sent_at       TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (session_id, reminder_type)
    );
  `);

  // ─── Migration: add cancel + propose columns to spiritual_sessions ────────
  const spiritColsCancel = (db.prepare("PRAGMA table_info(spiritual_sessions)").all() as any[]).map((c: any) => c.name);
  if (!spiritColsCancel.includes('is_cancelled')) {
    db.exec("ALTER TABLE spiritual_sessions ADD COLUMN is_cancelled     INTEGER NOT NULL DEFAULT 0");
    db.exec("ALTER TABLE spiritual_sessions ADD COLUMN cancelled_at     TEXT");
    db.exec("ALTER TABLE spiritual_sessions ADD COLUMN cancelled_by     TEXT");
    db.exec("ALTER TABLE spiritual_sessions ADD COLUMN cancelled_reason TEXT");
    db.exec("ALTER TABLE spiritual_sessions ADD COLUMN proposed_new_date  TEXT");
    db.exec("ALTER TABLE spiritual_sessions ADD COLUMN proposed_new_topic TEXT");
    console.log('[DB] Migrated spiritual_sessions: added cancel + propose columns.');
  }

  // ─── Migration: add SMALL_GROUP + ALL_MENTORS to spiritual_sessions ─────────
  const spiritTypesSql = (db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='spiritual_sessions'").get() as any)?.sql || '';
  if (!spiritTypesSql.includes('SMALL_GROUP')) {
    console.log('[DB] Migrating spiritual_sessions: adding SMALL_GROUP and ALL_MENTORS types...');
    db.exec(`
      PRAGMA foreign_keys = OFF;
      CREATE TABLE spiritual_sessions_bak3 AS SELECT * FROM spiritual_sessions;
      DROP TABLE spiritual_sessions;
      CREATE TABLE spiritual_sessions (
        session_id          TEXT PRIMARY KEY,
        session_date        TEXT NOT NULL,
        topic               TEXT NOT NULL,
        session_type        TEXT NOT NULL DEFAULT 'GROUP' CHECK(session_type IN ('GROUP','ONE_ON_ONE_KID','ONE_ON_ONE_MENTOR','SMALL_GROUP','ALL_MENTORS')),
        target_id           TEXT,
        group_note          TEXT,
        is_signed           INTEGER NOT NULL DEFAULT 0,
        signed_at           TEXT,
        signed_by           TEXT,
        addon_text          TEXT,
        addon_is_signed     INTEGER NOT NULL DEFAULT 0,
        addon_signed_at     TEXT,
        addon_signed_by     TEXT,
        one_on_one_attended INTEGER NOT NULL DEFAULT 0,
        created_by          TEXT NOT NULL,
        created_at          TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at          TEXT NOT NULL DEFAULT (datetime('now')),
        is_cancelled        INTEGER NOT NULL DEFAULT 0,
        cancelled_at        TEXT,
        cancelled_by        TEXT,
        cancelled_reason    TEXT,
        proposed_new_date   TEXT,
        proposed_new_topic  TEXT,
        FOREIGN KEY (created_by) REFERENCES users(user_id)
      );
      INSERT INTO spiritual_sessions SELECT
        session_id, session_date, topic, session_type, target_id, group_note,
        is_signed, signed_at, signed_by, addon_text, addon_is_signed,
        addon_signed_at, addon_signed_by, one_on_one_attended,
        created_by, created_at, updated_at,
        COALESCE(is_cancelled, 0), cancelled_at, cancelled_by,
        cancelled_reason, proposed_new_date, proposed_new_topic
      FROM spiritual_sessions_bak3;
      DROP TABLE spiritual_sessions_bak3;
      PRAGMA foreign_keys = ON;
    `);
    db.exec('CREATE INDEX IF NOT EXISTS idx_spiritual_sessions_date ON spiritual_sessions(session_date);');
    console.log('[DB] Migration complete: SMALL_GROUP and ALL_MENTORS types added.');
  }

  // ─── Migration: add rsvp_status to spiritual_mentor_attendance ─────────────
  const mentorAttCols = (db.prepare("PRAGMA table_info(spiritual_mentor_attendance)").all() as any[]).map((c: any) => c.name);
  if (!mentorAttCols.includes('rsvp_status')) {
    db.exec("ALTER TABLE spiritual_mentor_attendance ADD COLUMN rsvp_status TEXT NOT NULL DEFAULT 'PENDING'");
    console.log('[DB] Migrated spiritual_mentor_attendance: added rsvp_status column.');
  }

  // ─── Migration: add photo_data to kids ───────────────────────────────────────
  const kidColsPhoto = (db.prepare("PRAGMA table_info(kids)").all() as any[]).map((c: any) => c.name);
  if (!kidColsPhoto.includes('photo_data')) {
    db.exec("ALTER TABLE kids ADD COLUMN photo_data TEXT");
    console.log('[DB] Migrated kids: added photo_data column.');
  }

  console.log('[DB] Database initialized:', DB_PATH);
}

export default db;
