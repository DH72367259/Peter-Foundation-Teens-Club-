import { v4 as uuidv4 } from 'uuid';
import db from '../database/db';

/**
 * Generates a human-readable registration ID like TC-2026-000123
 * Atomic counter stored in SQLite to prevent duplicates across LAN
 */
export function generateRegistrationId(): string {
  const year = new Date().getFullYear();

  // Count existing kids this year to get next sequence
  const row = db.prepare(`
    SELECT COUNT(*) as cnt FROM kids
    WHERE registration_id LIKE 'TC-${year}-%'
  `).get() as { cnt: number };

  const seq = String(row.cnt + 1).padStart(6, '0');
  return `TC-${year}-${seq}`;
}

export function newUUID(): string {
  return uuidv4();
}

export function normalizePhone(phone: string): string {
  return phone.replace(/\D/g, '');
}

export function calcAge(dob: string): number {
  const birth = new Date(dob);
  const now = new Date();
  let age = now.getFullYear() - birth.getFullYear();
  const m = now.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < birth.getDate())) age--;
  return age;
}
