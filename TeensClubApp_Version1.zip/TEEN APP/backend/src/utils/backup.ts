/**
 * backup.ts — Safe auto-backup using SQLite's Online Backup API.
 *
 * WHY NOT put the DB directly on Google Drive:
 *   SQLite uses OS-level file locking. Cloud sync tools upload the file
 *   while it is open, which breaks the lock and corrupts the database.
 *   The WAL files (.db-wal, .db-shm) also confuse sync agents.
 *
 * HOW this works instead:
 *   1. The live DB stays on the local disk (always safe).
 *   2. Every hour, db.backup() creates a safe consistent snapshot
 *      (SQLite's built-in online backup API — never blocks the server).
 *   3. That snapshot is copied into the Google Drive / OneDrive folder
 *      so Drive can sync it to the cloud automatically.
 *   4. A "teensclub-LATEST.db" file is always overwritten for easy restore.
 *   5. The last 14 timestamped backups are kept; older ones are deleted.
 *
 * Path priority:
 *   1. GDRIVE_BACKUP_PATH env variable (set in StartServer.bat)
 *   2. %USERPROFILE%\My Drive          (Google Drive for Desktop, new)
 *   3. %USERPROFILE%\Google Drive       (old Google Drive app)
 *   4. %USERPROFILE%\OneDrive           (Microsoft OneDrive)
 *   5. <app>/data/backups/              (local fallback — always works)
 */

import path from 'path';
import fs from 'fs';
import os from 'os';
import db from '../database/db';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface BackupResult {
  success: boolean;
  /** Full path the backup was written to */
  dest: string;
  /** Whether the backup landed inside a cloud-synced folder */
  cloud: boolean;
  /** "Google Drive", "OneDrive", "Custom Path", or null */
  cloudService: string | null;
  /** ISO timestamp of when the backup ran */
  timestamp: string;
  error?: string;
}

// ─── In-memory state (read by the /backup/status endpoint) ───────────────────
export let lastBackup: BackupResult | null = null;

// ─── Detect cloud folder ──────────────────────────────────────────────────────

export function findCloudDir(): { dir: string; service: string } | null {
  // 1. Explicit override via environment variable
  const envPath = process.env.GDRIVE_BACKUP_PATH;
  if (envPath) {
    try {
      if (fs.existsSync(envPath)) return { dir: envPath, service: 'Custom Path' };
    } catch { /* ignore */ }
  }

  const home = os.homedir();
  const candidates: { p: string; service: string }[] = [
    { p: path.join(home, 'My Drive'),     service: 'Google Drive' },   // Drive for Desktop (new)
    { p: path.join(home, 'Google Drive'), service: 'Google Drive' },   // Old Drive app
    { p: path.join(home, 'OneDrive'),     service: 'OneDrive'     },   // Microsoft OneDrive
  ];

  for (const { p, service } of candidates) {
    try {
      if (fs.existsSync(p)) return { dir: p, service };
    } catch { /* ignore */ }
  }
  return null;
}

// ─── Run a backup ─────────────────────────────────────────────────────────────

export async function runBackup(): Promise<BackupResult> {
  const cloud = findCloudDir();

  // Destination folder: cloud subfolder OR local backups folder
  const baseDir = cloud
    ? path.join(cloud.dir, 'TeensClub Backups')
    : path.join(process.cwd(), 'data', 'backups');

  if (!fs.existsSync(baseDir)) {
    fs.mkdirSync(baseDir, { recursive: true });
  }

  const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const timestampedFile = path.join(baseDir, `teensclub-backup-${timestamp}.db`);
  const latestFile      = path.join(baseDir, 'teensclub-LATEST.db');

  try {
    // SQLite online backup — safe even under concurrent writes
    await (db as any).backup(timestampedFile);

    // Overwrite the LATEST copy for easy one-click restore
    if (fs.existsSync(latestFile)) fs.unlinkSync(latestFile);
    await (db as any).backup(latestFile);

    pruneOldBackups(baseDir, 14);

    lastBackup = {
      success: true,
      dest: timestampedFile,
      cloud: !!cloud,
      cloudService: cloud?.service ?? null,
      timestamp: new Date().toISOString(),
    };
  } catch (err: any) {
    lastBackup = {
      success: false,
      dest: timestampedFile,
      cloud: !!cloud,
      cloudService: cloud?.service ?? null,
      timestamp: new Date().toISOString(),
      error: String(err?.message ?? err),
    };
  }

  return lastBackup;
}

// ─── Keep only the N most recent timestamped backups ─────────────────────────

function pruneOldBackups(dir: string, keep: number): void {
  try {
    const files = fs.readdirSync(dir)
      .filter(f => /^teensclub-backup-.+\.db$/.test(f))
      .map(f => ({ name: f, mtime: fs.statSync(path.join(dir, f)).mtimeMs }))
      .sort((a, b) => b.mtime - a.mtime);

    files.slice(keep).forEach(({ name }) => {
      try { fs.unlinkSync(path.join(dir, name)); } catch { /* ignore */ }
    });
  } catch { /* ignore */ }
}
