import express from 'express';
import cors from 'cors';
import path from 'path';
import os from 'os';
import { initializeDatabase } from './database/db';
import authRoutes from './routes/auth';
import kidsRoutes from './routes/kids';
import analyticsRoutes from './routes/analytics';
import mentorsRoutes from './routes/mentors';
import spiritualRoutes from './routes/spiritual';
import editRequestsRoutes from './routes/edit_requests';
import notificationsRoutes from './routes/notifications';
import recordsRoutes from './routes/records';
import { runBackup, findCloudDir } from './utils/backup';

const app = express();
const PORT = parseInt(process.env.PORT || '3001', 10);
const HOST = process.env.HOST || '0.0.0.0'; // Listen on all interfaces for LAN access

// Initialize SQLite database and seed data
initializeDatabase();

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(cors({
  origin: '*',  // Allow all origins on LAN
  credentials: true,
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// ─── API Routes ───────────────────────────────────────────────────────────────
app.use('/api/auth', authRoutes);
app.use('/api/kids', kidsRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/mentors', mentorsRoutes);
app.use('/api/spiritual', spiritualRoutes);
app.use('/api/edit-requests', editRequestsRoutes);
app.use('/api/notifications', notificationsRoutes);
app.use('/api/records', recordsRoutes);

// ─── Health check ─────────────────────────────────────────────────────────────
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ─── Serve React frontend (production build) ─────────────────────────────────
const frontendDist = path.join(__dirname, '..', '..', 'frontend', 'dist');
app.use(express.static(frontendDist));
app.get('*', (_req, res) => {
  res.sendFile(path.join(frontendDist, 'index.html'));
});

// ─── Detect LAN IP ───────────────────────────────────────────────────────────
function getNetworkIP(): string {
  const interfaces = os.networkInterfaces();

  // Virtual/irrelevant adapter names to skip
  const skipPatterns = ['vmware', 'vethernet', 'loopback', 'virtual', 'hyper-v', 'bluetooth'];

  // Priority: prefer adapters with 'wi-fi' or 'wireless' or 'wlan' in the name
  const preferPatterns = ['wi-fi', 'wifi', 'wireless', 'wlan'];

  const candidates: { name: string; address: string }[] = [];

  for (const name of Object.keys(interfaces)) {
    const nameLower = name.toLowerCase();
    const isVirtual = skipPatterns.some(p => nameLower.includes(p));
    if (isVirtual) continue;

    for (const iface of interfaces[name] ?? []) {
      if (iface.family === 'IPv4' && !iface.internal) {
        candidates.push({ name: nameLower, address: iface.address });
      }
    }
  }

  // Prefer Wi-Fi adapter
  const wifi = candidates.find(c => preferPatterns.some(p => c.name.includes(p)));
  if (wifi) return wifi.address;

  // Fallback to first remaining candidate
  if (candidates.length > 0) return candidates[0].address;

  return '<YOUR-PC-IP>';
}

// ─── Start ────────────────────────────────────────────────────────────────────
app.listen(PORT, HOST, () => {
  const networkIP = getNetworkIP();
  const cloud = findCloudDir();

  console.log(`\n✅ Teen's Club Server running!`);
  console.log(`   Local:   http://localhost:${PORT}`);
  console.log(`   Network: http://${networkIP}:${PORT}  ← Share this with other PCs on LAN`);

  if (cloud) {
    console.log(`   Backups → ${cloud.service} — ${path.join(cloud.dir, 'TeensClub Backups')}`);
  } else {
    console.log(`   Backups → local folder: ${path.join(process.cwd(), 'data', 'backups')}`);
    console.log(`   Tip: Install Google Drive or set GDRIVE_BACKUP_PATH in StartServer.bat`);
  }
  console.log('');

  // ── Auto-backup: first run 90 seconds after startup, then every hour ──────
  const doBackup = async () => {
    const r = await runBackup();
    const where = r.cloud ? r.cloudService : 'local backups';
    if (r.success) {
      console.log(`💾 Backup OK → ${where} (${new Date(r.timestamp).toLocaleTimeString()})`);
    } else {
      console.log(`⚠️  Backup failed: ${r.error}`);
    }
  };

  setTimeout(() => {
    doBackup();
    setInterval(doBackup, 60 * 60 * 1000); // repeat every hour
  }, 90 * 1000);

  // ── Session reminder notifications (runs every hour) ─────────────────────
  const sendReminders = () => {
    try {
      const db = require('./database/db').default;
      const { v4: uuidv4 } = require('uuid');

      const now       = new Date();
      const today     = now.toISOString().slice(0, 10);
      const in7days   = new Date(now.getTime() + 7  * 86400000).toISOString().slice(0, 10);
      const in1day    = new Date(now.getTime() + 1  * 86400000).toISOString().slice(0, 10);

      const loggedTypes = (session_id: string, reminder_type: string) =>
        db.prepare('SELECT 1 FROM session_reminder_log WHERE session_id=? AND reminder_type=?').get(session_id, reminder_type);

      const markLogged = (session_id: string, reminder_type: string) =>
        db.prepare("INSERT OR IGNORE INTO session_reminder_log (session_id, reminder_type) VALUES (?,?)").run(session_id, reminder_type);

      const insertNotif = db.prepare(`INSERT INTO notifications (notification_id, user_id, type, message, entity_id, entity_label) VALUES (?,?,?,?,?,?)`);

      const notifySession = (session: any, reminderType: '1WEEK' | '1DAY') => {
        if (session.is_cancelled) return;
        if (loggedTypes(session.session_id, reminderType)) return;

        const label = reminderType === '1WEEK' ? 'in 1 week' : 'tomorrow';
        const msg = `🔔 Reminder: "${session.topic}" session is ${label} (${session.session_date}).`;

        // Notify all invited mentors
        const mentors = db.prepare('SELECT mentor_id FROM spiritual_mentor_attendance WHERE session_id=?').all(session.session_id) as any[];
        db.transaction(() => {
          mentors.forEach((m: any) => {
            insertNotif.run(uuidv4(), m.mentor_id, 'SESSION_REMINDER', msg, session.session_id, session.topic);
          });
          // Notify SL who created it
          insertNotif.run(uuidv4(), session.created_by, 'SESSION_REMINDER', msg, session.session_id, session.topic);
          markLogged(session.session_id, reminderType);
        })();
      };

      // Check 7-day reminders
      const sessionsIn7 = db.prepare(`SELECT session_id, session_date, topic, created_by, is_cancelled FROM spiritual_sessions WHERE session_date = ? AND is_cancelled = 0`).all(in7days) as any[];
      sessionsIn7.forEach((s: any) => notifySession(s, '1WEEK'));

      // Check 1-day reminders
      const sessionsIn1 = db.prepare(`SELECT session_id, session_date, topic, created_by, is_cancelled FROM spiritual_sessions WHERE session_date = ? AND is_cancelled = 0`).all(in1day) as any[];
      sessionsIn1.forEach((s: any) => notifySession(s, '1DAY'));

      if (sessionsIn7.length + sessionsIn1.length > 0) {
        console.log(`🔔 Reminder check: ${sessionsIn7.length} 1-week, ${sessionsIn1.length} 1-day reminders processed.`);
      }
    } catch (e: any) {
      console.error('⚠️  Reminder check failed:', e.message);
    }
  };

  // Run reminder check 2 minutes after startup, then every hour
  setTimeout(() => {
    sendReminders();
    setInterval(sendReminders, 60 * 60 * 1000);
  }, 2 * 60 * 1000);
});
