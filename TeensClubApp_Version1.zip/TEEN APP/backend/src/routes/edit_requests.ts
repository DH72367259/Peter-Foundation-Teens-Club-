import { Router, Response } from 'express';
import db from '../database/db';
import { authenticate, requireAdmin, AuthRequest } from '../middleware/auth';
import { newUUID } from '../utils/helpers';

const router = Router();
router.use(authenticate);

// ─── POST /api/edit-requests — submit a request to unlock an entity ───────────
router.post('/', (req: AuthRequest, res: Response) => {
  const { entity_type, entity_id, entity_label, reason } = req.body;

  if (!entity_type || !entity_id || !reason?.trim()) {
    res.status(400).json({ error: 'entity_type, entity_id, and reason are required' }); return;
  }
  const validTypes = ['KID', 'MENTOR_NOTE', 'SPIRITUAL_SESSION'];
  if (!validTypes.includes(entity_type)) {
    res.status(400).json({ error: 'Invalid entity_type' }); return;
  }

  // Only one PENDING request per entity at a time
  const existing = db.prepare(
    "SELECT request_id FROM edit_requests WHERE entity_id=? AND status='PENDING'"
  ).get(entity_id);
  if (existing) {
    res.status(400).json({ error: 'A pending edit request already exists for this record' }); return;
  }

  const request_id = newUUID();
  db.prepare(`
    INSERT INTO edit_requests (request_id, entity_type, entity_id, entity_label, requested_by, reason)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(request_id, entity_type, entity_id, entity_label?.trim() || null, req.user!.user_id, reason.trim());

  res.status(201).json({ request_id, message: 'Edit request submitted' });
});

// ─── GET /api/edit-requests/pending-count — admin: count of PENDING ──────────
router.get('/pending-count', requireAdmin, (_req, res: Response) => {
  const row = db.prepare("SELECT COUNT(*) as count FROM edit_requests WHERE status='PENDING'").get() as any;
  res.json({ count: row.count });
});

// ─── GET /api/edit-requests — admin: list all (optional ?status=) ─────────────
router.get('/', requireAdmin, (req: AuthRequest, res: Response) => {
  const { status } = req.query as { status?: string };

  const validStatuses = ['PENDING', 'APPROVED', 'DENIED'];
  const whereClause = status && validStatuses.includes(status)
    ? `WHERE er.status = '${status}'`
    : '';

  const requests = db.prepare(`
    SELECT er.request_id, er.entity_type, er.entity_id, er.entity_label,
           er.reason, er.status, er.requested_at,
           er.reviewed_at, er.review_note,
           u.full_name  AS requester_name,
           u.username   AS requester_username,
           rv.full_name AS reviewer_name
    FROM edit_requests er
    JOIN  users u  ON u.user_id  = er.requested_by
    LEFT JOIN users rv ON rv.user_id = er.reviewed_by
    ${whereClause}
    ORDER BY er.requested_at DESC
  `).all();
  res.json(requests);
});

// ─── PUT /api/edit-requests/:requestId/approve — admin: approve + unlock ──────
router.put('/:requestId/approve', requireAdmin, (req: AuthRequest, res: Response) => {
  const { requestId } = req.params;
  const { review_note } = req.body;

  const request = db.prepare('SELECT * FROM edit_requests WHERE request_id=?').get(requestId) as any;
  if (!request) { res.status(404).json({ error: 'Request not found' }); return; }
  if (request.status !== 'PENDING') {
    res.status(400).json({ error: `Request is already ${request.status.toLowerCase()}` }); return;
  }

  // Unlock the entity
  const requesterRole = (db.prepare("SELECT role FROM users WHERE user_id=?").get(request.requested_by) as any)?.role;
  if (request.entity_type === 'KID') {
    if (requesterRole === 'MENTOR') {
      // Mentor edit request: unlock AND grant edit access
      db.prepare(`UPDATE kids SET is_signed=0, signed_at=NULL, signed_by=NULL, mentor_edit_user_id=? WHERE kid_id=?`).run(request.requested_by, request.entity_id);
    } else {
      db.prepare(`UPDATE kids SET is_signed=0, signed_at=NULL, signed_by=NULL WHERE kid_id=?`).run(request.entity_id);
    }
  } else if (request.entity_type === 'MENTOR_NOTE') {
    db.prepare(`
      UPDATE mentor_notes
      SET is_signed=0, signed_at=NULL, signed_by=NULL
      WHERE note_id=?
    `).run(request.entity_id);
  } else if (request.entity_type === 'SPIRITUAL_SESSION') {
    db.prepare(`
      UPDATE spiritual_sessions
      SET is_signed=0, signed_at=NULL, signed_by=NULL,
          addon_is_signed=0, addon_signed_at=NULL, addon_signed_by=NULL
      WHERE session_id=?
    `).run(request.entity_id);
  }

  // Mark request as APPROVED
  db.prepare(`
    UPDATE edit_requests
    SET status='APPROVED', reviewed_by=?, reviewed_at=datetime('now'), review_note=?
    WHERE request_id=?
  `).run(req.user!.user_id, review_note?.trim() || null, requestId);

  // Notify mentor if applicable
  if (request.entity_type === 'KID' && requesterRole === 'MENTOR') {
    const kid = db.prepare('SELECT first_name, last_name FROM kids WHERE kid_id=?').get(request.entity_id) as any;
    const kidName = kid ? `${kid.first_name} ${kid.last_name || ''}`.trim() : (request.entity_label || request.entity_id);
    db.prepare(`INSERT INTO notifications (notification_id, user_id, type, message, entity_id, entity_label) VALUES (?,?,?,?,?,?)`)
      .run(newUUID(), request.requested_by, 'EDIT_REQUEST_APPROVED',
        `Admin approved your edit request for "${kidName}". You can now make changes and resubmit.`,
        request.entity_id, kidName);
  }

  res.json({ message: 'Request approved and record unlocked' });
});

// ─── PUT /api/edit-requests/:requestId/deny — admin: deny request ─────────────
router.put('/:requestId/deny', requireAdmin, (req: AuthRequest, res: Response) => {
  const { requestId } = req.params;
  const { review_note } = req.body;

  const request = db.prepare('SELECT * FROM edit_requests WHERE request_id=?').get(requestId) as any;
  if (!request) { res.status(404).json({ error: 'Request not found' }); return; }
  if (request.status !== 'PENDING') {
    res.status(400).json({ error: `Request is already ${request.status.toLowerCase()}` }); return;
  }

  db.prepare(`
    UPDATE edit_requests
    SET status='DENIED', reviewed_by=?, reviewed_at=datetime('now'), review_note=?
    WHERE request_id=?
  `).run(req.user!.user_id, review_note?.trim() || null, requestId);

  res.json({ message: 'Request denied' });
});

// ─── PUT /api/edit-requests/approve-batch — admin: bulk approve ────────────
router.put('/approve-batch', requireAdmin, (req: AuthRequest, res: Response) => {
  const { request_ids } = req.body;
  if (!Array.isArray(request_ids) || request_ids.length === 0) {
    res.status(400).json({ error: 'request_ids array is required' }); return;
  }

  const update = db.transaction(() => {
    let count = 0;
    for (const requestId of request_ids) {
      const request = db.prepare("SELECT * FROM edit_requests WHERE request_id=? AND status='PENDING'").get(requestId) as any;
      if (!request) continue;

      const rqRole = (db.prepare("SELECT role FROM users WHERE user_id=?").get(request.requested_by) as any)?.role;
      if (request.entity_type === 'KID') {
        if (rqRole === 'MENTOR') {
          db.prepare(`UPDATE kids SET is_signed=0, signed_at=NULL, signed_by=NULL, mentor_edit_user_id=? WHERE kid_id=?`).run(request.requested_by, request.entity_id);
        } else {
          db.prepare(`UPDATE kids SET is_signed=0, signed_at=NULL, signed_by=NULL WHERE kid_id=?`).run(request.entity_id);
        }
      } else if (request.entity_type === 'MENTOR_NOTE') {
        db.prepare(`UPDATE mentor_notes SET is_signed=0, signed_at=NULL, signed_by=NULL WHERE note_id=?`).run(request.entity_id);
      } else if (request.entity_type === 'SPIRITUAL_SESSION') {
        db.prepare(`UPDATE spiritual_sessions SET is_signed=0, signed_at=NULL, signed_by=NULL, addon_is_signed=0, addon_signed_at=NULL, addon_signed_by=NULL WHERE session_id=?`).run(request.entity_id);
      }

      db.prepare(`UPDATE edit_requests SET status='APPROVED', reviewed_by=?, reviewed_at=datetime('now'), review_note=NULL WHERE request_id=?`).run(req.user!.user_id, requestId);

      // Notify mentor if applicable
      if (request.entity_type === 'KID' && rqRole === 'MENTOR') {
        const kid = db.prepare('SELECT first_name, last_name FROM kids WHERE kid_id=?').get(request.entity_id) as any;
        const kidName = kid ? `${kid.first_name} ${kid.last_name || ''}`.trim() : (request.entity_label || request.entity_id);
        db.prepare(`INSERT INTO notifications (notification_id, user_id, type, message, entity_id, entity_label) VALUES (?,?,?,?,?,?)`)
          .run(newUUID(), request.requested_by, 'EDIT_REQUEST_APPROVED',
            `Admin approved your edit request for "${kidName}". You can now make changes and resubmit.`,
            request.entity_id, kidName);
      }
      count++;
    }
    return count;
  });

  const approved = update();
  res.json({ approved, message: `${approved} request(s) approved` });
});

export default router;
