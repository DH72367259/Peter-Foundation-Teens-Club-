import { Router, Response } from 'express';
import db from '../database/db';
import { authenticate, requireAdmin, AuthRequest } from '../middleware/auth';
import { newUUID } from '../utils/helpers';

const router = Router();
router.use(authenticate);

// ─── GET /api/mentors/list  — dropdown list of all mentor users (ADMIN or DATA_ENTRY)
router.get('/list', (req: AuthRequest, res: Response) => {
  const role = req.user?.role;
  if (role !== 'ADMIN' && role !== 'DATA_ENTRY' && role !== 'SUB') {
    res.status(403).json({ error: 'Not authorised' }); return;
  }
  const mentors = db.prepare(
    "SELECT user_id, full_name, username FROM users WHERE role='MENTOR' AND is_active=1 ORDER BY full_name"
  ).all();
  res.json(mentors);
});

// ─── GET /api/mentors/my-kids  — mentor's own assigned kids
router.get('/my-kids', (req: AuthRequest, res: Response) => {
  if (req.user?.role !== 'MENTOR') {
    res.status(403).json({ error: 'Mentors only' }); return;
  }
  const kids = db.prepare(`
    SELECT k.kid_id, k.registration_id, k.first_name, k.last_name, k.age_snapshot,
           k.education_level, k.phone_normalized, k.gender, km.assigned_at
    FROM kids k JOIN kid_mentor km ON km.kid_id = k.kid_id
    WHERE km.mentor_id = ? AND k.is_deleted = 0
    ORDER BY k.first_name
  `).all(req.user.user_id);
  res.json(kids);
});

// ─── GET /api/mentors  — all mentors with kid counts (ADMIN)
router.get('/', requireAdmin, (_req, res) => {
  const mentors = db.prepare(`
    SELECT u.user_id, u.full_name, u.username, u.is_active,
           COUNT(km.kid_id) as assigned_count
    FROM users u
    LEFT JOIN kid_mentor km ON km.mentor_id = u.user_id
    WHERE u.role = 'MENTOR'
    GROUP BY u.user_id
    ORDER BY u.full_name
  `).all();
  res.json(mentors);
});

// ─── GET /api/mentors/:mentorId/kids  — admin view of mentor's assigned kids
router.get('/:mentorId/kids', requireAdmin, (req, res) => {
  const kids = db.prepare(`
    SELECT k.kid_id, k.registration_id, k.first_name, k.last_name, k.age_snapshot,
           k.education_level, k.phone_normalized, k.gender, km.assigned_at
    FROM kids k JOIN kid_mentor km ON km.kid_id = k.kid_id
    WHERE km.mentor_id = ? AND k.is_deleted = 0
    ORDER BY k.first_name
  `).all(req.params.mentorId);
  res.json(kids);
});

// ─── POST /api/mentors/assign  — assign kid to mentor (ADMIN)
router.post('/assign', requireAdmin, (req: AuthRequest, res: Response) => {
  const { kid_id, mentor_id } = req.body;
  if (!kid_id || !mentor_id) { res.status(400).json({ error: 'kid_id and mentor_id required' }); return; }

  const kid = db.prepare('SELECT 1 FROM kids WHERE kid_id=? AND is_deleted=0').get(kid_id);
  if (!kid) { res.status(404).json({ error: 'Kid not found' }); return; }

  const mentor = db.prepare("SELECT 1 FROM users WHERE user_id=? AND role='MENTOR' AND is_active=1").get(mentor_id);
  if (!mentor) { res.status(404).json({ error: 'Mentor not found or inactive' }); return; }

  try {
    db.prepare(
      "INSERT OR IGNORE INTO kid_mentor (kid_id, mentor_id, assigned_at, assigned_by) VALUES (?,?,datetime('now'),?)"
    ).run(kid_id, mentor_id, req.user?.user_id);
    res.json({ message: 'Assigned successfully' });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// ─── GET /api/mentors/all-assigned-kids  — kids already assigned to ANY mentor (ADMIN)
router.get('/all-assigned-kids', requireAdmin, (_req, res) => {
  const kids = db.prepare(`
    SELECT k.kid_id, k.registration_id, k.first_name, k.last_name, k.age_snapshot,
           k.education_level, k.phone_normalized,
           u.user_id as mentor_id, u.full_name as mentor_name
    FROM kids k
    JOIN kid_mentor km ON km.kid_id = k.kid_id
    JOIN users u ON u.user_id = km.mentor_id
    WHERE k.is_deleted = 0
    ORDER BY k.first_name
  `).all();
  res.json(kids);
});

// ─── POST /api/mentors/reassign  — reassign kid from one mentor to another (ADMIN)
router.post('/reassign', requireAdmin, (req: AuthRequest, res: Response) => {
  const { kid_id, new_mentor_id, reason, transfer_notes } = req.body;
  if (!kid_id || !new_mentor_id || !reason?.trim()) {
    res.status(400).json({ error: 'kid_id, new_mentor_id, and reason are required' }); return;
  }

  const kid = db.prepare('SELECT 1 FROM kids WHERE kid_id=? AND is_deleted=0').get(kid_id);
  if (!kid) { res.status(404).json({ error: 'Kid not found' }); return; }

  const newMentor = db.prepare("SELECT 1 FROM users WHERE user_id=? AND role='MENTOR' AND is_active=1").get(new_mentor_id);
  if (!newMentor) { res.status(404).json({ error: 'New mentor not found or inactive' }); return; }

  const currentAssignment = db.prepare('SELECT mentor_id FROM kid_mentor WHERE kid_id=?').get(kid_id) as any;
  const old_mentor_id = currentAssignment?.mentor_id;

  db.transaction(() => {
    // Remove from old mentor
    db.prepare('DELETE FROM kid_mentor WHERE kid_id=?').run(kid_id);
    // Assign to new mentor
    db.prepare("INSERT INTO kid_mentor (kid_id, mentor_id, assigned_at, assigned_by) VALUES (?,?,datetime('now'),?)")
      .run(kid_id, new_mentor_id, req.user!.user_id);
    // Transfer notes if requested
    if (transfer_notes && old_mentor_id) {
      db.prepare(`
        UPDATE mentor_notes
        SET mentor_id=?, is_inherited=1, original_mentor_id=?
        WHERE kid_id=? AND mentor_id=?
      `).run(new_mentor_id, old_mentor_id, kid_id, old_mentor_id);
    }
  })();

  res.json({ message: 'Reassigned successfully' });
});

// ─── DELETE /api/mentors/assign  — remove assignment (ADMIN)
router.delete('/assign', requireAdmin, (req, res) => {
  const { kid_id, mentor_id } = req.body;
  if (!kid_id || !mentor_id) { res.status(400).json({ error: 'kid_id and mentor_id required' }); return; }
  db.prepare('DELETE FROM kid_mentor WHERE kid_id=? AND mentor_id=?').run(kid_id, mentor_id);
  res.json({ message: 'Assignment removed' });
});

// ─── GET /api/mentors/notes/:kidId  — get session notes for a kid
router.get('/notes/:kidId', (req: AuthRequest, res: Response) => {
  const { kidId } = req.params;

  if (req.user?.role === 'MENTOR') {
    const assigned = db.prepare('SELECT 1 FROM kid_mentor WHERE mentor_id=? AND kid_id=?')
      .get(req.user.user_id, kidId);
    if (!assigned) { res.status(403).json({ error: 'Not assigned to this student' }); return; }
  }

  const notes = db.prepare(`
    SELECT mn.*, u.full_name as mentor_name
    FROM mentor_notes mn
    JOIN users u ON u.user_id = mn.mentor_id
    WHERE mn.kid_id = ?
    ORDER BY mn.session_date DESC
  `).all(kidId);
  res.json(notes);
});

// ─── POST /api/mentors/notes  — add session note (MENTOR or ADMIN)
router.post('/notes', (req: AuthRequest, res: Response) => {
  const role = req.user?.role;
  if (role !== 'MENTOR' && role !== 'ADMIN') {
    res.status(403).json({ error: 'Mentors and admins only' }); return;
  }

  const { kid_id, session_date, discussion, outcome, next_steps } = req.body;
  if (!kid_id || !session_date) {
    res.status(400).json({ error: 'kid_id and session_date are required' }); return;
  }

  if (role === 'MENTOR') {
    const assigned = db.prepare('SELECT 1 FROM kid_mentor WHERE mentor_id=? AND kid_id=?')
      .get(req.user!.user_id, kid_id);
    if (!assigned) { res.status(403).json({ error: 'Not assigned to this student' }); return; }
  }

  const note_id = newUUID();
  db.prepare(`
    INSERT INTO mentor_notes (note_id, kid_id, mentor_id, session_date, discussion, outcome, next_steps)
    VALUES (?,?,?,?,?,?,?)
  `).run(note_id, kid_id, req.user!.user_id, session_date,
    discussion?.slice(0, 1000) || null,
    outcome?.slice(0, 500) || null,
    next_steps?.slice(0, 500) || null
  );
  res.status(201).json({ message: 'Note saved', note_id });
});

// ─── PUT /api/mentors/notes/:noteId  — update note content (MENTOR or ADMIN)
router.put('/notes/:noteId', (req: AuthRequest, res: Response) => {
  const role = req.user?.role;
  if (role !== 'MENTOR' && role !== 'ADMIN') {
    res.status(403).json({ error: 'Mentors and admins only' }); return;
  }

  const note = db.prepare('SELECT * FROM mentor_notes WHERE note_id=?').get(req.params.noteId) as any;
  if (!note) { res.status(404).json({ error: 'Note not found' }); return; }

  if (note.is_inherited && role !== 'ADMIN') {
    res.status(403).json({ error: 'Transferred notes cannot be edited' }); return;
  }

  if (role === 'MENTOR') {
    if (note.mentor_id !== req.user!.user_id) { res.status(403).json({ error: 'Not your note' }); return; }
    if (note.is_signed) {
      res.status(400).json({ error: 'Note is locked — request admin approval to edit' }); return;
    }
  }

  const { discussion, outcome, next_steps, session_date } = req.body;
  db.prepare(`
    UPDATE mentor_notes SET
      session_date=COALESCE(?,session_date),
      discussion=?, outcome=?, next_steps=?
    WHERE note_id=?
  `).run(
    session_date || null,
    discussion?.slice(0, 1000) || null,
    outcome?.slice(0, 500) || null,
    next_steps?.slice(0, 500) || null,
    req.params.noteId
  );
  res.json({ message: 'Note updated' });
});

// ─── POST /api/mentors/notes/:noteId/sign
router.post('/notes/:noteId/sign', (req: AuthRequest, res: Response) => {
  const role = req.user?.role;
  if (role !== 'MENTOR' && role !== 'ADMIN') {
    res.status(403).json({ error: 'Not authorised' }); return;
  }
  const note = db.prepare('SELECT * FROM mentor_notes WHERE note_id=?').get(req.params.noteId) as any;
  if (!note) { res.status(404).json({ error: 'Note not found' }); return; }
  if (role === 'MENTOR' && note.mentor_id !== req.user!.user_id) {
    res.status(403).json({ error: 'Not your note' }); return;
  }
  if (note.is_signed) { res.status(400).json({ error: 'Note already signed' }); return; }

  db.prepare(`UPDATE mentor_notes SET is_signed=1, signed_at=datetime('now'), signed_by=? WHERE note_id=?`)
    .run(req.user!.full_name, req.params.noteId);
  res.json({ message: 'Note signed and locked' });
});

// ─── POST /api/mentors/notes/:noteId/unlock  — Admin only
router.post('/notes/:noteId/unlock', requireAdmin, (req: AuthRequest, res: Response) => {
  const note = db.prepare('SELECT note_id FROM mentor_notes WHERE note_id=?').get(req.params.noteId);
  if (!note) { res.status(404).json({ error: 'Note not found' }); return; }
  db.prepare(`UPDATE mentor_notes SET is_signed=0, signed_at=NULL, signed_by=NULL WHERE note_id=?`)
    .run(req.params.noteId);
  res.json({ message: 'Note unlocked for editing' });
});

// ─── DELETE /api/mentors/notes/:noteId  — delete a note (ADMIN only)
router.delete('/notes/:noteId', requireAdmin, (req, res) => {
  const result = db.prepare('DELETE FROM mentor_notes WHERE note_id=?').run(req.params.noteId);
  if (result.changes === 0) { res.status(404).json({ error: 'Note not found' }); return; }
  res.json({ message: 'Note deleted' });
});

export default router;
