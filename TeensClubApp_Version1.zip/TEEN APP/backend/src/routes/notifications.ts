import { Router, Response } from 'express';
import db from '../database/db';
import { authenticate, AuthRequest } from '../middleware/auth';

const router = Router();
router.use(authenticate);

// GET /api/notifications — all notifications for current user
router.get('/', (req: AuthRequest, res: Response) => {
  const rows = db.prepare(`
    SELECT notification_id, type, message, entity_id, entity_label, is_read, created_at
    FROM notifications
    WHERE user_id = ?
    ORDER BY created_at DESC
    LIMIT 50
  `).all(req.user!.user_id);
  res.json(rows);
});

// PUT /api/notifications/mark-read — mark all unread as read
router.put('/mark-read', (req: AuthRequest, res: Response) => {
  db.prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0")
    .run(req.user!.user_id);
  res.json({ message: 'All marked as read' });
});

// PUT /api/notifications/:id/read — mark one notification as read
router.put('/:id/read', (req: AuthRequest, res: Response) => {
  db.prepare("UPDATE notifications SET is_read = 1 WHERE notification_id = ? AND user_id = ?")
    .run(req.params.id, req.user!.user_id);
  res.json({ message: 'Marked as read' });
});

export default router;
