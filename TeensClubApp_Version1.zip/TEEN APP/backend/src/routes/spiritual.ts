import { Router, Response, NextFunction } from 'express';
import db from '../database/db';
import { authenticate, requireAdmin, AuthRequest } from '../middleware/auth';
import { newUUID } from '../utils/helpers';

const router = Router();
router.use(authenticate);

// ─── Role guards ───────────────────────────────────────────────────────────────
function requireSL(req: AuthRequest, res: Response, next: NextFunction): void {
  const role = req.user?.role;
  if (role !== 'SPIRITUAL_LEADER' && role !== 'ADMIN') {
    res.status(403).json({ error: 'Spiritual Leader or Admin access required' }); return;
  }
  next();
}

function canViewSpiritual(req: AuthRequest, res: Response, next: NextFunction): void {
  const role = req.user?.role;
  if (role !== 'ADMIN' && role !== 'SPIRITUAL_LEADER' && role !== 'MENTOR') {
    res.status(403).json({ error: 'Not authorised to view spiritual sessions' }); return;
  }
  next();
}

// ─── GET /api/spiritual/kids — all kids list for SL (dropdowns, attendance) ──
router.get('/kids', requireSL, (_req, res: Response) => {
  const kids = db.prepare(`
    SELECT k.kid_id, k.registration_id, k.first_name, k.last_name, k.age_snapshot,
           k.education_level, k.phone_normalized, k.gender,
           u.full_name as mentor_name, u.user_id as mentor_id
    FROM kids k
    LEFT JOIN kid_mentor km ON km.kid_id = k.kid_id
    LEFT JOIN users u ON u.user_id = km.mentor_id
    WHERE k.is_deleted = 0
    ORDER BY k.first_name, k.last_name
  `).all();
  res.json(kids);
});

// ─── GET /api/spiritual/mentors — mentor dropdown for SL ──────────────────────
router.get('/mentors', requireSL, (_req, res: Response) => {
  const mentors = db.prepare(
    "SELECT user_id, full_name, username FROM users WHERE role='MENTOR' AND is_active=1 ORDER BY full_name"
  ).all();
  res.json(mentors);
});

// ─── GET /api/spiritual/my-invites — mentor sees their RSVP invites ─────────
router.get('/my-invites', (req: AuthRequest, res: Response) => {
  if (req.user?.role !== 'MENTOR') { res.json([]); return; }
  const rows = db.prepare(`
    SELECT ss.session_id, ss.session_date, ss.topic, ss.session_type,
           ss.is_signed, ss.target_id,
           sma.rsvp_status, sma.is_present,
           u.full_name as created_by_name
    FROM spiritual_sessions ss
    JOIN spiritual_mentor_attendance sma ON sma.session_id = ss.session_id
    JOIN users u ON u.user_id = ss.created_by
    WHERE sma.mentor_id = ?
    ORDER BY ss.session_date DESC, ss.created_at DESC
  `).all(req.user!.user_id) as any[];
  const result = rows.map((r: any) => {
    let targetName = null;
    if (r.target_id) {
      if (r.session_type === 'ONE_ON_ONE_KID') {
        const kid = db.prepare('SELECT first_name, last_name FROM kids WHERE kid_id=?').get(r.target_id) as any;
        targetName = kid ? `${kid.first_name} ${kid.last_name}` : null;
      } else if (r.session_type === 'ONE_ON_ONE_MENTOR') {
        const mentor = db.prepare('SELECT full_name FROM users WHERE user_id=?').get(r.target_id) as any;
        targetName = mentor?.full_name ?? null;
      }
    }
    return { ...r, targetName };
  });
  res.json(result);
});

// ─── GET /api/spiritual/sessions — list all sessions ─────────────────────────
router.get('/sessions', canViewSpiritual, (req: AuthRequest, res: Response) => {
  const sessions = db.prepare(`
    SELECT ss.session_id, ss.session_date, ss.topic, ss.session_type, ss.target_id,
           ss.group_note, ss.created_by, ss.created_at, u.full_name as created_by_name,
           ss.is_signed, ss.signed_by, ss.signed_at,
           ss.one_on_one_attended,
           (SELECT COUNT(*) FROM spiritual_attendance sa  WHERE sa.session_id = ss.session_id AND sa.is_present = 1) as present_count,
           (SELECT COUNT(*) FROM spiritual_attendance sa2 WHERE sa2.session_id = ss.session_id) as total_registered,
           (SELECT COUNT(*) FROM spiritual_kid_notes skn WHERE skn.session_id = ss.session_id) as note_count,
           (SELECT COUNT(*) FROM spiritual_mentor_attendance sma WHERE sma.session_id = ss.session_id AND sma.rsvp_status = 'ACCEPTED') as rsvp_accepted,
           (SELECT COUNT(*) FROM spiritual_mentor_attendance sma2 WHERE sma2.session_id = ss.session_id AND sma2.rsvp_status = 'PENDING') as rsvp_pending,
           (SELECT COUNT(*) FROM spiritual_mentor_attendance sma3 WHERE sma3.session_id = ss.session_id) as rsvp_total
    FROM spiritual_sessions ss
    JOIN users u ON u.user_id = ss.created_by
    ORDER BY ss.session_date DESC, ss.created_at DESC
  `).all() as any[];

  // Enrich with target names for 1:1 sessions
  const result = sessions.map(s => {
    let targetName = null;
    if (s.target_id) {
      if (s.session_type === 'ONE_ON_ONE_KID') {
        const kid = db.prepare('SELECT first_name, last_name, registration_id FROM kids WHERE kid_id=?').get(s.target_id) as any;
        targetName = kid ? `${kid.first_name} ${kid.last_name}` : 'Unknown';
      } else if (s.session_type === 'ONE_ON_ONE_MENTOR') {
        const mentor = db.prepare('SELECT full_name FROM users WHERE user_id=?').get(s.target_id) as any;
        targetName = mentor?.full_name ?? 'Unknown';
      }
    }
    const { group_note, ...rest } = s;
    return { ...rest, has_group_note: !!group_note, targetName };
  });

  res.json(result);
});

// ─── POST /api/spiritual/sessions — create session ────────────────────────────
router.post('/sessions', requireSL, (req: AuthRequest, res: Response) => {
  const { session_date, topic, session_type = 'GROUP', target_id = null, kid_ids } = req.body;
  if (!session_date) { res.status(400).json({ error: 'Session date is required' }); return; }
  if (!topic?.trim()) { res.status(400).json({ error: 'Topic is required' }); return; }

  const validTypes = ['GROUP', 'ONE_ON_ONE_KID', 'ONE_ON_ONE_MENTOR', 'SMALL_GROUP', 'ALL_MENTORS'];
  if (!validTypes.includes(session_type)) {
    res.status(400).json({ error: 'Invalid session type' }); return;
  }
  // 2-month cap
  const maxDate = new Date(Date.now() + 60 * 86400000).toISOString().slice(0, 10);
  if (session_date > maxDate) {
    res.status(400).json({ error: 'Session date cannot be more than 2 months in the future' }); return;
  }
  if (session_type === 'ONE_ON_ONE_KID' && !target_id) {
    res.status(400).json({ error: 'Target teen is required for 1:1 teen sessions' }); return;
  }
  if (session_type === 'ONE_ON_ONE_MENTOR' && !target_id) {
    res.status(400).json({ error: 'Target mentor is required for 1:1 mentor sessions' }); return;
  }
  if (session_type === 'SMALL_GROUP') {
    if (!Array.isArray(kid_ids) || kid_ids.length < 1 || kid_ids.length > 10) {
      res.status(400).json({ error: 'SMALL_GROUP requires 1–10 teen IDs in kid_ids' }); return;
    }
  }

  const session_id = newUUID();
  const slName = (req.user as any)?.full_name || 'Spiritual Leader';
  const topicTrimmed = topic.trim();

  db.prepare(`
    INSERT INTO spiritual_sessions (session_id, session_date, topic, session_type, target_id, created_by)
    VALUES (?,?,?,?,?,?)
  `).run(session_id, session_date, topicTrimmed, session_type, target_id || null, req.user?.user_id);

  const notifyMentor = db.prepare(`INSERT INTO notifications (notification_id, user_id, type, message, entity_id, entity_label) VALUES (?,?,?,?,?,?)`);

  if (session_type === 'GROUP') {
    const kids = db.prepare('SELECT kid_id FROM kids WHERE is_deleted=0').all() as any[];
    const insKid = db.prepare('INSERT OR IGNORE INTO spiritual_attendance (session_id, kid_id, is_present) VALUES (?,?,0)');
    db.transaction(() => { kids.forEach(k => insKid.run(session_id, k.kid_id)); })();

    const mentors = db.prepare("SELECT user_id FROM users WHERE role='MENTOR' AND is_active=1").all() as any[];
    const insMentor = db.prepare("INSERT OR IGNORE INTO spiritual_mentor_attendance (session_id, mentor_id, is_present, rsvp_status) VALUES (?,?,0,'PENDING')");
    db.transaction(() => {
      mentors.forEach(m => {
        insMentor.run(session_id, m.user_id);
        notifyMentor.run(newUUID(), m.user_id, 'SESSION_INVITE',
          `📅 ${slName} scheduled a group session: "${topicTrimmed}" on ${session_date}. Please RSVP.`,
          session_id, topicTrimmed);
      });
    })();

  } else if (session_type === 'SMALL_GROUP') {
    const validKids = (kid_ids as string[]).filter(kid_id =>
      db.prepare('SELECT 1 FROM kids WHERE kid_id=? AND is_deleted=0').get(kid_id)
    );
    const insKid = db.prepare('INSERT OR IGNORE INTO spiritual_attendance (session_id, kid_id, is_present) VALUES (?,?,0)');
    db.transaction(() => { validKids.forEach(kid_id => insKid.run(session_id, kid_id)); })();

    // Find mentors of these specific kids
    const mentorIdSet = new Set<string>();
    validKids.forEach(kid_id => {
      const rows = db.prepare('SELECT mentor_id FROM kid_mentor WHERE kid_id=?').all(kid_id) as any[];
      rows.forEach(r => mentorIdSet.add(r.mentor_id));
    });
    const kidNames = validKids.map(kid_id => {
      const k = db.prepare('SELECT first_name, last_name FROM kids WHERE kid_id=?').get(kid_id) as any;
      return k ? `${k.first_name} ${k.last_name}` : '';
    }).filter(Boolean).join(', ');
    const insMentor = db.prepare("INSERT OR IGNORE INTO spiritual_mentor_attendance (session_id, mentor_id, is_present, rsvp_status) VALUES (?,?,0,'PENDING')");
    db.transaction(() => {
      for (const mentor_id of mentorIdSet) {
        insMentor.run(session_id, mentor_id);
        notifyMentor.run(newUUID(), mentor_id, 'SESSION_INVITE',
          `📅 ${slName} scheduled a small group session: "${topicTrimmed}" on ${session_date} (teens: ${kidNames}). Please RSVP.`,
          session_id, topicTrimmed);
      }
    })();

  } else if (session_type === 'ALL_MENTORS') {
    const mentors = db.prepare("SELECT user_id FROM users WHERE role='MENTOR' AND is_active=1").all() as any[];
    const insMentor = db.prepare("INSERT OR IGNORE INTO spiritual_mentor_attendance (session_id, mentor_id, is_present, rsvp_status) VALUES (?,?,0,'PENDING')");
    db.transaction(() => {
      mentors.forEach(m => {
        insMentor.run(session_id, m.user_id);
        notifyMentor.run(newUUID(), m.user_id, 'SESSION_INVITE',
          `📅 ${slName} scheduled an all-mentors meeting: "${topicTrimmed}" on ${session_date}. Please RSVP.`,
          session_id, topicTrimmed);
      });
    })();

  } else if (session_type === 'ONE_ON_ONE_KID' && target_id) {
    db.prepare('INSERT OR IGNORE INTO spiritual_attendance (session_id, kid_id, is_present) VALUES (?,?,0)').run(session_id, target_id);
    const kidMentors = db.prepare('SELECT mentor_id FROM kid_mentor WHERE kid_id=?').all(target_id) as any[];
    if (kidMentors.length > 0) {
      const kid = db.prepare('SELECT first_name, last_name FROM kids WHERE kid_id=?').get(target_id) as any;
      const kidName = kid ? `${kid.first_name} ${kid.last_name}` : 'your assigned teen';
      const insMentor = db.prepare("INSERT OR IGNORE INTO spiritual_mentor_attendance (session_id, mentor_id, is_present, rsvp_status) VALUES (?,?,0,'PENDING')");
      db.transaction(() => {
        kidMentors.forEach((m: any) => {
          insMentor.run(session_id, m.mentor_id);
          notifyMentor.run(newUUID(), m.mentor_id, 'SESSION_INVITE',
            `📅 ${slName} scheduled a 1:1 session with ${kidName}: "${topicTrimmed}" on ${session_date}.`,
            session_id, topicTrimmed);
        });
      })();
    }

  } else if (session_type === 'ONE_ON_ONE_MENTOR' && target_id) {
    db.prepare("INSERT OR IGNORE INTO spiritual_mentor_attendance (session_id, mentor_id, is_present, rsvp_status) VALUES (?,?,0,'PENDING')")
      .run(session_id, target_id);
    notifyMentor.run(newUUID(), target_id, 'SESSION_INVITE',
      `📅 ${slName} scheduled a 1:1 meeting with you: "${topicTrimmed}" on ${session_date}. Please RSVP.`,
      session_id, topicTrimmed);
  }

  res.status(201).json({ message: 'Session created', session_id });
});

// ─── PUT /api/spiritual/sessions/:id/rsvp — mentor RSVP ─────────────────────
router.put('/sessions/:id/rsvp', (req: AuthRequest, res: Response) => {
  if (req.user?.role !== 'MENTOR') {
    res.status(403).json({ error: 'Only mentors can RSVP to sessions' }); return;
  }
  const { rsvp_status } = req.body;
  if (!['ACCEPTED', 'DECLINED'].includes(rsvp_status)) {
    res.status(400).json({ error: 'rsvp_status must be ACCEPTED or DECLINED' }); return;
  }
  const row = db.prepare('SELECT 1 FROM spiritual_mentor_attendance WHERE session_id=? AND mentor_id=?')
    .get(req.params.id, req.user!.user_id);
  if (!row) { res.status(404).json({ error: 'You are not invited to this session' }); return; }
  db.prepare("UPDATE spiritual_mentor_attendance SET rsvp_status=? WHERE session_id=? AND mentor_id=?")
    .run(rsvp_status, req.params.id, req.user!.user_id);
  res.json({ message: rsvp_status === 'ACCEPTED' ? 'You have confirmed attendance' : 'Marked as not attending' });
});

// ─── GET /api/spiritual/sessions/:id — full session detail ────────────────────
router.get('/sessions/:id', canViewSpiritual, (req: AuthRequest, res: Response) => {
  const role = req.user?.role;
  const { id } = req.params;

  const session = db.prepare(`
    SELECT ss.*, u.full_name as created_by_name
    FROM spiritual_sessions ss
    JOIN users u ON u.user_id = ss.created_by
    WHERE ss.session_id = ?
  `).get(id) as any;
  if (!session) { res.status(404).json({ error: 'Session not found' }); return; }

  // Attendance list (kid attendance)
  let attendance: any[];
  if (role === 'MENTOR') {
    attendance = db.prepare(`
      SELECT sa.kid_id, sa.is_present,
             k.first_name, k.last_name, k.registration_id, k.age_snapshot, k.education_level, k.phone_normalized
      FROM spiritual_attendance sa
      JOIN kids k ON k.kid_id = sa.kid_id
      JOIN kid_mentor km ON km.kid_id = sa.kid_id
      WHERE sa.session_id = ? AND km.mentor_id = ? AND k.is_deleted = 0
      ORDER BY k.first_name, k.last_name
    `).all(id, req.user!.user_id) as any[];
  } else {
    attendance = db.prepare(`
      SELECT sa.kid_id, sa.is_present,
             k.first_name, k.last_name, k.registration_id, k.age_snapshot, k.education_level, k.phone_normalized,
             (SELECT u2.full_name FROM users u2 JOIN kid_mentor km2 ON km2.mentor_id = u2.user_id WHERE km2.kid_id = k.kid_id LIMIT 1) as mentor_name
      FROM spiritual_attendance sa
      JOIN kids k ON k.kid_id = sa.kid_id
      WHERE sa.session_id = ? AND k.is_deleted = 0
      ORDER BY k.first_name, k.last_name
    `).all(id) as any[];
  }

  // Mentor attendance (for GROUP/SMALL_GROUP/ALL_MENTORS sessions, visible to SL/ADMIN; MENTOR sees own row only)
  let mentorAttendance: any[] = [];
  const isGroupLike = ['GROUP', 'SMALL_GROUP', 'ALL_MENTORS'].includes(session.session_type);
  const isONEONONE_MENTOR = session.session_type === 'ONE_ON_ONE_MENTOR';
  if ((isGroupLike || isONEONONE_MENTOR) && role !== 'MENTOR') {
    mentorAttendance = db.prepare(`
      SELECT sma.mentor_id, sma.is_present, sma.rsvp_status,
             u.full_name AS mentor_name, u.username
      FROM spiritual_mentor_attendance sma
      JOIN users u ON u.user_id = sma.mentor_id
      WHERE sma.session_id = ?
      ORDER BY u.full_name
    `).all(id) as any[];
  } else if (role === 'MENTOR') {
    // Mentors see their own RSVP row for all session types
    const myRow = db.prepare(`
      SELECT sma.mentor_id, sma.is_present, sma.rsvp_status,
             u.full_name AS mentor_name, u.username
      FROM spiritual_mentor_attendance sma
      JOIN users u ON u.user_id = sma.mentor_id
      WHERE sma.session_id = ? AND sma.mentor_id = ?
    `).get(id, req.user!.user_id) as any;
    if (myRow) mentorAttendance = [myRow];
  }

  // Kid notes for this session (MENTOR sees only their kids)
  let kidNotes: any[];
  if (role === 'MENTOR') {
    kidNotes = db.prepare(`
      SELECT skn.note_id, skn.kid_id, skn.content, skn.improvement, skn.suggestions, skn.created_at,
             k.first_name, k.last_name, k.registration_id, u.full_name as author_name
      FROM spiritual_kid_notes skn
      JOIN kids k ON k.kid_id = skn.kid_id
      JOIN users u ON u.user_id = skn.created_by
      JOIN kid_mentor km ON km.kid_id = skn.kid_id
      WHERE skn.session_id = ? AND km.mentor_id = ?
      ORDER BY skn.created_at DESC
    `).all(id, req.user!.user_id) as any[];
  } else {
    kidNotes = db.prepare(`
      SELECT skn.note_id, skn.kid_id, skn.content, skn.improvement, skn.suggestions, skn.created_at,
             k.first_name, k.last_name, k.registration_id, u.full_name as author_name
      FROM spiritual_kid_notes skn
      JOIN kids k ON k.kid_id = skn.kid_id
      JOIN users u ON u.user_id = skn.created_by
      WHERE skn.session_id = ?
      ORDER BY skn.created_at DESC
    `).all(id) as any[];
  }

  // Target name for 1:1 sessions
  let targetName = null;
  if (session.target_id) {
    if (session.session_type === 'ONE_ON_ONE_KID') {
      const kid = db.prepare('SELECT first_name, last_name, registration_id FROM kids WHERE kid_id=?').get(session.target_id) as any;
      targetName = kid ? `${kid.first_name} ${kid.last_name} (${kid.registration_id})` : 'Unknown';
    } else {
      const mentor = db.prepare('SELECT full_name FROM users WHERE user_id=?').get(session.target_id) as any;
      targetName = mentor?.full_name ?? 'Unknown';
    }
  }

  res.json({ ...session, targetName, attendance, mentorAttendance, kidNotes });
});

// ─── PUT /api/spiritual/sessions/:id — update topic / group_note ──────────────
router.put('/sessions/:id', requireSL, (req: AuthRequest, res: Response) => {
  const { id } = req.params;
  const { topic, group_note } = req.body;

  const session = db.prepare('SELECT * FROM spiritual_sessions WHERE session_id=?').get(id) as any;
  if (!session) { res.status(404).json({ error: 'Session not found' }); return; }
  if (session.is_signed) {
    res.status(400).json({ error: 'Session is locked — notes cannot be modified after signing' }); return;
  }

  db.prepare(`
    UPDATE spiritual_sessions
    SET topic      = COALESCE(?, topic),
        group_note = ?,
        updated_at = datetime('now')
    WHERE session_id = ?
  `).run(topic?.trim() || null, group_note !== undefined ? (group_note?.trim() || null) : null, id);

  res.json({ message: 'Session updated' });
});

// ─── POST /api/spiritual/sessions/:id/sign ────────────────────────────────────
router.post('/sessions/:id/sign', requireSL, (req: AuthRequest, res: Response) => {
  const session = db.prepare('SELECT * FROM spiritual_sessions WHERE session_id=?').get(req.params.id) as any;
  if (!session) { res.status(404).json({ error: 'Session not found' }); return; }
  if (session.is_signed) { res.status(400).json({ error: 'Session is already signed' }); return; }

  db.prepare(`UPDATE spiritual_sessions SET is_signed=1, signed_at=datetime('now'), signed_by=? WHERE session_id=?`)
    .run(req.user!.full_name, req.params.id);
  res.json({ message: 'Session signed and locked' });
});

// ─── PUT /api/spiritual/sessions/:id/addon ────────────────────────────────────
router.put('/sessions/:id/addon', requireSL, (req: AuthRequest, res: Response) => {
  const { addon_text } = req.body;
  const session = db.prepare('SELECT * FROM spiritual_sessions WHERE session_id=?').get(req.params.id) as any;
  if (!session)           { res.status(404).json({ error: 'Session not found' }); return; }
  if (!session.is_signed) { res.status(400).json({ error: 'Session must be signed before adding addon notes' }); return; }
  if (session.addon_is_signed) { res.status(400).json({ error: 'Addon is already signed and locked' }); return; }

  db.prepare(`UPDATE spiritual_sessions SET addon_text=?, updated_at=datetime('now') WHERE session_id=?`)
    .run(addon_text?.trim() || null, req.params.id);
  res.json({ message: 'Addon saved' });
});

// ─── POST /api/spiritual/sessions/:id/addon-sign ─────────────────────────────
router.post('/sessions/:id/addon-sign', requireSL, (req: AuthRequest, res: Response) => {
  const session = db.prepare('SELECT * FROM spiritual_sessions WHERE session_id=?').get(req.params.id) as any;
  if (!session)                    { res.status(404).json({ error: 'Session not found' }); return; }
  if (!session.is_signed)          { res.status(400).json({ error: 'Session must be signed first' }); return; }
  if (!session.addon_text?.trim()) { res.status(400).json({ error: 'No addon text to sign' }); return; }
  if (session.addon_is_signed)     { res.status(400).json({ error: 'Addon is already signed' }); return; }

  db.prepare(`UPDATE spiritual_sessions SET addon_is_signed=1, addon_signed_at=datetime('now'), addon_signed_by=? WHERE session_id=?`)
    .run(req.user!.full_name, req.params.id);
  res.json({ message: 'Addon signed' });
});

// ─── PUT /api/spiritual/sessions/:id/attendance — save attendance ─────────────
router.put('/sessions/:id/attendance', requireSL, (req: AuthRequest, res: Response) => {
  const { id } = req.params;

  const session = db.prepare('SELECT * FROM spiritual_sessions WHERE session_id=?').get(id) as any;
  if (!session) { res.status(404).json({ error: 'Session not found' }); return; }
  if (session.is_signed) {
    res.status(400).json({ error: 'Session is locked — attendance cannot be modified after signing' }); return;
  }

  if (['GROUP', 'SMALL_GROUP'].includes(session.session_type)) {
    const { attendance, mentor_attendance } = req.body;
    if (!Array.isArray(attendance)) { res.status(400).json({ error: 'attendance array required' }); return; }

    const upsertKid = db.prepare('INSERT OR REPLACE INTO spiritual_attendance (session_id, kid_id, is_present) VALUES (?,?,?)');
    db.transaction(() => {
      attendance.forEach(({ kid_id, is_present }: { kid_id: string; is_present: boolean }) => {
        upsertKid.run(id, kid_id, is_present ? 1 : 0);
      });
    })();

    if (Array.isArray(mentor_attendance)) {
      const upsertMentor = db.prepare('UPDATE spiritual_mentor_attendance SET is_present=? WHERE session_id=? AND mentor_id=?');
      db.transaction(() => {
        mentor_attendance.forEach(({ mentor_id, is_present }: { mentor_id: string; is_present: boolean }) => {
          upsertMentor.run(is_present ? 1 : 0, id, mentor_id);
        });
      })();
    }
  } else if (session.session_type === 'ALL_MENTORS') {
    const { mentor_attendance } = req.body;
    if (Array.isArray(mentor_attendance)) {
      const upsertMentor = db.prepare('UPDATE spiritual_mentor_attendance SET is_present=? WHERE session_id=? AND mentor_id=?');
      db.transaction(() => {
        mentor_attendance.forEach(({ mentor_id, is_present }: { mentor_id: string; is_present: boolean }) => {
          upsertMentor.run(is_present ? 1 : 0, id, mentor_id);
        });
      })();
    }
    res.json({ message: 'Attendance saved' }); return;
  } else {
    // 1:1 session — save one_on_one_attended on the session row
    const { one_on_one_attended } = req.body;
    const attended = one_on_one_attended ? 1 : 0;
    db.prepare('UPDATE spiritual_sessions SET one_on_one_attended=? WHERE session_id=?').run(attended, id);
    if (session.session_type === 'ONE_ON_ONE_KID' && session.target_id) {
      db.prepare('INSERT OR REPLACE INTO spiritual_attendance (session_id, kid_id, is_present) VALUES (?,?,?)')
        .run(id, session.target_id, attended);
    } else if (session.session_type === 'ONE_ON_ONE_MENTOR' && session.target_id) {
      // Keep spiritual_mentor_attendance in sync so Records page shows correct attendance
      db.prepare('UPDATE spiritual_mentor_attendance SET is_present=? WHERE session_id=? AND mentor_id=?')
        .run(attended, id, session.target_id);
    }
  }
  res.json({ message: 'Attendance saved' });
});

// ─── POST /api/spiritual/sessions/:id/kid-note — add individual kid note ──────
router.post('/sessions/:id/kid-note', requireSL, (req: AuthRequest, res: Response) => {
  const { id } = req.params;
  const { kid_id, content, improvement, suggestions } = req.body;
  if (!kid_id) { res.status(400).json({ error: 'kid_id is required' }); return; }
  if (!content?.trim()) { res.status(400).json({ error: 'Content is required' }); return; }

  const session = db.prepare('SELECT is_signed FROM spiritual_sessions WHERE session_id=?').get(id) as any;
  if (!session) { res.status(404).json({ error: 'Session not found' }); return; }
  if (session.is_signed) {
    res.status(400).json({ error: 'Session is locked — individual notes cannot be added after signing' }); return;
  }

  const note_id = newUUID();
  db.prepare(`
    INSERT INTO spiritual_kid_notes (note_id, session_id, kid_id, content, improvement, suggestions, created_by)
    VALUES (?,?,?,?,?,?,?)
  `).run(note_id, id, kid_id, content.trim(), improvement?.trim() || null, suggestions?.trim() || null, req.user?.user_id);

  res.status(201).json({ message: 'Note added', note_id });
});

// ─── GET /api/spiritual/kid-notes/:kidId — all spiritual notes for a kid ──────
router.get('/kid-notes/:kidId', (req: AuthRequest, res: Response) => {
  const role = req.user?.role;
  const { kidId } = req.params;

  if (role === 'MENTOR') {
    const assigned = db.prepare('SELECT 1 FROM kid_mentor WHERE mentor_id=? AND kid_id=?').get(req.user!.user_id, kidId);
    if (!assigned) { res.status(403).json({ error: 'Not assigned to this student' }); return; }
  } else if (role !== 'ADMIN' && role !== 'SPIRITUAL_LEADER') {
    res.status(403).json({ error: 'Not authorised' }); return;
  }

  const notes = db.prepare(`
    SELECT skn.note_id, skn.session_id, skn.kid_id, skn.content, skn.improvement, skn.suggestions, skn.created_at,
           u.full_name as author_name,
           ss.session_date, ss.topic as session_topic
    FROM spiritual_kid_notes skn
    JOIN users u ON u.user_id = skn.created_by
    JOIN spiritual_sessions ss ON ss.session_id = skn.session_id
    WHERE skn.kid_id = ?
    ORDER BY skn.created_at DESC
  `).all(kidId);
  res.json(notes);
});

// ─── DELETE /api/spiritual/kid-notes/note/:noteId — SL or ADMIN ───────────────
// Must be registered BEFORE /kid-notes/:kidId to avoid :kidId matching "note"
router.delete('/kid-notes/note/:noteId', requireSL, (req: AuthRequest, res: Response) => {
  const note = db.prepare(`
    SELECT skn.note_id, ss.is_signed
    FROM spiritual_kid_notes skn
    JOIN spiritual_sessions ss ON ss.session_id = skn.session_id
    WHERE skn.note_id = ?
  `).get(req.params.noteId) as any;
  if (!note) { res.status(404).json({ error: 'Note not found' }); return; }
  if (note.is_signed) {
    res.status(400).json({ error: 'Session is locked — notes cannot be deleted after signing' }); return;
  }
  db.prepare('DELETE FROM spiritual_kid_notes WHERE note_id=?').run(req.params.noteId);
  res.json({ message: 'Note deleted' });
});

// ─── POST /api/spiritual/sessions/:id/unlock — ADMIN only ────────────────────
router.post('/sessions/:id/unlock', requireAdmin, (req: AuthRequest, res: Response) => {
  const session = db.prepare('SELECT session_id FROM spiritual_sessions WHERE session_id=?').get(req.params.id);
  if (!session) { res.status(404).json({ error: 'Session not found' }); return; }

  db.prepare(`
    UPDATE spiritual_sessions
    SET is_signed=0, signed_at=NULL, signed_by=NULL,
        addon_is_signed=0, addon_signed_at=NULL, addon_signed_by=NULL
    WHERE session_id=?
  `).run(req.params.id);
  res.json({ message: 'Session unlocked' });
});

// ─── DELETE /api/spiritual/sessions/:id — ADMIN only ─────────────────────────
router.delete('/sessions/:id', requireAdmin, (req: AuthRequest, res: Response) => {
  const result = db.prepare('DELETE FROM spiritual_sessions WHERE session_id=?').run(req.params.id);
  if (result.changes === 0) { res.status(404).json({ error: 'Session not found' }); return; }
  res.json({ message: 'Session deleted' });
});

// ─── PUT /api/spiritual/sessions/:id/cancel — SL cancels a session ────────────
router.put('/sessions/:id/cancel', requireSL, (req: AuthRequest, res: Response) => {
  const { cancelled_reason, proposed_new_date, proposed_new_topic } = req.body;
  if (!cancelled_reason?.trim()) { res.status(400).json({ error: 'Reason for cancellation is required' }); return; }

  const session = db.prepare('SELECT * FROM spiritual_sessions WHERE session_id=?').get(req.params.id) as any;
  if (!session) { res.status(404).json({ error: 'Session not found' }); return; }
  if (session.is_cancelled) { res.status(400).json({ error: 'Session is already cancelled' }); return; }

  const slName = (req.user as any)?.full_name || 'Spiritual Leader';
  db.prepare(`UPDATE spiritual_sessions SET is_cancelled=1, cancelled_at=datetime('now'), cancelled_by=?, cancelled_reason=?, proposed_new_date=?, proposed_new_topic=?, updated_at=datetime('now') WHERE session_id=?`)
    .run(slName, cancelled_reason.trim(), proposed_new_date || null, proposed_new_topic?.trim() || null, req.params.id);

  // Notify all invited mentors
  const mentors = db.prepare('SELECT mentor_id FROM spiritual_mentor_attendance WHERE session_id=?').all(req.params.id) as any[];
  const insertNotif = db.prepare(`INSERT INTO notifications (notification_id, user_id, type, message, entity_id, entity_label) VALUES (?,?,?,?,?,?)`);
  const proposeMsg = proposed_new_date ? ` New proposed date: ${proposed_new_date}${proposed_new_topic ? ` — "${proposed_new_topic}"` : ''}.` : '';
  db.transaction(() => {
    mentors.forEach((m: any) => {
      insertNotif.run(newUUID(), m.mentor_id, 'SESSION_CANCELLED',
        `❌ Session "${session.topic}" on ${session.session_date} has been cancelled by ${slName}. Reason: ${cancelled_reason.trim()}.${proposeMsg}`,
        req.params.id, session.topic);
    });
  })();

  res.json({ message: 'Session cancelled and mentors notified' });
});

// ─── GET /api/spiritual/upcoming — upcoming sessions (with filters) ─────────
router.get('/upcoming', canViewSpiritual, (req: AuthRequest, res: Response) => {
  const role = req.user?.role;
  const days  = Math.min(parseInt(String(req.query.days || '14'), 10), 60);
  let { type_filter } = req.query; // 'all'|'GROUP'|'SMALL_GROUP'|'ALL_MENTORS'|'ONE_ON_ONE_KID'|'ONE_ON_ONE_MENTOR'

  const today     = new Date().toISOString().slice(0, 10);
  const futureEnd = new Date(Date.now() + days * 86400000).toISOString().slice(0, 10);

  let rows = db.prepare(`
    SELECT ss.session_id, ss.session_date, ss.topic, ss.session_type, ss.target_id,
           ss.is_signed, ss.is_cancelled, ss.cancelled_reason, ss.proposed_new_date, ss.proposed_new_topic,
           u.full_name as created_by_name,
           ss.one_on_one_attended,
           (SELECT COUNT(*) FROM spiritual_attendance sa  WHERE sa.session_id = ss.session_id AND sa.is_present = 1) as present_count,
           (SELECT COUNT(*) FROM spiritual_attendance sa2 WHERE sa2.session_id = ss.session_id) as total_registered,
           (SELECT COUNT(*) FROM spiritual_mentor_attendance sma WHERE sma.session_id = ss.session_id AND sma.rsvp_status = 'ACCEPTED') as rsvp_accepted,
           (SELECT COUNT(*) FROM spiritual_mentor_attendance sma2 WHERE sma2.session_id = ss.session_id) as rsvp_total
    FROM spiritual_sessions ss
    JOIN users u ON u.user_id = ss.created_by
    WHERE ss.session_date >= ? AND ss.session_date <= ?
      AND ss.is_signed = 0
    ORDER BY ss.session_date ASC, ss.created_at ASC
  `).all(today, futureEnd) as any[];

  // Mentors only see sessions they're invited to
  if (role === 'MENTOR') {
    const myIds = new Set(
      (db.prepare('SELECT session_id FROM spiritual_mentor_attendance WHERE mentor_id=?').all(req.user!.user_id) as any[]).map((r: any) => r.session_id)
    );
    rows = rows.filter((r: any) => myIds.has(r.session_id));
  }

  // Apply type filter
  if (type_filter && type_filter !== 'all') {
    rows = rows.filter((r: any) => r.session_type === type_filter);
  }

  // Enrich with target names and my RSVP for mentors
  const result = rows.map((s: any) => {
    let targetName = null;
    if (s.target_id) {
      if (s.session_type === 'ONE_ON_ONE_KID') {
        const kid = db.prepare('SELECT first_name, last_name FROM kids WHERE kid_id=?').get(s.target_id) as any;
        targetName = kid ? `${kid.first_name} ${kid.last_name}` : null;
      } else if (s.session_type === 'ONE_ON_ONE_MENTOR') {
        const mentor = db.prepare('SELECT full_name FROM users WHERE user_id=?').get(s.target_id) as any;
        targetName = mentor?.full_name ?? null;
      }
    }
    let myRsvp = null;
    if (role === 'MENTOR') {
      const row = db.prepare('SELECT rsvp_status FROM spiritual_mentor_attendance WHERE session_id=? AND mentor_id=?').get(s.session_id, req.user!.user_id) as any;
      myRsvp = row?.rsvp_status ?? null;
    }
    // Days until session
    const today = new Date(); today.setHours(0,0,0,0);
    const sessDate = new Date(s.session_date + 'T00:00:00');
    const daysUntil = Math.round((sessDate.getTime() - today.getTime()) / 86400000);
    return { ...s, targetName, myRsvp, daysUntil };
  });

  res.json(result);
});

// ─── GET /api/spiritual/session-requests — SL sees all pending requests ────────
router.get('/session-requests', requireSL, (_req: AuthRequest, res: Response) => {
  const rows = db.prepare(`
    SELECT sr.*, u.full_name as requester_name, u.username as requester_username
    FROM session_requests sr
    JOIN users u ON u.user_id = sr.requested_by
    ORDER BY sr.created_at DESC
  `).all() as any[];
  res.json(rows);
});

// ─── GET /api/spiritual/my-session-requests — mentor sees their requests ───────
router.get('/my-session-requests', (req: AuthRequest, res: Response) => {
  if (req.user?.role !== 'MENTOR') { res.json([]); return; }
  const rows = db.prepare(`
    SELECT sr.*, u.full_name as requester_name
    FROM session_requests sr
    JOIN users u ON u.user_id = sr.requested_by
    WHERE sr.requested_by = ?
    ORDER BY sr.created_at DESC
  `).all(req.user!.user_id) as any[];
  res.json(rows);
});

// ─── POST /api/spiritual/session-requests — mentor creates a request ──────────
router.post('/session-requests', (req: AuthRequest, res: Response) => {
  if (req.user?.role !== 'MENTOR') { res.status(403).json({ error: 'Only mentors can create session requests' }); return; }
  const { request_type, kid_ids, message } = req.body;
  if (!['ONE_ON_ONE_SL', 'ONE_ON_ONE_KID'].includes(request_type)) {
    res.status(400).json({ error: 'request_type must be ONE_ON_ONE_SL or ONE_ON_ONE_KID' }); return;
  }
  if (!message?.trim()) { res.status(400).json({ error: 'Message is required' }); return; }
  if (request_type === 'ONE_ON_ONE_KID') {
    if (!Array.isArray(kid_ids) || kid_ids.length === 0) {
      res.status(400).json({ error: 'kid_ids required for ONE_ON_ONE_KID request' }); return;
    }
  }

  const request_id = newUUID();
  db.prepare(`INSERT INTO session_requests (request_id, requested_by, request_type, kid_ids, message, status) VALUES (?,?,?,?,?,?)`)
    .run(request_id, req.user!.user_id, request_type, kid_ids ? JSON.stringify(kid_ids) : null, message.trim(), 'PENDING');

  // Notify all Spiritual Leaders
  const sls = db.prepare("SELECT user_id FROM users WHERE role IN ('SPIRITUAL_LEADER','ADMIN') AND is_active=1").all() as any[];
  const mentorName = (req.user as any)?.full_name || 'Mentor';
  const typeLabel = request_type === 'ONE_ON_ONE_SL' ? '1:1 with you' : '1:1 for their teens';
  const insertNotif = db.prepare(`INSERT INTO notifications (notification_id, user_id, type, message, entity_id, entity_label) VALUES (?,?,?,?,?,?)`);
  db.transaction(() => {
    sls.forEach((sl: any) => {
      insertNotif.run(newUUID(), sl.user_id, 'SESSION_REQUEST',
        `📩 ${mentorName} has requested a ${typeLabel} session: "${message.trim().slice(0, 80)}"`,
        request_id, mentorName);
    });
  })();

  res.status(201).json({ message: 'Request submitted', request_id });
});

// ─── PUT /api/spiritual/session-requests/:id/approve — SL approves ────────────
router.put('/session-requests/:id/approve', requireSL, (req: AuthRequest, res: Response) => {
  const { session_date, topic } = req.body;
  if (!session_date) { res.status(400).json({ error: 'Session date is required to approve' }); return; }
  if (!topic?.trim()) { res.status(400).json({ error: 'Session topic/title is required' }); return; }

  const sr = db.prepare('SELECT * FROM session_requests WHERE request_id=?').get(req.params.id) as any;
  if (!sr) { res.status(404).json({ error: 'Request not found' }); return; }
  if (sr.status !== 'PENDING') { res.status(400).json({ error: 'Request is no longer pending' }); return; }

  // 2-month cap
  const maxDate = new Date(Date.now() + 60 * 86400000).toISOString().slice(0, 10);
  if (session_date > maxDate) {
    res.status(400).json({ error: 'Session date cannot be more than 2 months in the future' }); return;
  }

  // Create the session
  const session_id = newUUID();
  const session_type = sr.request_type === 'ONE_ON_ONE_SL' ? 'ONE_ON_ONE_MENTOR' : 'SMALL_GROUP';
  const target_id = sr.request_type === 'ONE_ON_ONE_SL' ? sr.requested_by : null;
  const slName = (req.user as any)?.full_name || 'Spiritual Leader';

  db.prepare(`INSERT INTO spiritual_sessions (session_id, session_date, topic, session_type, target_id, created_by) VALUES (?,?,?,?,?,?)`)
    .run(session_id, session_date, topic.trim(), session_type, target_id, req.user!.user_id);

  const notifyMentor = db.prepare(`INSERT INTO notifications (notification_id, user_id, type, message, entity_id, entity_label) VALUES (?,?,?,?,?,?)`);

  if (sr.request_type === 'ONE_ON_ONE_SL') {
    // 1:1 between SL and mentor
    db.prepare("INSERT OR IGNORE INTO spiritual_mentor_attendance (session_id, mentor_id, is_present, rsvp_status) VALUES (?,?,0,'ACCEPTED')")
      .run(session_id, sr.requested_by);
    notifyMentor.run(newUUID(), sr.requested_by, 'SESSION_REQUEST_APPROVED',
      `✅ Your session request was approved! 1:1 session with ${slName}: "${topic.trim()}" on ${session_date}.`,
      session_id, topic.trim());
  } else {
    // 1:1 for kid(s) - small group session
    const kidIds: string[] = sr.kid_ids ? JSON.parse(sr.kid_ids) : [];
    const insKid = db.prepare('INSERT OR IGNORE INTO spiritual_attendance (session_id, kid_id, is_present) VALUES (?,?,0)');
    db.transaction(() => { kidIds.forEach((kid_id: string) => insKid.run(session_id, kid_id)); })();
    // Add requesting mentor
    db.prepare("INSERT OR IGNORE INTO spiritual_mentor_attendance (session_id, mentor_id, is_present, rsvp_status) VALUES (?,?,0,'ACCEPTED')")
      .run(session_id, sr.requested_by);
    notifyMentor.run(newUUID(), sr.requested_by, 'SESSION_REQUEST_APPROVED',
      `✅ Your session request was approved! Session: "${topic.trim()}" on ${session_date}. Your teens have been added.`,
      session_id, topic.trim());
  }

  db.prepare(`UPDATE session_requests SET status='APPROVED', reviewed_by=?, reviewed_at=datetime('now'), approved_session_id=?, updated_at=datetime('now') WHERE request_id=?`)
    .run(req.user!.full_name, session_id, req.params.id);

  res.json({ message: 'Request approved and session created', session_id });
});

// ─── PUT /api/spiritual/session-requests/:id/deny — SL denies ────────────────
router.put('/session-requests/:id/deny', requireSL, (req: AuthRequest, res: Response) => {
  const { review_note } = req.body;
  const sr = db.prepare('SELECT * FROM session_requests WHERE request_id=?').get(req.params.id) as any;
  if (!sr) { res.status(404).json({ error: 'Request not found' }); return; }
  if (sr.status !== 'PENDING') { res.status(400).json({ error: 'Request is no longer pending' }); return; }

  db.prepare(`UPDATE session_requests SET status='DENIED', reviewed_by=?, reviewed_at=datetime('now'), review_note=?, updated_at=datetime('now') WHERE request_id=?`)
    .run(req.user!.full_name, review_note?.trim() || null, req.params.id);

  const slName = (req.user as any)?.full_name || 'Spiritual Leader';
  db.prepare(`INSERT INTO notifications (notification_id, user_id, type, message, entity_id, entity_label) VALUES (?,?,?,?,?,?)`)
    .run(newUUID(), sr.requested_by, 'SESSION_REQUEST_DENIED',
      `❌ Your session request was not approved by ${slName}.${review_note ? ' Note: ' + review_note.trim() : ''}`,
      req.params.id, 'Session Request');

  res.json({ message: 'Request denied' });
});

export default router;

