import { Router, Response } from 'express';
import db from '../database/db';
import { authenticate, requireAdmin, AuthRequest } from '../middleware/auth';
import { generateRegistrationId, newUUID, normalizePhone, calcAge } from '../utils/helpers';

const router = Router();
router.use(authenticate);

// ─── Helpers ──────────────────────────────────────────────────────────────────
function isMentorAssigned(mentor_id: string, kid_id: string): boolean {
  return !!db.prepare('SELECT 1 FROM kid_mentor WHERE mentor_id=? AND kid_id=?').get(mentor_id, kid_id);
}

function validatePhone(raw: string): boolean {
  return /^\d{10}$/.test(raw.replace(/\D/g, ''));
}

function getFullKid(kid_id: string) {
  const kid = db.prepare('SELECT * FROM kids WHERE kid_id = ? AND is_deleted = 0').get(kid_id) as any;
  if (!kid) return null;
  const parents = db.prepare(`
    SELECT p.* FROM parents p
    JOIN kid_parent kp ON kp.parent_id = p.parent_id WHERE kp.kid_id = ?
  `).all(kid_id);
  const hobbies = db.prepare(`
    SELECT h.hobby_id, h.name FROM hobbies h
    JOIN kid_hobbies kh ON kh.hobby_id = h.hobby_id WHERE kh.kid_id = ?
  `).all(kid_id);
  const interests = db.prepare(`
    SELECT i.interest_id, i.name FROM interests i
    JOIN kid_interests ki ON ki.interest_id = i.interest_id WHERE ki.kid_id = ?
  `).all(kid_id);
  const mentor = db.prepare(`
    SELECT u.user_id, u.full_name, u.username FROM users u
    JOIN kid_mentor km ON km.mentor_id = u.user_id WHERE km.kid_id = ?
  `).get(kid_id);
  // creator_role: used by frontend to conditionally show "Request Changes" button
  let creator_role: string | null = null;
  if (kid.created_by_user_id) {
    const creator = db.prepare('SELECT role FROM users WHERE user_id=?').get(kid.created_by_user_id) as any;
    if (creator) creator_role = creator.role;
  }
  return { ...kid, parents, hobbies, interests, mentor, creator_role };
}

// ─── MUST come before /:id ────────────────────────────────────────────────────

router.get('/meta/hobbies', (_req, res) => {
  res.json(db.prepare('SELECT * FROM hobbies ORDER BY name').all());
});

router.get('/meta/interests', (_req, res) => {
  res.json(db.prepare('SELECT * FROM interests ORDER BY name').all());
});

// GET /api/kids/pending-submissions/count  — admin: count of PENDING
router.get('/pending-submissions/count', requireAdmin, (_req, res) => {
  const row = db.prepare("SELECT COUNT(*) as count FROM kids WHERE submission_status='PENDING' AND is_deleted=0").get() as any;
  res.json({ count: row.count });
});

// GET /api/kids/pending-submissions  — admin: list all PENDING
router.get('/pending-submissions', requireAdmin, (_req, res) => {
  const kids = db.prepare(`
    SELECT k.*, u.full_name as submitter_name, u.username as submitter_username
    FROM kids k
    LEFT JOIN users u ON u.user_id = k.submitted_by
    WHERE k.submission_status = 'PENDING' AND k.is_deleted = 0
    ORDER BY k.submitted_at DESC
  `).all() as any[];
  const result = kids.map((k: any) => {
    const parents = db.prepare(`
      SELECT p.full_name, p.relationship, p.phone_normalized FROM parents p
      JOIN kid_parent kp ON kp.parent_id = p.parent_id WHERE kp.kid_id = ?
    `).all(k.kid_id);
    return { ...k, parents };
  });
  res.json(result);
});

// GET /api/kids/my-denied-count  — DATA_ENTRY: count of DENIED records
router.get('/my-denied-count', (req: AuthRequest, res: Response) => {
  const role = req.user?.role;
  if (role !== 'DATA_ENTRY' && role !== 'SUB') { res.json({ count: 0 }); return; }
  const row = db.prepare(
    "SELECT COUNT(*) as count FROM kids WHERE created_by_user_id=? AND submission_status='DENIED' AND is_deleted=0 AND mentor_edit_user_id IS NULL"
  ).get(req.user!.user_id) as any;
  res.json({ count: row.count });
});

// GET /api/kids/filter-meta  — dynamic filter options from approved+signed records
router.get('/filter-meta', (req: AuthRequest, res: Response) => {
  const role = req.user?.role;
  if (role === 'DATA_ENTRY' || role === 'SUB') { res.status(403).json({ error: 'Not authorised' }); return; }
  const base = "is_deleted=0 AND submission_status='APPROVED' AND is_signed=1";
  const ages = (db.prepare(`SELECT DISTINCT age_snapshot as v FROM kids WHERE ${base} AND age_snapshot IS NOT NULL ORDER BY age_snapshot`).all() as any[]).map((r: any) => r.v);
  const education_levels = (db.prepare(`SELECT DISTINCT education_level as v FROM kids WHERE ${base} AND education_level IS NOT NULL ORDER BY education_level`).all() as any[]).map((r: any) => r.v);
  const genders = (db.prepare(`SELECT DISTINCT gender as v FROM kids WHERE ${base} AND gender IS NOT NULL ORDER BY gender`).all() as any[]).map((r: any) => r.v);
  const schools = (db.prepare(`SELECT DISTINCT school_name as v FROM kids WHERE ${base} AND school_name IS NOT NULL ORDER BY school_name`).all() as any[]).map((r: any) => r.v);
  const hobbies = db.prepare(`SELECT DISTINCT h.hobby_id, h.name FROM hobbies h JOIN kid_hobbies kh ON kh.hobby_id=h.hobby_id JOIN kids k ON k.kid_id=kh.kid_id WHERE k.${base} ORDER BY h.name`).all();
  const interests = db.prepare(`SELECT DISTINCT i.interest_id, i.name FROM interests i JOIN kid_interests ki ON ki.interest_id=i.interest_id JOIN kids k ON k.kid_id=ki.kid_id WHERE k.${base} ORDER BY i.name`).all();
  res.json({ ages, education_levels, genders, schools, hobbies, interests });
});

// GET /api/kids/filter  — filtered search for admin, SL, mentor
router.get('/filter', (req: AuthRequest, res: Response) => {
  const role = req.user?.role;
  if (role === 'DATA_ENTRY' || role === 'SUB') {
    res.status(403).json({ error: 'Not authorised' }); return;
  }
  const { age_min, age_max, age, education_level, gender, school, interest_ids, ambition } = req.query as Record<string, string>;

  let baseWhere = "k.is_deleted=0 AND (k.submission_status='APPROVED' OR k.mentor_edit_user_id IS NOT NULL)";
  const params: any[] = [];

  if (age) { baseWhere += ' AND k.age_snapshot = ?'; params.push(parseInt(age)); }
  else {
    if (age_min) { baseWhere += ' AND k.age_snapshot >= ?'; params.push(parseInt(age_min)); }
    if (age_max) { baseWhere += ' AND k.age_snapshot <= ?'; params.push(parseInt(age_max)); }
  }
  if (gender) { baseWhere += ' AND k.gender = ?'; params.push(gender); }
  if (education_level) { baseWhere += ' AND k.education_level = ?'; params.push(education_level); }
  if (school) { baseWhere += ' AND lower(k.school_name) LIKE ?'; params.push(`%${school.toLowerCase()}%`); }
  if (ambition) { baseWhere += ' AND lower(k.ambition_goal) LIKE ?'; params.push(`%${ambition.toLowerCase()}%`); }

  let kids: any[];
  if (interest_ids) {
    const ids = interest_ids.split(',').map(Number).filter(n => !isNaN(n) && n > 0);
    if (ids.length > 0) {
      const placeholders = ids.map(() => '?').join(',');
      kids = db.prepare(`
        SELECT DISTINCT k.kid_id, k.registration_id, k.first_name, k.last_name,
               k.age_snapshot, k.education_level, k.school_name, k.phone_normalized, k.gender, k.created_at, k.photo_data
        FROM kids k
        JOIN kid_interests ki ON ki.kid_id = k.kid_id
        WHERE ${baseWhere} AND ki.interest_id IN (${placeholders})
        ORDER BY k.first_name, k.last_name LIMIT 200
      `).all(...params, ...ids) as any[];
    } else { kids = []; }
  } else {
    kids = db.prepare(`
      SELECT k.kid_id, k.registration_id, k.first_name, k.last_name,
             k.age_snapshot, k.education_level, k.school_name, k.phone_normalized, k.gender, k.created_at, k.photo_data
      FROM kids k WHERE ${baseWhere}
      ORDER BY k.first_name, k.last_name LIMIT 200
    `).all(...params) as any[];
  }

  if (role === 'MENTOR') {
    kids = kids.filter((k: any) => isMentorAssigned(req.user!.user_id, k.kid_id));
  }

  const result = kids.map((k: any) => {
    const parents = db.prepare(`
      SELECT p.full_name, p.relationship, p.phone_normalized FROM parents p
      JOIN kid_parent kp ON kp.parent_id = p.parent_id WHERE kp.kid_id = ?
    `).all(k.kid_id);
    const hobbies = (db.prepare(`
      SELECT h.name FROM hobbies h JOIN kid_hobbies kh ON kh.hobby_id = h.hobby_id WHERE kh.kid_id = ?
    `).all(k.kid_id) as any[]).map((h: any) => h.name);
    return { ...k, parents, hobbies };
  });
  res.json(result);
});

// GET /api/kids/search
router.get('/search', (req: AuthRequest, res: Response) => {
  const q = (req.query.q as string || '').trim();
  if (!q) { res.json([]); return; }

  const role = req.user?.role;
  const isDataEntry = role === 'DATA_ENTRY' || role === 'SUB';
  const isMentor = role === 'MENTOR';
  let kids: any[] = [];

  if (/^TC-\d{4}-\d+$/i.test(q)) {
    kids = db.prepare('SELECT * FROM kids WHERE registration_id = ? AND is_deleted = 0').all(q.toUpperCase());
  } else if (q.replace(/\D/g, '').length >= 7) {
    const digits = normalizePhone(q);
    kids = db.prepare('SELECT * FROM kids WHERE phone_normalized LIKE ? AND is_deleted = 0').all(`%${digits}%`);
  } else {
    const pattern = `%${q.toLowerCase()}%`;
    kids = db.prepare(`
      SELECT * FROM kids
      WHERE (lower(first_name) LIKE ? OR lower(last_name) LIKE ? OR lower(first_name || ' ' || last_name) LIKE ?)
        AND is_deleted = 0
    `).all(pattern, pattern, pattern);
  }

  if (isDataEntry) {
    // DATA_ENTRY: only see their own DRAFT and DENIED (PENDING is hidden)
    kids = kids.filter((k: any) =>
      k.created_by_user_id === req.user!.user_id &&
      ['DRAFT', 'DENIED'].includes(k.submission_status)
    );
  } else if (isMentor) {
    kids = kids.filter((k: any) =>
      isMentorAssigned(req.user!.user_id, k.kid_id) &&
      (k.submission_status === 'APPROVED' || k.mentor_edit_user_id === req.user!.user_id)
    );
  } else {
    // Admin / SL: show all APPROVED + records actively being edited by any mentor
    kids = kids.filter((k: any) => k.submission_status === 'APPROVED' || k.mentor_edit_user_id);
  }

  const results = kids.map((k: any) => {
    const parents = db.prepare(`
      SELECT p.full_name, p.relationship, p.phone_normalized FROM parents p
      JOIN kid_parent kp ON kp.parent_id = p.parent_id WHERE kp.kid_id = ?
    `).all(k.kid_id);
    const hobbies = (db.prepare(`
      SELECT h.name FROM hobbies h JOIN kid_hobbies kh ON kh.hobby_id = h.hobby_id WHERE kh.kid_id = ?
    `).all(k.kid_id) as any[]).map((h: any) => h.name);
    return { ...k, parents, hobbies };
  });
  res.json(results);
});

// GET /api/kids
router.get('/', (req: AuthRequest, res: Response) => {
  const page  = parseInt(req.query.page  as string) || 1;
  const limit = parseInt(req.query.limit as string) || 20;
  const offset = (page - 1) * limit;
  const role = req.user?.role;
  const isDataEntry = role === 'DATA_ENTRY' || role === 'SUB';
  const isMentor = role === 'MENTOR';

  let total: number;
  let kids: any[];

  if (isDataEntry) {
    // DATA_ENTRY can only see DRAFT and DENIED - PENDING disappears from their view
    total = (db.prepare(`
      SELECT COUNT(*) as cnt FROM kids
      WHERE created_by_user_id=? AND submission_status IN ('DRAFT','DENIED') AND is_deleted=0
    `).get(req.user!.user_id) as any).cnt;
    kids = db.prepare(`
      SELECT kid_id, registration_id, first_name, last_name, age_snapshot,
             education_level, school_name, phone_normalized, submission_status, submission_note, created_at
      FROM kids WHERE created_by_user_id=? AND submission_status IN ('DRAFT','DENIED') AND is_deleted=0
      ORDER BY
        CASE submission_status WHEN 'DENIED' THEN 0 ELSE 1 END,
        created_at DESC LIMIT ? OFFSET ?
    `).all(req.user!.user_id, limit, offset);
  } else if (isMentor) {
    total = (db.prepare(`
      SELECT COUNT(*) as cnt FROM kids k
      JOIN kid_mentor km ON km.kid_id = k.kid_id
      WHERE km.mentor_id=? AND k.is_deleted=0
        AND (k.submission_status='APPROVED' OR k.mentor_edit_user_id=?)
    `).get(req.user!.user_id, req.user!.user_id) as any).cnt;
    kids = db.prepare(`
      SELECT k.kid_id, k.registration_id, k.first_name, k.last_name, k.age_snapshot,
             k.education_level, k.school_name, k.grade_year, k.phone_normalized, k.created_at,
             k.submission_status, k.mentor_edit_user_id
      FROM kids k JOIN kid_mentor km ON km.kid_id = k.kid_id
      WHERE km.mentor_id=? AND k.is_deleted=0
        AND (k.submission_status='APPROVED' OR k.mentor_edit_user_id=?)
      ORDER BY k.created_at DESC LIMIT ? OFFSET ?
    `).all(req.user!.user_id, req.user!.user_id, limit, offset);
  } else {
    total = (db.prepare("SELECT COUNT(*) as cnt FROM kids WHERE is_deleted=0 AND (submission_status='APPROVED' OR mentor_edit_user_id IS NOT NULL)").get() as any).cnt;
    kids = db.prepare(`
      SELECT kid_id, registration_id, first_name, last_name, age_snapshot,
             education_level, school_name, grade_year, phone_normalized, created_at,
             submission_status, mentor_edit_user_id
      FROM kids WHERE is_deleted=0 AND (submission_status='APPROVED' OR mentor_edit_user_id IS NOT NULL)
      ORDER BY created_at DESC LIMIT ? OFFSET ?
    `).all(limit, offset);
  }

  res.json({ total, page, limit, data: kids });
});

// GET /api/kids/my-mentor-edits  — MUST be before /:id to avoid being shadowed
// (moved here from end of file)
router.get('/my-mentor-edits', (req: AuthRequest, res: Response) => {
  if (req.user?.role !== 'MENTOR') { res.json([]); return; }
  const kids = db.prepare(`
    SELECT kid_id, registration_id, first_name, last_name, age_snapshot, gender,
           education_level, submission_status, submission_note, updated_at
    FROM kids WHERE mentor_edit_user_id=? AND submission_status IN ('DRAFT','DENIED','PENDING') AND is_deleted=0
    ORDER BY CASE submission_status WHEN 'DENIED' THEN 0 WHEN 'DRAFT' THEN 1 ELSE 2 END, updated_at DESC
  `).all(req.user!.user_id) as any[];
  res.json(kids);
});

// GET /api/kids/my-mentor-edits/count  — MENTOR: denied count for navbar badge
router.get('/my-mentor-edits/count', (req: AuthRequest, res: Response) => {
  if (req.user?.role !== 'MENTOR') { res.json({ count: 0 }); return; }
  const row = db.prepare(
    "SELECT COUNT(*) as count FROM kids WHERE mentor_edit_user_id=? AND submission_status='DENIED' AND is_deleted=0"
  ).get(req.user!.user_id) as any;
  res.json({ count: row.count });
});

// GET /api/kids/:id
router.get('/:id', (req: AuthRequest, res: Response) => {
  const role = req.user?.role;
  const isMentor = role === 'MENTOR';
  const isDataEntry = role === 'DATA_ENTRY' || role === 'SUB';

  if (isMentor && !isMentorAssigned(req.user!.user_id, req.params.id)) {
    res.status(403).json({ error: 'You are not assigned to this student' }); return;
  }
  const kid = getFullKid(req.params.id);
  if (!kid) { res.status(404).json({ error: 'Not found' }); return; }

  if (isDataEntry) {
    // DATA_ENTRY can view their own DRAFT, DENIED, or PENDING records
    const allowed = ['DRAFT', 'DENIED', 'PENDING'];
    if (kid.created_by_user_id !== req.user!.user_id || !allowed.includes(kid.submission_status)) {
      res.status(403).json({ error: 'Not authorised to view this record' }); return;
    }
  } else if (isMentor) {
    // Mentor can view their assigned kid if APPROVED, or if they have active edit access (DRAFT/PENDING while editing)
    if (kid.submission_status !== 'APPROVED' && kid.mentor_edit_user_id !== req.user!.user_id) {
      res.status(403).json({ error: 'Record not yet approved' }); return;
    }
  } else if (role === 'SPIRITUAL_LEADER') {
    // SL can view APPROVED records even when unlocked/being-edited by mentor
    if (kid.submission_status !== 'APPROVED' && !kid.mentor_edit_user_id) {
      res.status(403).json({ error: 'Record not yet approved' }); return;
    }
  }
  res.json(kid);
});

// POST /api/kids
router.post('/', (req: AuthRequest, res: Response) => {
  const role = req.user?.role;
  if (role !== 'ADMIN' && role !== 'DATA_ENTRY' && role !== 'SUB') {
    res.status(403).json({ error: 'Not authorised to add registrations' }); return;
  }

  const { kid, parents: parentList = [], hobby_ids = [], interest_ids = [], photo_data: photoData } = req.body;

  if (!kid?.first_name?.trim())   { res.status(400).json({ error: 'First name is required' }); return; }
  // last_name is optional
  if (!kid?.dob)                  { res.status(400).json({ error: 'Date of birth is required' }); return; }
  if (!kid?.gender)               { res.status(400).json({ error: 'Gender is required' }); return; }
  if (!kid?.education_level)      { res.status(400).json({ error: 'Education level is required' }); return; }
  if (!kid?.phone?.trim())        { res.status(400).json({ error: 'Phone number is required' }); return; }
  if (!validatePhone(kid.phone))  { res.status(400).json({ error: 'Phone number must be exactly 10 digits' }); return; }

  // Alpha-only for names
  const alphaOnly = /^[a-zA-Z ]+$/;
  if (!alphaOnly.test(kid.first_name.trim())) { res.status(400).json({ error: 'First name must contain letters and spaces only' }); return; }
  if (kid.last_name?.trim() && !alphaOnly.test(kid.last_name.trim())) { res.status(400).json({ error: 'Last name must contain letters and spaces only' }); return; }
  for (const p of parentList) {
    if (p.full_name?.trim() && !alphaOnly.test(p.full_name.trim())) {
      res.status(400).json({ error: 'Parent full name must contain letters and spaces only' }); return;
    }
  }

  const age = calcAge(kid.dob);
  if (age < 13) { res.status(400).json({ error: 'Teen must be at least 13 years old to register' }); return; }
  if (age > 21) { res.status(400).json({ error: 'Registration is only for teens aged 13–21 years' }); return; }

  for (const p of parentList) {
    if (p.full_name && p.phone && !validatePhone(p.phone)) {
      res.status(400).json({ error: `Parent "${p.full_name}": phone must be exactly 10 digits` }); return;
    }
    if (p.emergency_contact_phone && !validatePhone(p.emergency_contact_phone)) {
      res.status(400).json({ error: `Parent "${p.full_name}": emergency contact phone must be exactly 10 digits` }); return;
    }
  }

  // Duplicate check: same phone + same full name
  const phoneNorm = normalizePhone(kid.phone);
  const kidDup = db.prepare(`
    SELECT 1 FROM kids
    WHERE phone_normalized = ? AND lower(first_name) = lower(?)
      AND lower(coalesce(last_name,'')) = lower(?) AND is_deleted = 0
  `).get(phoneNorm, kid.first_name.trim(), (kid.last_name?.trim() || ''));
  if (kidDup) { res.status(409).json({ error: 'Duplicate entry: A teen with the same name and phone number already exists' }); return; }

  const isAdminCreate = role === 'ADMIN';

  const run = db.transaction(() => {
    const kid_id = newUUID();
    const registration_id = generateRegistrationId();
    const phone = normalizePhone(kid.phone);
    const submission_status = isAdminCreate ? 'APPROVED' : 'DRAFT';
    const signerName = isAdminCreate ? (req.user?.full_name || 'Admin') : null;

    db.prepare(`
      INSERT INTO kids (
        kid_id, registration_id, first_name, last_name, dob, age_snapshot, gender,
        education_level, school_name, grade_year, phone_normalized, address,
        ambition_goal, additional_comments,
        baptism_confirmed, consent_participate,
        submission_status, is_signed, signed_at, signed_by, created_by_user_id, photo_data
      ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    `).run(
      kid_id, registration_id,
      kid.first_name.trim(), kid.last_name?.trim() || '', kid.dob, age,
      kid.gender,
      kid.education_level, kid.school_name || null, kid.grade_year || null,
      phone, kid.address ? kid.address.slice(0, 250) : null,
      kid.ambition_goal || null, kid.additional_comments || null,
      kid.baptism_confirmed ? 1 : 0,
      kid.consent_participate ? 1 : 0,
      submission_status,
      isAdminCreate ? 1 : 0,
      isAdminCreate ? new Date().toISOString() : null,
      signerName,
      req.user?.user_id || null,
      photoData || null
    );

    const iKH = db.prepare('INSERT OR IGNORE INTO kid_hobbies (kid_id, hobby_id) VALUES (?,?)');
    for (const hid of hobby_ids) iKH.run(kid_id, hid);

    const iKI = db.prepare('INSERT OR IGNORE INTO kid_interests (kid_id, interest_id) VALUES (?,?)');
    for (const iid of interest_ids) iKI.run(kid_id, iid);

    for (const p of parentList) {
      if (!p.full_name?.trim()) continue;
      const parent_id = newUUID();
      db.prepare(`
        INSERT INTO parents (parent_id, full_name, relationship, phone_normalized, email,
          occupation, education, expectation_text, emergency_contact_name, emergency_contact_phone,
          preferred_contact, baptism_confirmed)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
      `).run(
        parent_id, p.full_name.trim(),
        p.relationship || 'Guardian',
        p.phone ? normalizePhone(p.phone) : null,
        p.email || null, p.occupation || null, p.education || null,
        p.expectation_text || null,
        p.emergency_contact_name || null,
        p.emergency_contact_phone ? normalizePhone(p.emergency_contact_phone) : null,
        p.preferred_contact || null,
        p.baptism_confirmed ? 1 : 0
      );
      db.prepare('INSERT INTO kid_parent (kid_id, parent_id) VALUES (?,?)').run(kid_id, parent_id);
    }

    const mentor_id = req.body.mentor_id || null;
    if (mentor_id && role === 'ADMIN') {
      const mentor = db.prepare("SELECT 1 FROM users WHERE user_id=? AND role='MENTOR' AND is_active=1").get(mentor_id);
      if (mentor) {
        db.prepare("INSERT OR IGNORE INTO kid_mentor (kid_id, mentor_id, assigned_at, assigned_by) VALUES (?,?,datetime('now'),?)")
          .run(kid_id, mentor_id, req.user?.user_id);
      }
    }

    return { kid_id, registration_id, submission_status, is_signed: isAdminCreate ? 1 : 0 };
  });

  try {
    const result = run();
    res.status(201).json({ message: isAdminCreate ? 'Registration approved and signed' : 'Registration saved', ...result });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// PUT /api/kids/:id
router.put('/:id', (req: AuthRequest, res: Response) => {
  const role = req.user?.role;
  const allowedRoles = ['ADMIN', 'DATA_ENTRY', 'SUB', 'MENTOR'];
  if (!allowedRoles.includes(role || '')) {
    res.status(403).json({ error: 'Not authorised to edit registrations' }); return;
  }

  const { kid, hobby_ids, interest_ids } = req.body;
  const { id } = req.params;
  const existing = db.prepare('SELECT * FROM kids WHERE kid_id = ? AND is_deleted = 0').get(id) as any;
  if (!existing) { res.status(404).json({ error: 'Not found' }); return; }

  if (role === 'MENTOR') {
    if (!isMentorAssigned(req.user!.user_id, id)) {
      res.status(403).json({ error: 'You are not assigned to this teen' }); return;
    }
    if (existing.mentor_edit_user_id !== req.user!.user_id) {
      res.status(403).json({ error: 'No edit access granted. Request edit access first.' }); return;
    }
    if (existing.is_signed) {
      res.status(403).json({ error: 'Record is locked' }); return;
    }
  } else if (role !== 'ADMIN') {
    if (existing.created_by_user_id !== req.user!.user_id) {
      res.status(403).json({ error: 'Not authorised to edit this record' }); return;
    }
    if (!['DRAFT', 'DENIED'].includes(existing.submission_status)) {
      res.status(403).json({ error: 'Record is pending or approved — cannot edit' }); return;
    }
    if (existing.is_signed) {
      res.status(403).json({ error: 'Record is locked' }); return;
    }
  }

  if (!kid?.first_name?.trim()) { res.status(400).json({ error: 'First name is required' }); return; }
  // last_name is optional

  const alphaOnlyPut = /^[a-zA-Z ]+$/;
  if (!alphaOnlyPut.test(kid.first_name.trim())) { res.status(400).json({ error: 'First name must contain letters and spaces only' }); return; }
  if (kid.last_name?.trim() && !alphaOnlyPut.test(kid.last_name.trim())) { res.status(400).json({ error: 'Last name must contain letters and spaces only' }); return; }
  if (!kid?.dob)                { res.status(400).json({ error: 'Date of birth is required' }); return; }
  if (!kid?.gender)             { res.status(400).json({ error: 'Gender is required' }); return; }
  if (!kid?.education_level)    { res.status(400).json({ error: 'Education level is required' }); return; }
  if (kid.phone && !validatePhone(kid.phone)) {
    res.status(400).json({ error: 'Phone number must be exactly 10 digits' }); return;
  }

  // Duplicate check: same phone + same full name (excluding self)
  if (kid.phone) {
    const phoneNormPut = normalizePhone(kid.phone);
    const dupPut = db.prepare(`
      SELECT 1 FROM kids
      WHERE phone_normalized = ? AND lower(first_name) = lower(?)
        AND lower(coalesce(last_name,'')) = lower(?) AND is_deleted = 0 AND kid_id != ?
    `).get(phoneNormPut, kid.first_name.trim(), (kid.last_name?.trim() || ''), id);
    if (dupPut) { res.status(409).json({ error: 'Duplicate entry: A teen with the same name and phone number already exists' }); return; }
  }
  const age = calcAge(kid.dob);
  if (age < 13) { res.status(400).json({ error: 'Teen must be at least 13 years old' }); return; }
  if (age > 21) { res.status(400).json({ error: 'Registration is only for teens aged 13–21 years' }); return; }

  const run = db.transaction(() => {
    const phone = kid.phone ? normalizePhone(kid.phone) : null;
    // ADMIN save: auto-approve + auto-sign
    // MENTOR/DATA_ENTRY editing a DENIED record resets it to DRAFT
    const newStatus =
      (role === 'ADMIN') ? 'APPROVED' :
      (role === 'MENTOR') ? 'DRAFT' :
      (existing.submission_status === 'DENIED') ? 'DRAFT' :
      existing.submission_status;
    const adminSignerName = role === 'ADMIN' ? (req.user!.full_name || 'Admin') : null;

    if (role === 'ADMIN') {
      db.prepare(`
        UPDATE kids SET
          first_name=?, last_name=?, dob=?, age_snapshot=?, gender=?,
          education_level=?, school_name=?, grade_year=?, phone_normalized=?, address=?,
          ambition_goal=?, additional_comments=?,
          baptism_confirmed=?, consent_participate=?,
          submission_status='APPROVED', submission_note=NULL,
          is_signed=1, signed_at=datetime('now'), signed_by=?,
          updated_at=datetime('now')
        WHERE kid_id=?
      `).run(
        kid.first_name.trim(), kid.last_name?.trim() || '', kid.dob, age, kid.gender || null,
        kid.education_level || null, kid.school_name || null, kid.grade_year || null,
        phone, kid.address ? kid.address.slice(0, 250) : null,
        kid.ambition_goal || null, kid.additional_comments || null,
        kid.baptism_confirmed ? 1 : 0, kid.consent_participate ? 1 : 0,
        adminSignerName, id
      );
    } else {
      db.prepare(`
        UPDATE kids SET
          first_name=?, last_name=?, dob=?, age_snapshot=?, gender=?,
          education_level=?, school_name=?, grade_year=?, phone_normalized=?, address=?,
          ambition_goal=?, additional_comments=?,
          baptism_confirmed=?, consent_participate=?,
          submission_status=?, submission_note=NULL,
          updated_at=datetime('now')
        WHERE kid_id=?
      `).run(
        kid.first_name.trim(), kid.last_name?.trim() || '', kid.dob, age, kid.gender || null,
        kid.education_level || null, kid.school_name || null, kid.grade_year || null,
        phone, kid.address ? kid.address.slice(0, 250) : null,
        kid.ambition_goal || null, kid.additional_comments || null,
        kid.baptism_confirmed ? 1 : 0, kid.consent_participate ? 1 : 0,
        newStatus, id
      );
    }
    if (Array.isArray(hobby_ids)) {
      db.prepare('DELETE FROM kid_hobbies WHERE kid_id = ?').run(id);
      hobby_ids.forEach((hid: number) => db.prepare('INSERT OR IGNORE INTO kid_hobbies (kid_id, hobby_id) VALUES (?,?)').run(id, hid));
    }
    if (Array.isArray(interest_ids)) {
      db.prepare('DELETE FROM kid_interests WHERE kid_id = ?').run(id);
      interest_ids.forEach((iid: number) => db.prepare('INSERT OR IGNORE INTO kid_interests (kid_id, interest_id) VALUES (?,?)').run(id, iid));
    }
    if ('mentor_id' in req.body && role === 'ADMIN') {
      db.prepare('DELETE FROM kid_mentor WHERE kid_id = ?').run(id);
      const new_mentor_id = req.body.mentor_id;
      if (new_mentor_id) {
        const mentor = db.prepare("SELECT 1 FROM users WHERE user_id=? AND role='MENTOR' AND is_active=1").get(new_mentor_id);
        if (mentor) {
          db.prepare("INSERT INTO kid_mentor (kid_id, mentor_id, assigned_at, assigned_by) VALUES (?,?,datetime('now'),?)")
            .run(id, new_mentor_id, req.user?.user_id);
        }
      }
    }
  });

  try {
    run();
    res.json({ message: role === 'ADMIN' ? 'Record approved and signed' : 'Updated successfully' });
  }
  catch (e: any) { res.status(500).json({ error: e.message }); }
});

// POST /api/kids/:id/submit — submit DRAFT/DENIED (DATA_ENTRY or MENTOR)
router.post('/:id/submit', (req: AuthRequest, res: Response) => {
  const role = req.user?.role;
  const rec = db.prepare('SELECT * FROM kids WHERE kid_id=? AND is_deleted=0').get(req.params.id) as any;
  if (!rec) { res.status(404).json({ error: 'Not found' }); return; }

  if (role === 'MENTOR') {
    if (rec.mentor_edit_user_id !== req.user!.user_id) {
      res.status(403).json({ error: 'Not authorised to submit this record' }); return;
    }
  } else if (role !== 'DATA_ENTRY' && role !== 'SUB' && role !== 'ADMIN') {
    res.status(403).json({ error: 'Not authorised' }); return;
  } else if (role !== 'ADMIN' && rec.created_by_user_id !== req.user!.user_id) {
    res.status(403).json({ error: 'Not authorised to submit this record' }); return;
  }
  if (!['DRAFT', 'DENIED'].includes(rec.submission_status)) {
    res.status(400).json({ error: `Cannot submit: current status is ${rec.submission_status}` }); return;
  }
  db.prepare(`UPDATE kids SET submission_status='PENDING', submission_note=NULL, submitted_at=datetime('now'), submitted_by=? WHERE kid_id=? AND submission_status IN ('DRAFT','DENIED')`).run(req.user!.user_id, req.params.id);
  res.json({ message: 'Submitted for admin approval' });
});

// POST /api/kids/:id/approve-submission  — ADMIN approves + auto-signs
router.post('/:id/approve-submission', requireAdmin, (req: AuthRequest, res: Response) => {
  const rec = db.prepare('SELECT * FROM kids WHERE kid_id=? AND is_deleted=0').get(req.params.id) as any;
  if (!rec) { res.status(404).json({ error: 'Not found' }); return; }
  if (rec.submission_status !== 'PENDING') {
    res.status(400).json({ error: `Record is ${rec.submission_status.toLowerCase()}, not pending` }); return;
  }
  const mentorEditUserId = rec.mentor_edit_user_id; // save before clearing
  db.prepare(`UPDATE kids SET submission_status='APPROVED', submission_note=NULL, is_signed=1, signed_at=datetime('now'), signed_by=?, mentor_edit_user_id=NULL, updated_at=datetime('now') WHERE kid_id=?`)
    .run(req.user!.full_name || 'Admin', req.params.id);

  // Notify mentor if this was a mentor-originated edit
  if (mentorEditUserId) {
    const kidName = `${rec.first_name} ${rec.last_name || ''}`.trim();
    db.prepare(`INSERT INTO notifications (notification_id, user_id, type, message, entity_id, entity_label) VALUES (?,?,?,?,?,?)`)
      .run(newUUID(), mentorEditUserId, 'EDIT_SUBMISSION_APPROVED',
        `✅ Your edited record for "${kidName}" has been approved and is now locked. Data is up to date.`,
        rec.kid_id, kidName);
  }

  res.json({ message: 'Registration approved and signed' });
});

// POST /api/kids/approve-batch  — ADMIN approves multiple PENDING records at once
router.post('/approve-batch', requireAdmin, (req: AuthRequest, res: Response) => {
  const { kid_ids } = req.body;
  if (!Array.isArray(kid_ids) || kid_ids.length === 0) {
    res.status(400).json({ error: 'kid_ids array is required' }); return;
  }
  const signerName = req.user!.full_name || 'Admin';
  const update = db.transaction(() => {
    let count = 0;
    for (const kid_id of kid_ids) {
      const recBatch = db.prepare("SELECT first_name, last_name, mentor_edit_user_id FROM kids WHERE kid_id=? AND submission_status='PENDING' AND is_deleted=0").get(kid_id) as any;
      if (!recBatch) continue;
      const r = db.prepare(`
        UPDATE kids SET submission_status='APPROVED', submission_note=NULL,
          is_signed=1, signed_at=datetime('now'), signed_by=?,
          mentor_edit_user_id=NULL, updated_at=datetime('now')
        WHERE kid_id=? AND submission_status='PENDING' AND is_deleted=0
      `).run(signerName, kid_id);
      if (r.changes > 0) {
        count++;
        if (recBatch.mentor_edit_user_id) {
          const kidNameBatch = `${recBatch.first_name} ${recBatch.last_name || ''}`.trim();
          db.prepare(`INSERT INTO notifications (notification_id, user_id, type, message, entity_id, entity_label) VALUES (?,?,?,?,?,?)`)
            .run(newUUID(), recBatch.mentor_edit_user_id, 'EDIT_SUBMISSION_APPROVED',
              `✅ Your edited record for "${kidNameBatch}" has been approved and is now locked.`,
              kid_id, kidNameBatch);
        }
      }
    }
    return count;
  });
  const approved = update();
  res.json({ approved, message: `${approved} registration(s) approved and signed` });
});
// POST /api/kids/:id/deny-submission  — ADMIN denies with reason
router.post('/:id/deny-submission', requireAdmin, (req: AuthRequest, res: Response) => {
  const { note } = req.body;
  if (!note?.trim()) { res.status(400).json({ error: 'Denial reason is required' }); return; }
  const rec = db.prepare('SELECT * FROM kids WHERE kid_id=? AND is_deleted=0').get(req.params.id) as any;
  if (!rec) { res.status(404).json({ error: 'Not found' }); return; }
  if (rec.submission_status !== 'PENDING') {
    res.status(400).json({ error: `Record is ${rec.submission_status.toLowerCase()}, not pending` }); return;
  }
  db.prepare(`UPDATE kids SET submission_status='DENIED', submission_note=?, updated_at=datetime('now') WHERE kid_id=?`)
    .run(note.trim(), req.params.id);
  res.json({ message: 'Registration denied' });
});

// POST /api/kids/submit-all — submit ALL DRAFT+DENIED records (DATA_ENTRY or MENTOR)
router.post('/submit-all', (req: AuthRequest, res: Response) => {
  const role = req.user?.role;
  let records: any[];

  if (role === 'MENTOR') {
    records = db.prepare(
      "SELECT kid_id FROM kids WHERE mentor_edit_user_id=? AND submission_status IN ('DRAFT','DENIED') AND is_deleted=0"
    ).all(req.user!.user_id) as any[];
  } else if (role === 'DATA_ENTRY' || role === 'SUB' || role === 'ADMIN') {
    records = db.prepare(
      "SELECT kid_id FROM kids WHERE created_by_user_id=? AND submission_status IN ('DRAFT','DENIED') AND is_deleted=0"
    ).all(req.user!.user_id) as any[];
  } else {
    res.status(403).json({ error: 'Not authorised' }); return;
  }

  if (records.length === 0) { res.json({ submitted: 0, message: 'No records to submit' }); return; }

  const stmt = db.prepare(`UPDATE kids SET submission_status='PENDING', submission_note=NULL, submitted_at=datetime('now'), submitted_by=? WHERE kid_id=? AND submission_status IN ('DRAFT','DENIED')`);
  const update = db.transaction(() => { let c2 = 0; for (const d of records) { stmt.run(req.user!.user_id, d.kid_id); c2++; } return c2; });
  const submitted = update();
  res.json({ submitted, message: `${submitted} registration(s) submitted for approval` });
});

// POST /api/kids/:id/sign  — ADMIN only
router.post('/:id/sign', requireAdmin, (req: AuthRequest, res: Response) => {
  const rec = db.prepare('SELECT * FROM kids WHERE kid_id=? AND is_deleted=0').get(req.params.id) as any;
  if (!rec) { res.status(404).json({ error: 'Not found' }); return; }
  if (rec.is_signed) { res.status(400).json({ error: 'Record already signed' }); return; }
  db.prepare(`UPDATE kids SET is_signed=1, signed_at=datetime('now'), signed_by=? WHERE kid_id=?`)
    .run(req.user!.full_name, req.params.id);
  res.json({ message: 'Record signed and locked' });
});

// POST /api/kids/:id/unlock  — ADMIN only
router.post('/:id/unlock', requireAdmin, (req: AuthRequest, res: Response) => {
  const rec = db.prepare('SELECT * FROM kids WHERE kid_id=? AND is_deleted=0').get(req.params.id) as any;
  if (!rec) { res.status(404).json({ error: 'Not found' }); return; }
  db.prepare(`UPDATE kids SET is_signed=0, signed_at=NULL, signed_by=NULL WHERE kid_id=?`).run(req.params.id);
  res.json({ message: 'Record unlocked for editing' });
});

// POST /api/kids/:id/request-changes  — ADMIN sends approved record back for corrections
router.post('/:id/request-changes', requireAdmin, (req: AuthRequest, res: Response) => {
  const { note } = req.body;
  if (!note?.trim()) { res.status(400).json({ error: 'Reason for changes is required' }); return; }
  const rec = db.prepare('SELECT * FROM kids WHERE kid_id=? AND is_deleted=0').get(req.params.id) as any;
  if (!rec) { res.status(404).json({ error: 'Not found' }); return; }
  if (!rec.created_by_user_id) {
    res.status(400).json({ error: 'Cannot request changes — original creator unknown' }); return;
  }
  // Set back to DENIED so the original creator sees it and can edit/resubmit
  db.prepare(`
    UPDATE kids SET submission_status='DENIED', submission_note=?, is_signed=0,
      signed_at=NULL, signed_by=NULL, updated_at=datetime('now')
    WHERE kid_id=?
  `).run(note.trim(), req.params.id);
  res.json({ message: 'Changes requested — record sent back to original creator' });
});

// DELETE /api/kids/:id — ADMIN only (soft delete)
router.delete('/:id', requireAdmin, (req: AuthRequest, res: Response) => {
  const result = db.prepare(
    "UPDATE kids SET is_deleted=1, updated_at=datetime('now') WHERE kid_id=? AND is_deleted=0"
  ).run(req.params.id);
  if (result.changes === 0) { res.status(404).json({ error: 'Not found' }); return; }
  res.json({ message: 'Record deleted (soft delete)' });
});

// PUT /api/kids/:id/photo — upload or replace a kid's photo
// Rules: if no photo yet → any authorised editor can upload
//        if photo exists → ADMIN only can replace
//        signed records → same rules still apply (photo is separate from record data)
router.put('/:id/photo', (req: AuthRequest, res: Response) => {
  const role = req.user?.role;
  if (!role || role === 'SUB') { res.status(403).json({ error: 'Not authorised' }); return; }

  const rec = db.prepare('SELECT * FROM kids WHERE kid_id=? AND is_deleted=0').get(req.params.id) as any;
  if (!rec) { res.status(404).json({ error: 'Not found' }); return; }

  // MENTOR: must be assigned to this kid
  if (role === 'MENTOR' && !isMentorAssigned(req.user!.user_id, req.params.id)) {
    res.status(403).json({ error: 'Not authorised: you are not assigned to this teen' }); return;
  }

  // If photo already exists, only ADMIN can replace
  if (rec.photo_data && role !== 'ADMIN') {
    res.status(403).json({ error: 'A photo already exists. Only the admin can replace it.' }); return;
  }

  const { photo_data } = req.body;
  if (!photo_data || typeof photo_data !== 'string') {
    res.status(400).json({ error: 'photo_data is required' }); return;
  }

  // Validate: must be a jpeg or png data URL
  if (!photo_data.startsWith('data:image/jpeg;base64,') && !photo_data.startsWith('data:image/png;base64,')) {
    res.status(400).json({ error: 'Only JPEG and PNG images are allowed' }); return;
  }

  // Validate size: base64 string ≤ 280,000 chars (≈ 200 KB raw file)
  if (photo_data.length > 280000) {
    res.status(400).json({ error: 'Photo is too large. Maximum allowed size is 200 KB.' }); return;
  }

  db.prepare("UPDATE kids SET photo_data=?, updated_at=datetime('now') WHERE kid_id=?")
    .run(photo_data, req.params.id);
  res.json({ message: 'Photo saved successfully' });
});

// DELETE /api/kids/:id/photo — ADMIN only, removes photo
router.delete('/:id/photo', requireAdmin, (req: AuthRequest, res: Response) => {
  const rec = db.prepare('SELECT kid_id FROM kids WHERE kid_id=? AND is_deleted=0').get(req.params.id) as any;
  if (!rec) { res.status(404).json({ error: 'Not found' }); return; }
  db.prepare("UPDATE kids SET photo_data=NULL, updated_at=datetime('now') WHERE kid_id=?")
    .run(req.params.id);
  res.json({ message: 'Photo removed' });
});

export default router;
