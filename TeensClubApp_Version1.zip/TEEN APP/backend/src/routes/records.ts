import { Router, Response } from 'express';
import { authenticate, AuthRequest } from '../middleware/auth';
import db from '../database/db';

const router = Router();
router.use(authenticate);

// ─── helpers ─────────────────────────────────────────────────────────────────
function attendanceStats(rows: any[]) {
  const total   = rows.length;
  const present = rows.filter(r => r.is_present).length;
  const absent  = total - present;
  const pct     = total > 0 ? Math.round((present / total) * 100) : 0;

  // monthly breakdown  { 'YYYY-MM': { total, present } }
  const monthly: Record<string, { total: number; present: number }> = {};
  for (const r of rows) {
    const month = (r.session_date as string).slice(0, 7);
    if (!monthly[month]) monthly[month] = { total: 0, present: 0 };
    monthly[month].total++;
    if (r.is_present) monthly[month].present++;
  }

  return { total, present, absent, pct, monthly };
}

// ══════════════════════════════════════════════════════════════════════════════
// GET /records/kids-list     — all approved kids (for dropdowns)
// ══════════════════════════════════════════════════════════════════════════════
router.get('/kids-list', (req: AuthRequest, res: Response): void => {
  const user = req.user!;
  const allowed = ['ADMIN', 'SPIRITUAL_LEADER', 'MENTOR'];
  if (!allowed.includes(user.role)) { res.status(403).json({ error: 'Access denied' }); return; }

  let rows: any[];
  if (user.role === 'MENTOR') {
    // mentors only see their assigned kids
    rows = db.prepare(`
      SELECT k.kid_id, k.first_name, k.last_name, k.registration_id
      FROM kids k JOIN kid_mentor km ON km.kid_id = k.kid_id
      WHERE km.mentor_id = ? AND k.is_deleted = 0 AND k.submission_status = 'APPROVED'
      ORDER BY k.first_name, k.last_name
    `).all(user.user_id) as any[];
  } else {
    rows = db.prepare(`
      SELECT kid_id, first_name, last_name, registration_id
      FROM kids WHERE is_deleted = 0 AND submission_status = 'APPROVED'
      ORDER BY first_name, last_name
    `).all() as any[];
  }
  res.json(rows);
});

// ══════════════════════════════════════════════════════════════════════════════
// GET /records/mentors-list  — all active mentors (for dropdowns)
// ══════════════════════════════════════════════════════════════════════════════
router.get('/mentors-list', (req: AuthRequest, res: Response): void => {
  const user = req.user!;
  const allowed = ['ADMIN', 'SPIRITUAL_LEADER'];
  if (!allowed.includes(user.role)) { res.status(403).json({ error: 'Access denied' }); return; }

  const rows = db.prepare(`
    SELECT user_id, full_name, username FROM users
    WHERE role = 'MENTOR' AND is_active = 1 ORDER BY full_name
  `).all();
  res.json(rows);
});

// ══════════════════════════════════════════════════════════════════════════════
// GET /records/kid/:kidId    — full kid record (admin / SL / mentor who owns)
// ══════════════════════════════════════════════════════════════════════════════
router.get('/kid/:kidId', (req: AuthRequest, res: Response): void => {
  const { kidId } = req.params;
  const user = req.user!;

  const allowed = ['ADMIN', 'SPIRITUAL_LEADER', 'MENTOR'];
  if (!allowed.includes(user.role)) { res.status(403).json({ error: 'Access denied' }); return; }

  // Mentor can only view their own assigned kids
  if (user.role === 'MENTOR') {
    const assigned = db.prepare(
      'SELECT 1 FROM kid_mentor WHERE kid_id = ? AND mentor_id = ?'
    ).get(kidId, user.user_id);
    if (!assigned) { res.status(403).json({ error: 'Not your assigned kid' }); return; }
  }

  // ── Kid profile ─────────────────────────────────────────────────────────
  const kid = db.prepare(`
    SELECT k.*, u.full_name AS created_by_name
    FROM kids k LEFT JOIN users u ON u.user_id = k.created_by_user_id
    WHERE k.kid_id = ? AND k.is_deleted = 0
  `).get(kidId) as any;
  if (!kid) { res.status(404).json({ error: 'Kid not found' }); return; }

  // ── Parents ─────────────────────────────────────────────────────────────
  const parents = db.prepare(`
    SELECT p.* FROM parents p
    JOIN kid_parent kp ON kp.parent_id = p.parent_id
    WHERE kp.kid_id = ?
  `).all(kidId) as any[];

  // ── Hobbies & interests ──────────────────────────────────────────────────
  const hobbies = db.prepare(`
    SELECT h.name FROM hobbies h
    JOIN kid_hobbies kh ON kh.hobby_id = h.hobby_id WHERE kh.kid_id = ?
  `).all(kidId).map((r: any) => r.name);

  const interests = db.prepare(`
    SELECT i.name FROM interests i
    JOIN kid_interests ki ON ki.interest_id = i.interest_id WHERE ki.kid_id = ?
  `).all(kidId).map((r: any) => r.name);

  // ── Mentor assignments ───────────────────────────────────────────────────
  const mentors = db.prepare(`
    SELECT u.user_id, u.full_name, u.username, km.assigned_at
    FROM users u JOIN kid_mentor km ON km.mentor_id = u.user_id
    WHERE km.kid_id = ? ORDER BY km.assigned_at
  `).all(kidId) as any[];

  // ── Mentor notes (all mentors for this kid) ──────────────────────────────
  let mentorNotesQuery = `
    SELECT mn.*, u.full_name AS mentor_name
    FROM mentor_notes mn JOIN users u ON u.user_id = mn.mentor_id
    WHERE mn.kid_id = ? ORDER BY mn.session_date DESC
  `;
  const mentorNotes = user.role === 'MENTOR'
    ? db.prepare(`
        SELECT mn.*, u.full_name AS mentor_name
        FROM mentor_notes mn JOIN users u ON u.user_id = mn.mentor_id
        WHERE mn.kid_id = ? AND mn.mentor_id = ? ORDER BY mn.session_date DESC
      `).all(kidId, user.user_id)
    : db.prepare(mentorNotesQuery).all(kidId);

  // ── Spiritual attendance ─────────────────────────────────────────────────
  // GROUP / SMALL_GROUP sessions the kid was registered for
  const groupAttendance = db.prepare(`
    SELECT ss.session_id, ss.session_date, ss.topic, ss.session_type, ss.is_signed,
           ss.is_cancelled, sa.is_present, u.full_name AS sl_name
    FROM spiritual_sessions ss
    JOIN spiritual_attendance sa ON sa.session_id = ss.session_id AND sa.kid_id = ?
    LEFT JOIN users u ON u.user_id = ss.created_by
    ORDER BY ss.session_date DESC
  `).all(kidId) as any[];

  // 1:1 Kid sessions
  const oneOnOneSessions = db.prepare(`
    SELECT ss.session_id, ss.session_date, ss.topic, ss.session_type, ss.is_signed,
           ss.is_cancelled, ss.one_on_one_attended AS is_present, u.full_name AS sl_name
    FROM spiritual_sessions ss
    LEFT JOIN users u ON u.user_id = ss.created_by
    WHERE ss.session_type = 'ONE_ON_ONE_KID' AND ss.target_id = ?
    ORDER BY ss.session_date DESC
  `).all(kidId) as any[];

  const allSpiritualSessions = [...groupAttendance, ...oneOnOneSessions]
    .sort((a, b) => b.session_date.localeCompare(a.session_date));

  // ── SL individual kid notes ──────────────────────────────────────────────
  const slNotes = db.prepare(`
    SELECT skn.note_id, skn.content, skn.improvement, skn.suggestions, skn.created_at,
           ss.session_date, ss.topic, ss.session_id,
           u.full_name AS sl_name
    FROM spiritual_kid_notes skn
    JOIN spiritual_sessions ss ON ss.session_id = skn.session_id
    LEFT JOIN users u ON u.user_id = skn.created_by
    WHERE skn.kid_id = ? ORDER BY ss.session_date DESC
  `).all(kidId) as any[];

  // ── Stats ────────────────────────────────────────────────────────────────
  const nonCancelled = allSpiritualSessions.filter(s => !s.is_cancelled);
  const spiritualStats = attendanceStats(nonCancelled);

  res.json({
    kid, parents, hobbies, interests, mentors,
    mentorNotes,
    spiritualSessions: allSpiritualSessions,
    slNotes,
    spiritualStats,
  });
});

// ══════════════════════════════════════════════════════════════════════════════
// GET /records/mentor/:mentorId  — mentor's attendance + kids summary
// ══════════════════════════════════════════════════════════════════════════════
router.get('/mentor/:mentorId', (req: AuthRequest, res: Response): void => {
  const { mentorId } = req.params;
  const user = req.user!;

  const allowed = ['ADMIN', 'SPIRITUAL_LEADER'];
  if (!allowed.includes(user.role)) { res.status(403).json({ error: 'Access denied' }); return; }

  const mentor = db.prepare(
    'SELECT user_id, full_name, username, is_active FROM users WHERE user_id = ? AND role = ?'
  ).get(mentorId, 'MENTOR') as any;
  if (!mentor) { res.status(404).json({ error: 'Mentor not found' }); return; }

  // Sessions this mentor attended / was invited to
  const sessions = db.prepare(`
    SELECT ss.session_id, ss.session_date, ss.topic, ss.session_type, ss.is_signed,
           ss.is_cancelled, sma.is_present, sma.rsvp_status
    FROM spiritual_sessions ss
    JOIN spiritual_mentor_attendance sma ON sma.session_id = ss.session_id AND sma.mentor_id = ?
    ORDER BY ss.session_date DESC
  `).all(mentorId) as any[];

  // Assigned kids
  const kids = db.prepare(`
    SELECT k.kid_id, k.first_name, k.last_name, k.registration_id, km.assigned_at
    FROM kids k JOIN kid_mentor km ON km.kid_id = k.kid_id
    WHERE km.mentor_id = ? AND k.is_deleted = 0 ORDER BY k.first_name
  `).all(mentorId) as any[];

  // Mentor notes count per kid
  const noteCounts = db.prepare(`
    SELECT kid_id, COUNT(*) AS note_count, MAX(session_date) AS last_session
    FROM mentor_notes WHERE mentor_id = ? GROUP BY kid_id
  `).all(mentorId) as any[];
  const noteMap: Record<string, any> = {};
  noteCounts.forEach((n: any) => { noteMap[n.kid_id] = n; });
  const kidsWithNotes = kids.map(k => ({ ...k, ...(noteMap[k.kid_id] || { note_count: 0 }) }));

  const nonCancelled = sessions.filter(s => !s.is_cancelled);
  const stats = attendanceStats(nonCancelled);

  res.json({ mentor, sessions, kids: kidsWithNotes, stats });
});

// ══════════════════════════════════════════════════════════════════════════════
// GET /records/group-overview  — all kids attendance overview (SL / Admin)
// ══════════════════════════════════════════════════════════════════════════════
router.get('/group-overview', (req: AuthRequest, res: Response): void => {
  const user = req.user!;
  const allowed = ['ADMIN', 'SPIRITUAL_LEADER'];
  if (!allowed.includes(user.role)) { res.status(403).json({ error: 'Access denied' }); return; }

  // All non-cancelled GROUP + SMALL_GROUP sessions
  const sessions = db.prepare(`
    SELECT session_id, session_date, topic, session_type
    FROM spiritual_sessions
    WHERE is_cancelled = 0 AND session_type IN ('GROUP','SMALL_GROUP')
    ORDER BY session_date DESC LIMIT 50
  `).all() as any[];

  // For each session get attendance summary
  const result = sessions.map((s: any) => {
    const att = db.prepare(
      'SELECT SUM(is_present) AS present, COUNT(*) AS total FROM spiritual_attendance WHERE session_id = ?'
    ).get(s.session_id) as any;
    return { ...s, present: att?.present ?? 0, total: att?.total ?? 0 };
  });

  // Per-kid overall stats
  const kidStats = db.prepare(`
    SELECT k.kid_id, k.first_name, k.last_name, k.registration_id,
           COUNT(sa.session_id) AS total_sessions,
           SUM(sa.is_present) AS sessions_present
    FROM kids k
    JOIN spiritual_attendance sa ON sa.kid_id = k.kid_id
    JOIN spiritual_sessions ss ON ss.session_id = sa.session_id AND ss.is_cancelled = 0
    WHERE k.is_deleted = 0
    GROUP BY k.kid_id ORDER BY k.first_name
  `).all() as any[];

  res.json({ sessions: result, kidStats });
});

// ══════════════════════════════════════════════════════════════════════════════
// PUT /records/attendance  — Admin only: toggle attendance (bypasses signed lock)
// ══════════════════════════════════════════════════════════════════════════════
router.put('/attendance', (req: AuthRequest, res: Response): void => {
  const user = req.user!;
  if (user.role !== 'ADMIN') { res.status(403).json({ error: 'Admin only' }); return; }

  const { session_id, entity_type, entity_id, is_present } = req.body;
  if (!session_id || !entity_type || !entity_id || typeof is_present !== 'boolean') {
    res.status(400).json({ error: 'session_id, entity_type, entity_id, is_present required' }); return;
  }
  if (!['kid', 'mentor'].includes(entity_type)) {
    res.status(400).json({ error: 'entity_type must be "kid" or "mentor"' }); return;
  }

  const session = db.prepare('SELECT * FROM spiritual_sessions WHERE session_id=?').get(session_id) as any;
  if (!session) { res.status(404).json({ error: 'Session not found' }); return; }

  const attended = is_present ? 1 : 0;

  if (entity_type === 'kid') {
    db.prepare('INSERT OR REPLACE INTO spiritual_attendance (session_id, kid_id, is_present) VALUES (?,?,?)')
      .run(session_id, entity_id, attended);
    if (session.session_type === 'ONE_ON_ONE_KID' && session.target_id === entity_id) {
      db.prepare('UPDATE spiritual_sessions SET one_on_one_attended=? WHERE session_id=?').run(attended, session_id);
    }
  } else {
    db.prepare('UPDATE spiritual_mentor_attendance SET is_present=? WHERE session_id=? AND mentor_id=?')
      .run(attended, session_id, entity_id);
    if (session.session_type === 'ONE_ON_ONE_MENTOR' && session.target_id === entity_id) {
      db.prepare('UPDATE spiritual_sessions SET one_on_one_attended=? WHERE session_id=?').run(attended, session_id);
    }
  }

  res.json({ message: 'Attendance updated' });
});

export default router;
