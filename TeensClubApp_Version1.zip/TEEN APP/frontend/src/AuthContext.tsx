import React, { createContext, useContext, useState, useEffect, useRef } from 'react';

interface AuthUser {
  user_id: string;
  username: string;
  role: 'ADMIN' | 'DATA_ENTRY' | 'MENTOR' | 'SUB' | 'SPIRITUAL_LEADER';
  full_name: string;
}

interface AuthContextType {
  user: AuthUser | null;
  token: string | null;
  login: (token: string, user: AuthUser) => void;
  logout: () => void;
  isAdmin: boolean;
  isDataEntry: boolean;
  isMentor: boolean;
  isSpiritualLeader: boolean;
  canEdit: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

// ── Constants ─────────────────────────────────────────────────────────────────
const SESSION_FLAG = 'tc_session';          // sessionStorage key — cleared on browser close
const IDLE_TIMEOUT = 10 * 60 * 1000;       // 10 minutes of inactivity → auto-logout
const ACTIVITY_EVENTS = ['mousemove', 'keydown', 'click', 'scroll', 'touchstart'] as const;

export function AuthProvider({ children }: { children: React.ReactNode }) {
  // ── State ─────────────────────────────────────────────────────────────────
  // If the browser was freshly opened (no sessionStorage flag), don't restore
  // credentials from localStorage — the user must log in again.
  const isFreshBrowser = !sessionStorage.getItem(SESSION_FLAG);

  const [user, setUser] = useState<AuthUser | null>(() => {
    if (isFreshBrowser) return null;
    try { return JSON.parse(localStorage.getItem('tc_user') || 'null'); } catch { return null; }
  });
  const [token, setToken] = useState<string | null>(() => {
    if (isFreshBrowser) return null;
    return localStorage.getItem('tc_token');
  });

  const idleTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // ── Shared clear helper ───────────────────────────────────────────────────
  const clearSession = () => {
    localStorage.removeItem('tc_token');
    localStorage.removeItem('tc_user');
    sessionStorage.removeItem(SESSION_FLAG);
    setToken(null);
    setUser(null);
  };

  const login = (tok: string, u: AuthUser) => {
    localStorage.setItem('tc_token', tok);
    localStorage.setItem('tc_user', JSON.stringify(u));
    sessionStorage.setItem(SESSION_FLAG, '1');
    setToken(tok);
    setUser(u);
  };

  const logout = () => clearSession();

  // ── Browser-close detection + idle-timeout ────────────────────────────────
  useEffect(() => {
    // If no session flag: the browser was freshly opened — wipe any stale creds
    if (isFreshBrowser) {
      localStorage.removeItem('tc_token');
      localStorage.removeItem('tc_user');
    }
    // Mark session as alive for this browser tab
    sessionStorage.setItem(SESSION_FLAG, '1');

    // Idle-timeout: start a countdown; reset on any user activity
    const resetIdle = () => {
      if (idleTimer.current) clearTimeout(idleTimer.current);
      idleTimer.current = setTimeout(() => {
        clearSession();
      }, IDLE_TIMEOUT);
    };

    ACTIVITY_EVENTS.forEach(e => window.addEventListener(e, resetIdle, { passive: true }));
    resetIdle(); // kick off the first timer

    return () => {
      if (idleTimer.current) clearTimeout(idleTimer.current);
      ACTIVITY_EVENTS.forEach(e => window.removeEventListener(e, resetIdle));
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const isAdmin = user?.role === 'ADMIN';
  const isDataEntry = user?.role === 'DATA_ENTRY' || user?.role === 'SUB';
  const isMentor = user?.role === 'MENTOR';
  const isSpiritualLeader = user?.role === 'SPIRITUAL_LEADER';
  const canEdit = isAdmin || isDataEntry;

  return (
    <AuthContext.Provider value={{ user, token, login, logout, isAdmin, isDataEntry, isMentor, isSpiritualLeader, canEdit }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be inside AuthProvider');
  return ctx;
}
