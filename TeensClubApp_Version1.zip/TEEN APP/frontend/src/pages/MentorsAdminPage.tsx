import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  getMentors, getMentorList, getMentorKids, getKids,
  assignKidToMentor, removeKidFromMentor,
  getAllAssignedKids, reassignKidMentor,
} from '../api';

export default function MentorsAdminPage() {
  const navigate = useNavigate();
  const [mentors, setMentors]               = useState<any[]>([]);
  const [allMentors, setAllMentors]         = useState<any[]>([]);
  const [selectedMentor, setSelectedMentor] = useState<string>('');
  const [mentorKids, setMentorKids]         = useState<any[]>([]);
  const [allKids, setAllKids]               = useState<any[]>([]);
  const [assignedKids, setAssignedKids]     = useState<any[]>([]); // kids assigned to ANY mentor
  const [assignKidId, setAssignKidId]       = useState('');
  const [kidSearch, setKidSearch]           = useState('');
  const [msg, setMsg]   = useState('');
  const [error, setError] = useState('');

  // Reassign state
  const [showReassign, setShowReassign]     = useState(false);
  const [reassignForm, setReassignForm]     = useState({
    kid_id: '', new_mentor_id: '', reason: '', transfer_notes: false,
  });
  const [reassigning, setReassigning]       = useState(false);

  const loadAll = () => {
    getMentors().then(setMentors);
    getAllAssignedKids().then(setAssignedKids);
  };

  useEffect(() => {
    loadAll();
    getMentorList().then(setAllMentors);
  }, []);

  useEffect(() => {
    if (selectedMentor) {
      getMentorKids(selectedMentor).then(setMentorKids);
      getKids(1).then((r: any) => setAllKids(r.data || []));
    } else {
      setMentorKids([]);
    }
  }, [selectedMentor]);

  const handleAssign = async () => {
    if (!selectedMentor || !assignKidId) return;
    setMsg(''); setError('');
    try {
      await assignKidToMentor(assignKidId, selectedMentor);
      setMsg('Student assigned successfully');
      setAssignKidId('');
      getMentorKids(selectedMentor).then(setMentorKids);
      loadAll();
    } catch (e: any) {
      setError(e.response?.data?.error || 'Assignment failed');
    }
  };

  const handleRemove = async (kidId: string) => {
    if (!window.confirm('Remove this student from mentor?')) return;
    setMsg(''); setError('');
    try {
      await removeKidFromMentor(kidId, selectedMentor);
      setMsg('Assignment removed');
      getMentorKids(selectedMentor).then(setMentorKids);
      loadAll();
    } catch (e: any) {
      setError(e.response?.data?.error || 'Error removing assignment');
    }
  };

  const handleReassign = async () => {
    if (!reassignForm.kid_id || !reassignForm.new_mentor_id || !reassignForm.reason.trim()) {
      setError('Please fill out all required reassign fields.'); return;
    }
    setReassigning(true); setMsg(''); setError('');
    try {
      await reassignKidMentor({
        kid_id: reassignForm.kid_id,
        new_mentor_id: reassignForm.new_mentor_id,
        reason: reassignForm.reason.trim(),
        transfer_notes: reassignForm.transfer_notes,
      });
      setMsg('Student reassigned successfully' + (reassignForm.transfer_notes ? ' (previous notes transferred and locked).' : '.'));
      setReassignForm({ kid_id: '', new_mentor_id: '', reason: '', transfer_notes: false });
      setShowReassign(false);
      loadAll();
      if (selectedMentor) getMentorKids(selectedMentor).then(setMentorKids);
    } catch (e: any) {
      setError(e.response?.data?.error || 'Reassignment failed');
    } finally { setReassigning(false); }
  };

  // Fix: exclude kids assigned to ANY mentor from the assignment dropdown
  const assignedKidIds = new Set(assignedKids.map((k: any) => k.kid_id));
  const filteredKids = allKids.filter((k: any) => {
    const name = `${k.first_name} ${k.last_name}`.toLowerCase();
    const alreadyAssigned = assignedKidIds.has(k.kid_id);
    return !alreadyAssigned && (
      kidSearch === '' ||
      name.includes(kidSearch.toLowerCase()) ||
      k.registration_id?.toLowerCase().includes(kidSearch.toLowerCase())
    );
  });

  return (
    <main className="page">
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24 }}>
        <button className="btn btn-outline btn-sm" onClick={() => navigate('/')}>← Home</button>
        <h2 style={{ fontSize: 22, fontWeight: 700 }}>🧑‍🏫 Mentor Management</h2>
      </div>

      {msg   && <div className="alert alert-success">{msg}</div>}
      {error && <div className="alert alert-error">{error}</div>}

      {/* Mentor Overview */}
      <div className="card" style={{ marginBottom: 20 }}>
        <div className="card-title">All Mentors</div>
        {mentors.length === 0 ? (
          <p style={{ color: 'var(--muted)' }}>No mentor accounts found. Create mentor users in User Management first.</p>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Name</th><th>Username</th><th>Assigned Teens</th><th>Status</th><th>Action</th>
                </tr>
              </thead>
              <tbody>
                {mentors.map((m: any) => (
                  <tr key={m.user_id} style={{ background: selectedMentor === m.user_id ? 'var(--surface-alt, #f0f4ff)' : undefined }}>
                    <td><strong>{m.full_name}</strong></td>
                    <td><code>{m.username}</code></td>
                    <td><span className="badge badge-sub">{m.assigned_count} teens</span></td>
                    <td><span style={{ color: m.is_active ? 'var(--success)' : 'var(--danger)' }}>{m.is_active ? '✅ Active' : '❌ Inactive'}</span></td>
                    <td>
                      <button className="btn btn-primary btn-sm"
                        onClick={() => setSelectedMentor(selectedMentor === m.user_id ? '' : m.user_id)}>
                        {selectedMentor === m.user_id ? 'Close' : 'Manage'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Assign / Manage section */}
      {selectedMentor && (
        <div className="card" style={{ marginBottom: 20 }}>
          <div className="card-title">
            Assigned Teens for: <strong>{allMentors.find(m => m.user_id === selectedMentor)?.full_name}</strong>
          </div>

          {/* Assign new kid */}
          <div style={{ display: 'flex', gap: 12, marginBottom: 16, flexWrap: 'wrap', alignItems: 'flex-end' }}>
            <div className="field" style={{ flex: '1 1 220px', marginBottom: 0 }}>
              <label>Search Unassigned Student</label>
              <input value={kidSearch} onChange={e => setKidSearch(e.target.value)}
                placeholder="Filter by name or Reg ID…" />
            </div>
            <div className="field" style={{ flex: '1 1 240px', marginBottom: 0 }}>
              <label>Select Student</label>
              <select value={assignKidId} onChange={e => setAssignKidId(e.target.value)}>
                <option value="">— Choose unassigned student —</option>
                {filteredKids.map((k: any) => (
                  <option key={k.kid_id} value={k.kid_id}>
                    {k.first_name} {k.last_name} ({k.registration_id})
                  </option>
                ))}
              </select>
            </div>
            <button className="btn btn-success btn-sm" onClick={handleAssign}
              disabled={!assignKidId} style={{ height: 38 }}>
              + Assign
            </button>
          </div>

          {/* Currently assigned kids */}
          {mentorKids.length === 0 ? (
            <p style={{ color: 'var(--muted)', paddingTop: 8 }}>No students assigned yet.</p>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr><th>Reg ID</th><th>Name</th><th>Age</th><th>Education</th><th>Phone</th><th>Assigned</th><th></th></tr>
                </thead>
                <tbody>
                  {mentorKids.map((k: any) => (
                    <tr key={k.kid_id}>
                      <td><code>{k.registration_id}</code></td>
                      <td style={{ cursor: 'pointer', color: 'var(--primary)', fontWeight: 600 }}
                        onClick={() => navigate(`/kid/${k.kid_id}`)}>
                        {k.first_name} {k.last_name}
                      </td>
                      <td>{k.age_snapshot}</td>
                      <td>{k.education_level || '—'}</td>
                      <td>{k.phone_normalized || '—'}</td>
                      <td style={{ fontSize: 12, color: 'var(--muted)' }}>{k.assigned_at?.slice(0, 10)}</td>
                      <td>
                        <button className="btn btn-outline btn-sm" style={{ color: '#dc3545', borderColor: '#dc3545' }}
                          onClick={() => handleRemove(k.kid_id)}>
                          Remove
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ── Reassign Section ────────────────────────────────────────────────── */}
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div className="card-title" style={{ marginBottom: 0 }}>🔄 Reassign a Student to a Different Mentor</div>
          <button className="btn btn-outline btn-sm" onClick={() => { setShowReassign(v => !v); setError(''); }}>
            {showReassign ? 'Cancel' : 'Reassign'}
          </button>
        </div>

        {showReassign && (
          <div style={{ marginTop: 16 }}>
            <p style={{ color: 'var(--muted)', fontSize: 13, marginBottom: 12 }}>
              Select a student currently assigned to a mentor, choose the new mentor, provide a reason,
              and optionally transfer the old session notes to the new mentor (transferred notes become read-only).
            </p>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 12, marginBottom: 12 }}>
              <div className="field" style={{ marginBottom: 0 }}>
                <label className="required">Currently Assigned Student</label>
                <select value={reassignForm.kid_id}
                  onChange={e => setReassignForm(f => ({ ...f, kid_id: e.target.value }))}>
                  <option value="">— Select student —</option>
                  {assignedKids.map((k: any) => (
                    <option key={k.kid_id} value={k.kid_id}>
                      {k.first_name} {k.last_name} (Current: {k.mentor_name})
                    </option>
                  ))}
                </select>
              </div>

              <div className="field" style={{ marginBottom: 0 }}>
                <label className="required">New Mentor</label>
                <select value={reassignForm.new_mentor_id}
                  onChange={e => setReassignForm(f => ({ ...f, new_mentor_id: e.target.value }))}>
                  <option value="">— Select new mentor —</option>
                  {allMentors
                    .filter(m => {
                      // Don't show mentor who currently has the kid
                      const currentMentorId = assignedKids.find((k: any) => k.kid_id === reassignForm.kid_id)?.mentor_id;
                      return m.user_id !== currentMentorId;
                    })
                    .map(m => (
                      <option key={m.user_id} value={m.user_id}>{m.full_name}</option>
                    ))}
                </select>
              </div>

              <div className="field" style={{ marginBottom: 0, gridColumn: '1 / -1' }}>
                <label className="required">Reason for Reassignment</label>
                <textarea rows={3}
                  value={reassignForm.reason}
                  onChange={e => setReassignForm(f => ({ ...f, reason: e.target.value }))}
                  placeholder="Explain why the student is being reassigned…"
                  style={{ width: '100%', boxSizing: 'border-box' }}
                />
              </div>
            </div>

            <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', marginBottom: 16, fontSize: 14 }}>
              <input type="checkbox"
                checked={reassignForm.transfer_notes}
                onChange={e => setReassignForm(f => ({ ...f, transfer_notes: e.target.checked }))} />
              Transfer previous session notes to the new mentor (transferred notes will be{' '}
              <strong>read-only</strong> for the new mentor)
            </label>

            <button className="btn btn-primary" onClick={handleReassign} disabled={reassigning}>
              {reassigning ? 'Reassigning…' : '✅ Confirm Reassignment'}
            </button>
          </div>
        )}
      </div>
    </main>
  );
}
