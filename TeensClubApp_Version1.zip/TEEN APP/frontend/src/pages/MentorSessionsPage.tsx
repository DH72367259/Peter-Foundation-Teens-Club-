import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  getSpiritualUpcoming, rsvpSpiritualSession,
  getMySessionRequests, createSessionRequest, getMyKids,
  getSpiritualMyInvites,
} from '../api';
import { useAuth } from '../AuthContext';

const SESSION_TYPE_LABEL: Record<string, string> = {
  GROUP: 'Group', SMALL_GROUP: 'Small Group', ALL_MENTORS: 'All Mentors',
  ONE_ON_ONE_KID: '1:1 Teen', ONE_ON_ONE_MENTOR: '1:1 Mentor',
};
const SESSION_TYPE_COLOR: Record<string, { bg: string; color: string }> = {
  GROUP:             { bg: '#dbeafe', color: '#1d4ed8' },
  SMALL_GROUP:       { bg: '#e0f2fe', color: '#0369a1' },
  ALL_MENTORS:       { bg: '#fef3c7', color: '#92400e' },
  ONE_ON_ONE_KID:    { bg: '#fce7f3', color: '#be185d' },
  ONE_ON_ONE_MENTOR: { bg: '#f3e8ff', color: '#6b21a8' },
};

// Compute month label from a date string "YYYY-MM-DD"
function monthOf(dateStr: string) {
  return dateStr?.slice(0, 7) ?? '';
}

function daysUntilLabel(daysUntil: number): { label: string; color: string } {
  if (daysUntil < 0)   return { label: 'Past',            color: '#6b7280' };
  if (daysUntil === 0) return { label: 'Today!',          color: '#dc2626' };
  if (daysUntil === 1) return { label: 'Tomorrow!',       color: '#ea580c' };
  if (daysUntil <= 3)  return { label: `In ${daysUntil} days`, color: '#d97706' };
  if (daysUntil <= 7)  return { label: `In ${daysUntil} days`, color: '#2563eb' };
  return { label: `In ${daysUntil} days`, color: '#6b7280' };
}

const PAGE_SIZE = 10;

export default function MentorSessionsPage() {
  const navigate = useNavigate();
  const { user } = useAuth();

  // ── main tabs ──────────────────────────────────────────────────────────────
  const [tab, setTab] = useState<'upcoming' | 'completed' | 'approvals'>('upcoming');

  // ── upcoming sessions ──────────────────────────────────────────────────────
  const [sessions, setSessions]           = useState<any[]>([]);
  const [sessLoading, setSessLoading]     = useState(true);
  const [upcomingDays, setUpcomingDays]   = useState(14);
  const [typeFilter, setTypeFilter]       = useState('all');
  const [rsvpLoading, setRsvpLoading]     = useState<string | null>(null);

  // ── completed sessions (signed, via my-invites) ────────────────────────────
  const [allInvites, setAllInvites]       = useState<any[]>([]);
  const [invitesLoading, setInvitesLoading] = useState(true);
  const [completedPage, setCompletedPage] = useState(1);
  const [completedMonthFilter, setCompletedMonthFilter] = useState('all');

  // ── approvals ──────────────────────────────────────────────────────────────
  const [requests, setRequests]           = useState<any[]>([]);
  const [reqLoading, setReqLoading]       = useState(true);
  const [approvalSub, setApprovalSub]     = useState<'pending' | 'denied'>('pending');

  // ── new request modal ──────────────────────────────────────────────────────
  const [showNewReq, setShowNewReq]       = useState(false);
  const [allKids, setAllKids]             = useState<any[]>([]);
  const [form, setForm]                   = useState({ request_type: 'ONE_ON_ONE_SL', kid_ids: [] as string[], message: '' });
  const [saving, setSaving]               = useState(false);
  const [formError, setFormError]         = useState('');
  const [msg, setMsg]                     = useState('');

  const loadSessions = (days = upcomingDays, filter = typeFilter) => {
    setSessLoading(true);
    getSpiritualUpcoming(days, filter).then(setSessions).finally(() => setSessLoading(false));
  };
  const loadAllInvites = () => {
    setInvitesLoading(true);
    getSpiritualMyInvites().then(setAllInvites).finally(() => setInvitesLoading(false));
  };
  const loadRequests = () => {
    setReqLoading(true);
    getMySessionRequests().then(setRequests).finally(() => setReqLoading(false));
  };

  useEffect(() => {
    loadSessions(14, 'all');
    loadAllInvites();
    loadRequests();
    getMyKids().then(setAllKids).catch(() => {});
  }, []);

  const handleRsvp = async (sessionId: string, status: 'ACCEPTED' | 'DECLINED') => {
    setRsvpLoading(sessionId + status);
    try {
      await rsvpSpiritualSession(sessionId, status);
      loadSessions(upcomingDays, typeFilter);
    } catch (e: any) { alert(e.response?.data?.error || 'RSVP failed'); }
    finally { setRsvpLoading(null); }
  };

  const handleSubmitRequest = async () => {
    if (!form.message.trim()) { setFormError('Please describe your request'); return; }
    if (form.request_type === 'ONE_ON_ONE_KID' && form.kid_ids.length === 0) {
      setFormError('Please select at least one teen'); return;
    }
    setSaving(true); setFormError('');
    try {
      await createSessionRequest({
        request_type: form.request_type,
        kid_ids: form.request_type === 'ONE_ON_ONE_KID' ? form.kid_ids : undefined,
        message: form.message.trim(),
      });
      setMsg('Request sent to Spiritual Leader!');
      setShowNewReq(false);
      setForm({ request_type: 'ONE_ON_ONE_SL', kid_ids: [], message: '' });
      loadRequests();
      setApprovalSub('pending');
      setTab('approvals');
    } catch (ex: any) { setFormError(ex.response?.data?.error || 'Failed to submit'); }
    finally { setSaving(false); }
  };

  const pendingReqs = requests.filter(r => r.status === 'PENDING');
  const deniedReqs  = requests.filter(r => r.status === 'DENIED');

  return (
    <main className="page">
      {/* header — no back button */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 20 }}>
        <h2 style={{ fontSize: 22, fontWeight: 700 }}>📅 My Sessions</h2>
        <span style={{ fontSize: 13, color: 'var(--muted)', marginLeft: 'auto' }}>
          {user?.full_name}
        </span>
      </div>

      {msg && (
        <div className="alert alert-success" style={{ marginBottom: 12 }}>
          {msg}
          <button style={{ float: 'right', background: 'none', border: 'none', cursor: 'pointer', fontWeight: 700 }}
            onClick={() => setMsg('')}>✕</button>
        </div>
      )}

      {/* main tabs */}
      <div className="tabs" style={{ marginBottom: 20 }}>
        <button className={`tab-btn ${tab === 'upcoming' ? 'active' : ''}`} onClick={() => setTab('upcoming')}>
          Upcoming Sessions
          {sessions.filter(s => s.myRsvp === 'PENDING').length > 0
            ? ` (${sessions.filter(s => s.myRsvp === 'PENDING').length} RSVP needed)` : ''}
        </button>
        <button className={`tab-btn ${tab === 'completed' ? 'active' : ''}`} onClick={() => setTab('completed')}>
          Completed ✅
          {allInvites.filter(s => s.is_signed).length > 0
            ? ` (${allInvites.filter(s => s.is_signed).length})` : ''}
        </button>
        <button className={`tab-btn ${tab === 'approvals' ? 'active' : ''}`} onClick={() => setTab('approvals')}>
          Approvals
          {requests.filter(r => r.status === 'PENDING').length > 0
            ? ` (${requests.filter(r => r.status === 'PENDING').length} pending)` : ''}
        </button>
      </div>

      {/* ══ UPCOMING SESSIONS ══════════════════════════════════════════════════ */}
      {tab === 'upcoming' && (
        <div>
          {/* filters */}
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' as const, marginBottom: 16, alignItems: 'center' }}>
            <div>
              <label style={{ fontSize: 13, color: 'var(--muted)', marginRight: 6 }}>Window:</label>
              <select value={upcomingDays} style={{ fontSize: 13 }}
                onChange={e => { const d = Number(e.target.value); setUpcomingDays(d); loadSessions(d, typeFilter); }}>
                <option value={7}>Next 7 days</option>
                <option value={14}>Next 2 weeks (default)</option>
                <option value={30}>Next month</option>
                <option value={60}>Next 2 months</option>
              </select>
            </div>
            <div>
              <label style={{ fontSize: 13, color: 'var(--muted)', marginRight: 6 }}>Filter:</label>
              <select value={typeFilter} style={{ fontSize: 13 }}
                onChange={e => { setTypeFilter(e.target.value); loadSessions(upcomingDays, e.target.value); }}>
                <option value="all">All types</option>
                <option value="GROUP">Group only</option>
                <option value="SMALL_GROUP">Small Group only</option>
                <option value="ALL_MENTORS">Mentor meetings only</option>
                <option value="ONE_ON_ONE_KID">1:1 with teen only</option>
                <option value="ONE_ON_ONE_MENTOR">1:1 with mentor only</option>
              </select>
            </div>
            <button className="btn btn-outline btn-sm"
              onClick={() => loadSessions(upcomingDays, typeFilter)}>Refresh</button>
          </div>

          {sessLoading ? <p style={{ color: 'var(--muted)' }}>Loading sessions…</p> : (
            sessions.length === 0 ? (
              <div className="card">
                <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '32px 0' }}>
                  No upcoming sessions in the next {upcomingDays} days.
                  Your Spiritual Leader will invite you when sessions are scheduled.
                </p>
              </div>
            ) : (
              <div className="card" style={{ padding: '16px 20px' }}>
                <div style={{ fontWeight: 700, fontSize: 14, color: 'var(--muted)', marginBottom: 12 }}>
                  {sessions.length} session{sessions.length !== 1 ? 's' : ''} in the next {upcomingDays} days
                </div>
                {sessions.map((s: any) => {
                  const { label, color } = daysUntilLabel(s.daysUntil);
                  const tc = SESSION_TYPE_COLOR[s.session_type] || { bg: '#e5e7eb', color: '#374151' };
                  const myRsvp = s.myRsvp;
                  const isPending  = myRsvp === 'PENDING';
                  const isAccepted = myRsvp === 'ACCEPTED';
                  return (
                    <div key={s.session_id} style={{
                      padding: '14px 16px', borderRadius: 10, marginBottom: 10,
                      background: s.is_cancelled ? '#fef2f2' : isPending ? '#faf5ff' : isAccepted ? '#f0fdf4' : '#fef2f2',
                      border: `1px solid ${s.is_cancelled ? '#fca5a5' : isPending ? '#c4b5fd' : isAccepted ? '#86efac' : '#fca5a5'}`,
                      display: 'flex', alignItems: 'center', flexWrap: 'wrap' as const, gap: 10,
                    }}>
                      <div style={{ flex: 1, minWidth: 200 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' as const }}>
                          <strong style={{ fontSize: 15 }}>{s.topic}</strong>
                          <span style={{ fontSize: 11, padding: '2px 7px', borderRadius: 10, fontWeight: 600, background: tc.bg, color: tc.color }}>
                            {SESSION_TYPE_LABEL[s.session_type] || s.session_type}
                          </span>
                          {s.is_cancelled && (
                            <span style={{ fontSize: 11, background: '#fee2e2', color: '#991b1b', padding: '2px 7px', borderRadius: 10, fontWeight: 700 }}>
                              CANCELLED
                            </span>
                          )}
                        </div>
                        <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 4 }}>
                          {s.session_date}
                          {s.targetName ? ` — with ${s.targetName}` : ''}
                          {s.created_by_name ? ` — by ${s.created_by_name}` : ''}
                        </div>
                        {s.is_cancelled && s.cancelled_reason && (
                          <div style={{ fontSize: 12, color: '#dc2626', marginTop: 4 }}>Reason: {s.cancelled_reason}</div>
                        )}
                        {s.is_cancelled && s.proposed_new_date && (
                          <div style={{ fontSize: 12, color: '#16a34a', marginTop: 2 }}>
                            Proposed new date: {s.proposed_new_date}
                            {s.proposed_new_topic ? ` — "${s.proposed_new_topic}"` : ''}
                          </div>
                        )}
                      </div>

                      <div style={{ display: 'flex', flexDirection: 'column' as const, alignItems: 'flex-end', gap: 8 }}>
                        <span style={{ fontSize: 12, fontWeight: 700, color, background: '#fff', border: `1px solid ${color}`, borderRadius: 8, padding: '3px 10px' }}>
                          {label}
                        </span>
                        {myRsvp && (
                          <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 10, fontWeight: 700,
                            background: isPending ? '#ede9fe' : isAccepted ? '#dcfce7' : '#fee2e2',
                            color: isPending ? '#5b21b6' : isAccepted ? '#166534' : '#991b1b',
                          }}>
                            {isPending ? '⏳ RSVP Required' : isAccepted ? '✅ Confirmed' : '❌ Declined'}
                          </span>
                        )}
                        <div style={{ display: 'flex', gap: 6 }}>
                          {!s.is_cancelled && (
                            <button className="btn btn-sm"
                              onClick={() => navigate(`/spiritual/session/${s.session_id}`)}
                              style={{ fontSize: 12, padding: '3px 10px', borderRadius: 5, background: '#6366f1', color: '#fff', border: 'none' }}>
                              View
                            </button>
                          )}
                          {!s.is_cancelled && myRsvp && isPending && (
                            <>
                              <button className="btn btn-sm"
                                style={{ fontSize: 12, padding: '3px 10px', borderRadius: 5, background: '#16a34a', color: '#fff', border: 'none', opacity: rsvpLoading ? 0.6 : 1 }}
                                disabled={!!rsvpLoading} onClick={() => handleRsvp(s.session_id, 'ACCEPTED')}>
                                ✅ Accept
                              </button>
                              <button className="btn btn-sm"
                                style={{ fontSize: 12, padding: '3px 10px', borderRadius: 5, background: '#dc2626', color: '#fff', border: 'none', opacity: rsvpLoading ? 0.6 : 1 }}
                                disabled={!!rsvpLoading} onClick={() => handleRsvp(s.session_id, 'DECLINED')}>
                                ❌ Decline
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )
          )}
        </div>
      )}

      {/* ══ COMPLETED SESSIONS ═════════════════════════════════════════════════ */}
      {tab === 'completed' && (
        <div>
          {invitesLoading ? <p style={{ color: 'var(--muted)' }}>Loading…</p> : (() => {
            // Only signed, not cancelled sessions
            const completed = allInvites.filter((s: any) => s.is_signed && !s.is_cancelled)
              .sort((a: any, b: any) => b.session_date.localeCompare(a.session_date));

            // Build month options
            const months = Array.from(new Set(completed.map((s: any) => monthOf(s.session_date)))).sort().reverse();

            const filtered = completedMonthFilter === 'all'
              ? completed
              : completed.filter((s: any) => monthOf(s.session_date) === completedMonthFilter);

            const totalPages  = Math.ceil(filtered.length / PAGE_SIZE);
            const currentPage = Math.min(completedPage, Math.max(1, totalPages));
            const pageSlice   = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

            return (
              <div>
                <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 16, flexWrap: 'wrap' as const }}>
                  <label style={{ fontSize: 13, color: 'var(--muted)' }}>Month:</label>
                  <select value={completedMonthFilter} style={{ fontSize: 13 }}
                    onChange={e => { setCompletedMonthFilter(e.target.value); setCompletedPage(1); }}>
                    <option value="all">All months</option>
                    {months.map(m => <option key={m} value={m}>{m}</option>)}
                  </select>
                  <span style={{ fontSize: 13, color: 'var(--muted)', marginLeft: 'auto' }}>
                    {filtered.length} session{filtered.length !== 1 ? 's' : ''}
                  </span>
                </div>

                {filtered.length === 0 ? (
                  <div className="card">
                    <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '32px 0' }}>
                      No completed sessions yet. Sessions signed by the Spiritual Leader will appear here.
                    </p>
                  </div>
                ) : (
                  <div>
                    <div className="card">
                      <div className="table-wrap">
                        <table>
                          <thead>
                            <tr>
                              <th>Date</th><th>Topic</th><th>Type</th><th>RSVP</th><th>Attended</th><th>Signed By</th>
                            </tr>
                          </thead>
                          <tbody>
                            {pageSlice.map((s: any) => {
                              const tc = SESSION_TYPE_COLOR[s.session_type] || { bg: '#e5e7eb', color: '#374151' };
                              return (
                                <tr key={s.session_id}>
                                  <td><strong>{s.session_date}</strong></td>
                                  <td style={{ maxWidth: 200 }}>
                                    <span style={{ cursor: 'pointer', color: 'var(--primary)', textDecoration: 'underline' }}
                                      onClick={() => navigate(`/spiritual/session/${s.session_id}`)}>
                                      {s.topic}
                                    </span>
                                  </td>
                                  <td>
                                    <span style={{ fontSize: 11, padding: '1px 7px', borderRadius: 10, fontWeight: 600, background: tc.bg, color: tc.color }}>
                                      {SESSION_TYPE_LABEL[s.session_type] || s.session_type}
                                    </span>
                                  </td>
                                  <td>
                                    <span style={{ fontSize: 11, padding: '1px 6px', borderRadius: 8, fontWeight: 600,
                                      background: s.rsvp_status === 'ACCEPTED' ? '#dcfce7' : s.rsvp_status === 'DECLINED' ? '#fee2e2' : '#fef3c7',
                                      color: s.rsvp_status === 'ACCEPTED' ? '#166534' : s.rsvp_status === 'DECLINED' ? '#991b1b' : '#92400e',
                                    }}>{s.rsvp_status ?? 'PENDING'}</span>
                                  </td>
                                  <td>{s.is_present ? <span style={{ color: '#16a34a', fontWeight: 700 }}>✅</span> : <span style={{ color: '#dc2626' }}>❌</span>}</td>
                                  <td style={{ fontSize: 12, color: 'var(--muted)' }}>{s.created_by_name}</td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </div>
                    {totalPages > 1 && (
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 12 }}>
                        <button className="btn btn-outline btn-sm" disabled={currentPage === 1}
                          onClick={() => setCompletedPage(p => p - 1)}>← Prev</button>
                        <span style={{ fontSize: 13, color: 'var(--muted)' }}>Page {currentPage} of {totalPages}</span>
                        <button className="btn btn-outline btn-sm" disabled={currentPage === totalPages}
                          onClick={() => setCompletedPage(p => p + 1)}>Next →</button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })()}
        </div>
      )}

      {/* ══ APPROVALS ══════════════════════════════════════════════════════════ */}
      {tab === 'approvals' && (() => {
        const pendingReqs = requests.filter(r => r.status === 'PENDING');
        const deniedReqs  = requests.filter(r => r.status === 'DENIED');
        return (
        <div>
          {/* sub-tab bar + New Request button */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, flexWrap: 'wrap' as const, gap: 10 }}>
            <div className="tabs" style={{ marginBottom: 0 }}>
              <button className={`tab-btn ${approvalSub === 'pending' ? 'active' : ''}`}
                onClick={() => setApprovalSub('pending')}>
                Pending{pendingReqs.length > 0 ? ` (${pendingReqs.length})` : ''}
              </button>
              <button className={`tab-btn ${approvalSub === 'denied' ? 'active' : ''}`}
                onClick={() => setApprovalSub('denied')}>
                Denied{deniedReqs.length > 0 ? ` (${deniedReqs.length})` : ''}
              </button>
            </div>
            <button className="btn btn-primary btn-sm" style={{ background: '#7c3aed' }}
              onClick={() => { setShowNewReq(true); setFormError(''); setForm({ request_type: 'ONE_ON_ONE_SL', kid_ids: [], message: '' }); }}>
              + New Session Request
            </button>
          </div>

          {reqLoading ? <p style={{ color: 'var(--muted)' }}>Loading…</p> : (
            <>
              {/* PENDING sub-tab */}
              {approvalSub === 'pending' && (
                pendingReqs.length === 0 ? (
                  <div className="card">
                    <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '32px 0' }}>
                      No pending requests. Click "+ New Session Request" to request a 1:1 session from your Spiritual Leader.
                    </p>
                  </div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column' as const, gap: 12 }}>
                    {pendingReqs.map((r: any) => (
                      <div key={r.request_id} className="card" style={{ borderColor: '#a78bfa', borderWidth: 2 }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap' as const, gap: 8 }}>
                          <span style={{ fontSize: 14, fontWeight: 600 }}>
                            {r.request_type === 'ONE_ON_ONE_SL' ? '1:1 with Spiritual Leader' : '1:1 for my teen(s)'}
                          </span>
                          <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 10, fontWeight: 700, background: '#ede9fe', color: '#5b21b6' }}>
                            ⏳ PENDING REVIEW
                          </span>
                        </div>
                        <p style={{ fontSize: 13, margin: '8px 0 0', color: '#374151' }}>{r.message}</p>
                        <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 4 }}>
                          Requested: {r.created_at?.slice(0, 10)}
                        </div>
                        <p style={{ fontSize: 12, color: '#6b7280', marginTop: 6, fontStyle: 'italic' }}>
                          Awaiting review by Spiritual Leader.
                        </p>
                      </div>
                    ))}
                  </div>
                )
              )}

              {/* DENIED sub-tab */}
              {approvalSub === 'denied' && (
                deniedReqs.length === 0 ? (
                  <div className="card">
                    <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '32px 0' }}>No denied requests.</p>
                  </div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column' as const, gap: 12 }}>
                    {deniedReqs.map((r: any) => (
                      <div key={r.request_id} className="card" style={{ borderColor: '#fca5a5', borderWidth: 2 }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap' as const, gap: 8 }}>
                          <span style={{ fontSize: 14, fontWeight: 600 }}>
                            {r.request_type === 'ONE_ON_ONE_SL' ? '1:1 with Spiritual Leader' : '1:1 for my teen(s)'}
                          </span>
                          <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 10, fontWeight: 700, background: '#fee2e2', color: '#991b1b' }}>
                            ❌ DENIED
                          </span>
                        </div>
                        <p style={{ fontSize: 13, margin: '8px 0 0', color: '#374151' }}>{r.message}</p>
                        {r.review_note && (
                          <div style={{ marginTop: 8, padding: '8px 12px', background: '#fef2f2', borderRadius: 8, borderLeft: '3px solid #dc2626' }}>
                            <strong style={{ fontSize: 12, color: '#dc2626' }}>Reason for denial:</strong>
                            <p style={{ fontSize: 13, margin: '4px 0 0', color: '#374151' }}>{r.review_note}</p>
                          </div>
                        )}
                        <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 6 }}>
                          Requested: {r.created_at?.slice(0, 10)}
                        </div>
                        <p style={{ fontSize: 12, color: '#6b7280', marginTop: 4, fontStyle: 'italic' }}>
                          This request was denied. You may submit a new request if needed.
                        </p>
                      </div>
                    ))}
                  </div>
                )
              )}
            </>
          )}
        </div>
        );
      })()}

      {/* ══ NEW REQUEST MODAL ══════════════════════════════════════════════════ */}
      {showNewReq && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
          <div className="card" style={{ width: '100%', maxWidth: 500, margin: 0 }}>
            <div className="card-title">Request 1:1 Session with Spiritual Leader</div>
            <div className="field">
              <label className="required">Request Type</label>
              <select value={form.request_type}
                onChange={e => setForm(f => ({ ...f, request_type: e.target.value, kid_ids: [] }))}>
                <option value="ONE_ON_ONE_SL">1:1 with Spiritual Leader (for me)</option>
                <option value="ONE_ON_ONE_KID">1:1 for my teen(s)</option>
              </select>
            </div>
            {form.request_type === 'ONE_ON_ONE_KID' && (
              <div className="field">
                <label className="required">Select Teen(s)</label>
                <div style={{ border: '1px solid var(--border)', borderRadius: 8, padding: '10px 14px', maxHeight: 180, overflowY: 'auto' as const, background: '#fafafa' }}>
                  {allKids.map((k: any) => (
                    <label key={k.kid_id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0', cursor: 'pointer', fontSize: 13 }}>
                      <input type="checkbox" checked={form.kid_ids.includes(k.kid_id)}
                        onChange={() => setForm(f => ({
                          ...f,
                          kid_ids: f.kid_ids.includes(k.kid_id)
                            ? f.kid_ids.filter(i => i !== k.kid_id)
                            : [...f.kid_ids, k.kid_id],
                        }))} />
                      {k.first_name} {k.last_name}
                      <span style={{ color: 'var(--muted)', fontSize: 11 }}>({k.registration_id})</span>
                    </label>
                  ))}
                </div>
                {form.kid_ids.length > 0 && (
                  <p style={{ fontSize: 12, color: 'var(--primary)', marginTop: 4 }}>{form.kid_ids.length} selected</p>
                )}
              </div>
            )}
            <div className="field">
              <label className="required">Message / Details</label>
              <textarea rows={4} value={form.message}
                onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
                placeholder="Describe the purpose of this session…" maxLength={500} />
              <span style={{ fontSize: 12, color: 'var(--muted)' }}>{form.message.length}/500</span>
            </div>
            {formError && <div className="alert alert-error" style={{ marginBottom: 8 }}>{formError}</div>}
            <div className="btn-row">
              <button className="btn btn-outline btn-sm"
                onClick={() => { setShowNewReq(false); setFormError(''); }}>Cancel</button>
              <button className="btn btn-primary btn-sm" style={{ background: '#7c3aed' }}
                onClick={handleSubmitRequest} disabled={saving}>
                {saving ? 'Submitting…' : '📤 Send Request'}
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
