import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { getKid, deleteKid, getSpiritualKidNotes, signKid, unlockKid, createEditRequest, requestChangesForKid, approveKidSubmission, createSpiritualSession, getSpiritualKidsList } from '../api';
import { useAuth } from '../AuthContext';

const printStyles = `
@media print {
  body * { visibility: hidden !important; }
  #kid-print-view, #kid-print-view * { visibility: visible !important; }
  #kid-print-view { position: fixed; left: 0; top: 0; width: 100%; background: #fff; padding: 24px; z-index: 9999; }
  .no-print { display: none !important; }
}
`;

function StatusBadge({ isSigned }: { isSigned: boolean }) {
  if (isSigned) return <span style={{ background: '#f59e0b', color: '#fff', borderRadius: 12, padding: '2px 10px', fontSize: 12, fontWeight: 700 }}>✍️ Signed</span>;
  return <span style={{ background: '#94a3b8', color: '#fff', borderRadius: 12, padding: '2px 10px', fontSize: 12, fontWeight: 700 }}>📝 Unsigned</span>;
}

function SubmissionBadge({ status }: { status: string }) {
  const cfg: Record<string, { bg: string; color: string; label: string }> = {
    DRAFT:    { bg: '#e2e3e5', color: '#383d41', label: '📝 Draft' },
    PENDING:  { bg: '#fff3cd', color: '#856404', label: '⏳ Pending Approval' },
    APPROVED: { bg: '#d1e7dd', color: '#0a3622', label: '✅ Approved' },
    DENIED:   { bg: '#f8d7da', color: '#721c24', label: '❌ Changes Requested' },
  };
  const s = cfg[status] || cfg.DRAFT;
  return <span style={{ background: s.bg, color: s.color, borderRadius: 12, padding: '2px 10px', fontSize: 12, fontWeight: 700 }}>{s.label}</span>;
}

export default function KidProfilePage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { isAdmin, isMentor, canEdit, isSpiritualLeader, user } = useAuth();
  const [kid, setKid] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [spiritNotes, setSpiritNotes] = useState<any[]>([]);
  const [spiritOpen, setSpiritOpen] = useState(false);

  // Schedule Session (for SL / Admin)
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [scheduleForm, setScheduleForm] = useState({
    session_date: new Date().toISOString().slice(0, 10),
    topic: '',
    session_type: 'ONE_ON_ONE_KID',
    additionalKidIds: [] as string[],
  });
  const [allKids, setAllKids] = useState<any[]>([]);
  const [scheduleSaving, setScheduleSaving] = useState(false);
  const [scheduleError, setScheduleError] = useState('');

  // Action states
  const [actionLoading, setActionLoading] = useState(false);
  const [actionMsg, setActionMsg] = useState('');
  const [actionError, setActionError] = useState('');

  // Request edit modal (non-admin: ask admin to unlock)
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [requestReason, setRequestReason] = useState('');
  const [requestSaving, setRequestSaving] = useState(false);
  const [requestMsg, setRequestMsg] = useState('');

  // Request changes modal (admin: send approved record back to data-entry)
  const [showReqChangesModal, setShowReqChangesModal] = useState(false);
  const [reqChangesNote, setReqChangesNote]     = useState('');
  const [reqChangesSaving, setReqChangesSaving]  = useState(false);

  const reload = () => {
    if (id) getKid(id).then(setKid);
  };

  // Auto-dismiss messages after 2s
  useEffect(() => {
    if (actionMsg) { const t = setTimeout(() => setActionMsg(''), 2000); return () => clearTimeout(t); }
  }, [actionMsg]);
  useEffect(() => {
    if (requestMsg) { const t = setTimeout(() => setRequestMsg(''), 2000); return () => clearTimeout(t); }
  }, [requestMsg]);

  useEffect(() => {
    if (id) {
      getKid(id).then(setKid).finally(() => setLoading(false));
      if (isAdmin || isMentor || isSpiritualLeader) {
        getSpiritualKidNotes(id).then(setSpiritNotes).catch(() => setSpiritNotes([]));
      }
    }
    if (isSpiritualLeader || isAdmin) {
      getSpiritualKidsList().then(setAllKids).catch(() => {});
    }
  }, [id]);

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to soft-delete this record? It will be hidden but not permanently removed.')) return;
    await deleteKid(id!);
    navigate('/existing');
  };

  const handleApproveSingle = async () => {
    if (!window.confirm('Approve & sign this registration?')) return;
    setActionLoading(true); setActionMsg(''); setActionError('');
    try { await approveKidSubmission(id!); setActionMsg('Registration approved and signed!'); window.dispatchEvent(new CustomEvent('tc-refresh-counts')); reload(); }
    catch (e: any) { setActionError(e.response?.data?.error || 'Approve failed'); }
    finally { setActionLoading(false); }
  };

  const handleSign = async () => {
    if (!window.confirm('Sign this registration? It will be locked. Only the admin can unlock it after approving an edit request.')) return;
    setActionLoading(true); setActionMsg(''); setActionError('');
    try { await signKid(id!); setActionMsg('Registration signed and locked successfully.'); reload(); }
    catch (e: any) { setActionError(e.response?.data?.error || 'Sign failed'); }
    finally { setActionLoading(false); }
  };

  const handleUnlock = async () => {
    if (!window.confirm('Unlock this record? The sign flag will be cleared.')) return;
    setActionLoading(true); setActionMsg(''); setActionError('');
    try { await unlockKid(id!); setActionMsg('Record unlocked.'); reload(); }
    catch (e: any) { setActionError(e.response?.data?.error || 'Unlock failed'); }
    finally { setActionLoading(false); }
  };

  const handleRequestChanges = async () => {
    if (!reqChangesNote.trim()) { setActionError('Please describe what changes are needed.'); return; }
    setReqChangesSaving(true); setActionError('');
    try {
      await requestChangesForKid(id!, reqChangesNote.trim());
      setActionMsg('Changes requested — the record has been sent back to the data-entry person for correction.');
      setShowReqChangesModal(false); setReqChangesNote('');
      reload();
    } catch (e: any) { setActionError(e.response?.data?.error || 'Request failed'); }
    finally { setReqChangesSaving(false); }
  };

  const handleRequestEdit = async () => {
    if (!requestReason.trim()) { setActionError('Please provide a reason for the edit request.'); return; }
    setRequestSaving(true); setActionError('');
    try {
      await createEditRequest({
        entity_type: 'KID',
        entity_id: id!,
        entity_label: `${kid.first_name} ${kid.last_name} (${kid.registration_id})`,
        reason: requestReason.trim(),
      });
      setRequestMsg('Edit request submitted. The admin will review and unlock the record.');
      setShowRequestModal(false);
      setRequestReason('');
    } catch (e: any) { setActionError(e.response?.data?.error || 'Request failed'); }
    finally { setRequestSaving(false); }
  };

  if (loading) return <main className="page"><p>Loading...</p></main>;
  if (!kid) return <main className="page"><p style={{ color: 'var(--danger)' }}>Record not found.</p></main>;

  const age = kid.age_snapshot;
  const ageGroup = age <= 12 ? '10–12 yrs' : age <= 15 ? '13–15 yrs' : '16–18 yrs';
  const isLocked = !!kid.is_signed;

  const handlePrint = () => window.print();

  const PrintView = () => (
    <div id="kid-print-view" style={{ display: 'none' }}>
      <style>{printStyles}</style>
      {/* Print Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', borderBottom: '2px solid #333', paddingBottom: 16, marginBottom: 20 }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: '#666', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 4 }}>Peter Foundation Teen's Club</div>
          <h1 style={{ fontSize: 26, fontWeight: 800, margin: '0 0 4px' }}>{kid.first_name} {kid.last_name}</h1>
          <div style={{ fontSize: 13, color: '#555', marginBottom: 4 }}>Registration ID: <strong>{kid.registration_id}</strong></div>
          <div style={{ fontSize: 13, color: '#555' }}>
            {kid.gender || '—'} · Age {age} · DOB: {kid.dob}
          </div>
        </div>
        {kid.photo_data && (
          <img src={kid.photo_data} alt={kid.first_name}
            style={{ width: 100, height: 100, objectFit: 'cover', borderRadius: 8, border: '2px solid #999', marginLeft: 20, flexShrink: 0 }} />
        )}
      </div>
      {/* Personal Details */}
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13, marginBottom: 20 }}>
        <tbody>
          <tr style={{ background: '#f0f4f8' }}><td colSpan={4} style={{ padding: '6px 8px', fontWeight: 700, fontSize: 14 }}>📚 Education &amp; Contact</td></tr>
          <tr><td style={{ padding: '4px 8px', color: '#555', width: '25%' }}>Education Level</td><td style={{ padding: '4px 8px', width: '25%' }}>{kid.education_level || '—'}</td>
              <td style={{ padding: '4px 8px', color: '#555', width: '25%' }}>Class / Grade</td><td style={{ padding: '4px 8px' }}>{kid.grade_year || '—'}</td></tr>
          <tr><td style={{ padding: '4px 8px', color: '#555' }}>School / College</td><td style={{ padding: '4px 8px' }} colSpan={3}>{kid.school_name || '—'}</td></tr>
          <tr><td style={{ padding: '4px 8px', color: '#555' }}>Phone</td><td style={{ padding: '4px 8px' }}>{kid.phone_normalized || '—'}</td>
              <td style={{ padding: '4px 8px', color: '#555' }}>Address</td><td style={{ padding: '4px 8px' }}>{kid.address || '—'}</td></tr>
          <tr><td style={{ padding: '4px 8px', color: '#555' }}>Baptism</td><td style={{ padding: '4px 8px' }}>{kid.baptism_confirmed ? '✓ Confirmed' : '—'}</td>
              <td style={{ padding: '4px 8px', color: '#555' }}>Consent</td><td style={{ padding: '4px 8px' }}>{kid.consent_participate ? '✓ Yes' : '—'}</td></tr>
        </tbody>
      </table>
      {/* Hobbies & Interests */}
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13, marginBottom: 20 }}>
        <tbody>
          <tr style={{ background: '#f0f4f8' }}><td colSpan={2} style={{ padding: '6px 8px', fontWeight: 700, fontSize: 14 }}>🎭 Hobbies &amp; Interests</td></tr>
          <tr>
            <td style={{ padding: '4px 8px', color: '#555', verticalAlign: 'top', width: '50%' }}>
              <strong>Hobbies:</strong> {kid.hobbies?.map((h: any) => h.name).join(', ') || 'None'}
            </td>
            <td style={{ padding: '4px 8px', color: '#555', verticalAlign: 'top' }}>
              <strong>Interests:</strong> {kid.interests?.map((i: any) => i.name).join(', ') || 'None'}
            </td>
          </tr>
        </tbody>
      </table>
      {/* Ambition */}
      {kid.ambition_goal && (
        <div style={{ marginBottom: 20, padding: '8px 12px', border: '1px solid #ddd', borderRadius: 6 }}>
          <strong style={{ fontSize: 13 }}>🎯 Ambition / Goal:</strong>
          <p style={{ margin: '4px 0 0', fontSize: 13, color: '#444' }}>{kid.ambition_goal}</p>
        </div>
      )}
      {/* Parents */}
      {kid.parents?.length > 0 && (
        <div style={{ marginBottom: 20 }}>
          <div style={{ background: '#f0f4f8', padding: '6px 8px', fontWeight: 700, fontSize: 14, marginBottom: 8 }}>👨‍👩‍👦 Parent / Guardian Details</div>
          {kid.parents.map((p: any) => (
            <table key={p.parent_id} style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13, marginBottom: 10 }}>
              <tbody>
                <tr><td colSpan={4} style={{ padding: '4px 8px', fontWeight: 700 }}>{p.full_name} ({p.relationship})</td></tr>
                <tr><td style={{ padding: '3px 8px', color: '#555', width: '25%' }}>Phone</td><td style={{ padding: '3px 8px', width: '25%' }}>{p.phone_normalized || '—'}</td>
                    <td style={{ padding: '3px 8px', color: '#555', width: '25%' }}>Email</td><td style={{ padding: '3px 8px' }}>{p.email || '—'}</td></tr>
                <tr><td style={{ padding: '3px 8px', color: '#555' }}>Occupation</td><td style={{ padding: '3px 8px' }}>{p.occupation || '—'}</td>
                    <td style={{ padding: '3px 8px', color: '#555' }}>Baptism</td><td style={{ padding: '3px 8px' }}>{p.baptism_confirmed ? '✓ Confirmed' : '—'}</td></tr>
                {p.emergency_contact_name && <tr><td style={{ padding: '3px 8px', color: '#555' }}>Emergency</td><td colSpan={3} style={{ padding: '3px 8px' }}>{p.emergency_contact_name} — {p.emergency_contact_phone}</td></tr>}
              </tbody>
            </table>
          ))}
        </div>
      )}
      {/* Footer */}
      <div style={{ marginTop: 30, borderTop: '1px solid #ccc', paddingTop: 10, fontSize: 11, color: '#888', display: 'flex', justifyContent: 'space-between' }}>
        <span>Printed on {new Date().toLocaleDateString()}</span>
        <span>Peter Foundation Teen's Club — Confidential</span>
        <span>Signed: {kid.is_signed ? `${kid.signed_by} (${kid.signed_at?.slice(0, 10)})` : 'Not signed'}</span>
      </div>
    </div>
  );

  return (
    <main className="page">
      {isAdmin && <PrintView />}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24 }}>
        <button className="btn btn-outline btn-sm no-print" onClick={() => navigate(-1)}>← Back</button>
        <div style={{ flex: 1 }} />
        {isAdmin && (
          <button className="btn btn-outline btn-sm no-print" onClick={handlePrint} style={{ borderColor: '#6f42c1', color: '#6f42c1' }}>
            🖨 Print / PDF
          </button>
        )}
        {canEdit && !isLocked && (
          <button className="btn btn-primary btn-sm no-print" onClick={() => navigate(`/register/${id}`)}>✏️ Edit</button>
        )}
        {canEdit && isLocked && isAdmin && (
          <button className="btn btn-primary btn-sm no-print" onClick={() => navigate(`/register/${id}`)}>✏️ Edit (Admin)</button>
        )}
        {isMentor && !isLocked && kid?.mentor_edit_user_id === user?.user_id && (
          <button className="btn btn-primary btn-sm no-print" onClick={() => navigate(`/register/${id}`)}>✏️ Edit</button>
        )}
        {(isMentor || isAdmin) && (
          <button className="btn btn-outline btn-sm no-print" onClick={() => navigate(`/notes/${id}`)}>🗒 Session Notes</button>
        )}
        {(isSpiritualLeader || isAdmin) && (
          <button className="btn btn-sm no-print" style={{ background: '#7c3aed', color: '#fff', border: 'none', borderRadius: 6 }}
            onClick={() => { setShowScheduleModal(true); setScheduleError(''); }}>
            📅 Schedule Session
          </button>
        )}
        {isAdmin && <button className="btn btn-danger btn-sm no-print" onClick={handleDelete}>🗑 Delete</button>}
      </div>

      {/* Status messages */}
      {actionMsg   && <div className="alert alert-success">{actionMsg}</div>}
      {actionError && <div className="alert alert-error">{actionError}</div>}
      {requestMsg  && <div className="alert alert-success">{requestMsg}</div>}

      {/* Locked banner for non-admin */}
      {isLocked && !isAdmin && (
        <div className="alert" style={{ background: '#fff7ed', border: '1px solid #f97316', color: '#c2410c', marginBottom: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span>🔒 This record is signed and locked. To make changes, submit an edit request.</span>
          <button className="btn btn-sm" style={{ background: '#f97316', color: '#fff', border: 'none' }}
            onClick={() => { setShowRequestModal(true); setActionError(''); }}>
            📩 Request Edit
          </button>
        </div>
      )}

      {/* Header */}
      <div className="card" style={{ marginBottom: 16 }}>
        <div className="profile-header">
          <div style={{ display: 'flex', gap: 20, alignItems: 'flex-start' }}>
            {kid.photo_data && (
              <img src={kid.photo_data} alt={kid.first_name}
                style={{ width: 110, height: 110, objectFit: 'cover', borderRadius: 12, border: '2px solid var(--border)', flexShrink: 0 }} />
            )}
            <div>
              <div className="profile-reg-id">{kid.registration_id}</div>
              <h1 style={{ fontSize: 26, fontWeight: 800, marginTop: 4 }}>
                {kid.first_name} {kid.last_name}
              </h1>
              <p style={{ color: 'var(--muted)', marginTop: 4 }}>
                {kid.gender || 'Gender not specified'} · Age {age} ({ageGroup})
              </p>
            </div>
          </div>
          <div style={{ textAlign: 'right', fontSize: 13, color: 'var(--muted)' }}>
            <div style={{ marginBottom: 6, display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'flex-end' }}>
              <StatusBadge isSigned={!!kid.is_signed} />
              <SubmissionBadge status={kid.submission_status || 'DRAFT'} />
            </div>
            <div>DOB: <strong>{kid.dob}</strong></div>
            <div>Registered: <strong>{kid.created_at?.slice(0, 10)}</strong></div>
            {kid.is_signed && (
              <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 4 }}>Signed by {kid.signed_by} on {kid.signed_at?.slice(0, 10)}</div>
            )}
            {kid.baptism_confirmed ? <div style={{ color: 'var(--success)', marginTop: 4 }}>✝️ Baptism Confirmed</div> : null}
          </div>
        </div>

        {/* Sign / Unlock action bar */}
        {canEdit && (
          <div style={{ marginTop: 16, paddingTop: 16, borderTop: '1px solid var(--border)', display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
        {/* Approve & Sign button for PENDING records (admin only) */}
            {isAdmin && kid.submission_status === 'PENDING' && (
              <button className="btn btn-sm" style={{ background: '#28a745', color: '#fff', border: 'none', fontWeight: 700 }}
                onClick={handleApproveSingle} disabled={actionLoading}>
                ✅ Approve & Sign
              </button>
            )}
            {!kid.is_signed && kid.submission_status !== 'PENDING' && (
              <button className="btn btn-sm" style={{ background: '#f59e0b', color: '#fff' }} onClick={handleSign} disabled={actionLoading}>
                ✍️ Sign Registration
              </button>
            )}
            {isAdmin && isLocked && (
              <button className="btn btn-outline btn-sm" onClick={handleUnlock} disabled={actionLoading}>
                🔓 Unlock Record
              </button>
            )}
            {isAdmin && kid.submission_status === 'APPROVED' && kid.creator_role !== 'ADMIN' && kid.created_by_user_id && (
              <button className="btn btn-sm" style={{ background: '#6f42c1', color: '#fff', border: 'none' }}
                onClick={() => { setShowReqChangesModal(true); setActionError(''); }}>
                🔄 Request Changes
              </button>
            )}
            {!isAdmin && isLocked && (
              <button className="btn btn-sm" style={{ background: '#f97316', color: '#fff', border: 'none' }}
                onClick={() => { setShowRequestModal(true); setActionError(''); }}>
                📩 Request Edit
              </button>
            )}
          </div>
        )}
      </div>

      {/* Request Changes Modal (admin → data-entry) */}
      {showReqChangesModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
          <div className="card" style={{ width: '100%', maxWidth: 500, margin: 0 }}>
            <div className="card-title">🔄 Request Changes from Data-Entry</div>
            <p style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 12 }}>
              Describe what needs to be corrected. This record will be sent back to the original data-entry person as <strong>DENIED</strong> with your note. They will be notified and must fix and resubmit.
            </p>
            <div className="field">
              <label className="required">Changes Required</label>
              <textarea rows={4} value={reqChangesNote} onChange={e => setReqChangesNote(e.target.value)}
                placeholder="e.g. Please correct the date of birth and add the parent's phone number." maxLength={500} />
              <span style={{ fontSize: 12, color: 'var(--muted)' }}>{reqChangesNote.length}/500</span>
            </div>
            {actionError && <div className="alert alert-error" style={{ marginBottom: 8 }}>{actionError}</div>}
            <div className="btn-row">
              <button className="btn btn-outline btn-sm" onClick={() => { setShowReqChangesModal(false); setActionError(''); }}>Cancel</button>
              <button className="btn btn-sm" style={{ background: '#6f42c1', color: '#fff', border: 'none' }}
                onClick={handleRequestChanges} disabled={reqChangesSaving}>
                {reqChangesSaving ? 'Sending...' : '🔄 Send Back for Changes'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Request Edit Modal (non-admin → ask admin to unlock) */}
      {showRequestModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
          <div className="card" style={{ width: '100%', maxWidth: 480, margin: 0 }}>
            <div className="card-title">📩 Request to Edit Registration</div>
            <p style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 12 }}>
              Describe what needs to be changed. The admin will review and unlock the record if approved.
            </p>
            <div className="field">
              <label className="required">Reason for Edit</label>
              <textarea rows={4} value={requestReason} onChange={e => setRequestReason(e.target.value)}
                placeholder="e.g. Incorrect phone number, wrong date of birth, need to update school name..." maxLength={500} />
              <span style={{ fontSize: 12, color: 'var(--muted)' }}>{requestReason.length}/500</span>
            </div>
            {actionError && <div className="alert alert-error" style={{ marginBottom: 8 }}>{actionError}</div>}
            <div className="btn-row">
              <button className="btn btn-outline btn-sm" onClick={() => { setShowRequestModal(false); setActionError(''); }}>Cancel</button>
              <button className="btn btn-primary btn-sm" onClick={handleRequestEdit} disabled={requestSaving}>
                {requestSaving ? 'Submitting...' : '📩 Submit Request'}
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="form-grid" style={{ marginBottom: 16 }}>
        {/* Education */}
        <div className="card">
          <div className="card-title">📚 Education</div>
          <table style={{ width: '100%' }}>
            <tbody>
              <tr><td style={{ color: 'var(--muted)', paddingBottom: 6 }}>Level</td><td>{kid.education_level || '—'}</td></tr>
              <tr><td style={{ color: 'var(--muted)', paddingBottom: 6 }}>School / College</td><td>{kid.school_name || '—'}</td></tr>
              <tr><td style={{ color: 'var(--muted)', paddingBottom: 6 }}>Class / Grade</td><td>{kid.grade_year || '—'}</td></tr>
            </tbody>
          </table>
        </div>

        {/* Contact */}
        <div className="card">
          <div className="card-title">📞 Contact & Location</div>
          <table style={{ width: '100%' }}>
            <tbody>
              <tr><td style={{ color: 'var(--muted)', paddingBottom: 6 }}>Phone</td><td>{kid.phone_normalized || '—'}</td></tr>
              <tr><td style={{ color: 'var(--muted)', paddingBottom: 6 }}>Address</td><td>{kid.address || '—'}</td></tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Hobbies & Interests */}
      <div className="card" style={{ marginBottom: 16 }}>
        <div className="card-title">🎭 Hobbies & Interests</div>
        <div style={{ marginBottom: 12 }}>
          <div style={{ fontWeight: 600, marginBottom: 6, fontSize: 13 }}>Hobbies</div>
          {kid.hobbies?.length
            ? kid.hobbies.map((h: any) => <span key={h.hobby_id} className="hobby-chip">{h.name}</span>)
            : <span style={{ color: 'var(--muted)' }}>None selected</span>}
        </div>
        <div>
          <div style={{ fontWeight: 600, marginBottom: 6, fontSize: 13 }}>Interests</div>
          {kid.interests?.length
            ? kid.interests.map((i: any) => <span key={i.interest_id} className="interest-chip">{i.name}</span>)
            : <span style={{ color: 'var(--muted)' }}>None selected</span>}
        </div>
      </div>

      {/* Goals & Comments */}
      <div className="form-grid" style={{ marginBottom: 16 }}>
        <div className="card">
          <div className="card-title">🎯 Ambition / Goal</div>
          <p style={{ color: kid.ambition_goal ? 'var(--text)' : 'var(--muted)', lineHeight: 1.6 }}>
            {kid.ambition_goal || 'Not provided'}
          </p>
        </div>
        <div className="card">
          <div className="card-title">📝 Additional Comments</div>
          <p style={{ color: kid.additional_comments ? 'var(--text)' : 'var(--muted)', lineHeight: 1.6 }}>
            {kid.additional_comments || 'None'}
          </p>
        </div>
      </div>

      {/* Consent */}
      <div className="card" style={{ marginBottom: 16 }}>
        <div className="card-title">✅ Consent Status</div>
        <div style={{ display: 'flex', gap: 24, flexWrap: 'wrap' }}>
          {[
            { label: 'Participation', val: kid.consent_participate },
          ].map(({ label, val }) => (
            <span key={label} style={{ color: val ? 'var(--success)' : 'var(--danger)', fontWeight: 500 }}>
              {val ? '✅' : '❌'} {label}
            </span>
          ))}
        </div>
      </div>

      {/* Parents */}
      {kid.parents?.length > 0 && (
        <div className="card" style={{ marginBottom: 16 }}>
          <div className="card-title">👨‍👩‍👦 Parent / Guardian Details</div>
          <div className={kid.parents.length > 1 ? 'form-grid' : ''}>
            {kid.parents.map((p: any) => (
              <div key={p.parent_id} style={{ padding: 16, border: '1px solid var(--border)', borderRadius: 8 }}>
                <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 8 }}>{p.full_name}</div>
                <table style={{ width: '100%', fontSize: 13 }}>
                  <tbody>
                    <tr><td style={{ color: 'var(--muted)', paddingBottom: 5, width: '40%' }}>Relationship</td><td>{p.relationship}</td></tr>
                    <tr><td style={{ color: 'var(--muted)', paddingBottom: 5 }}>Phone</td><td>{p.phone_normalized || '—'}</td></tr>
                    <tr><td style={{ color: 'var(--muted)', paddingBottom: 5 }}>Email</td><td>{p.email || '—'}</td></tr>
                    <tr><td style={{ color: 'var(--muted)', paddingBottom: 5 }}>Occupation</td><td>{p.occupation || '—'}</td></tr>
                    <tr><td style={{ color: 'var(--muted)', paddingBottom: 5 }}>Education</td><td>{p.education || '—'}</td></tr>
                    <tr><td style={{ color: 'var(--muted)', paddingBottom: 5 }}>Preferred Contact</td><td>{p.preferred_contact || '—'}</td></tr>
                    <tr>
                      <td style={{ color: 'var(--muted)', paddingBottom: 5 }}>Baptism / Confirmation</td>
                      <td style={{ color: p.baptism_confirmed ? 'var(--success)' : 'var(--muted)', fontWeight: p.baptism_confirmed ? 600 : 400 }}>
                        {p.baptism_confirmed ? '✝️ Confirmed' : '—'}
                      </td>
                    </tr>
                    {p.emergency_contact_name && (
                      <tr><td style={{ color: 'var(--muted)', paddingBottom: 5 }}>Emergency Contact</td>
                        <td>{p.emergency_contact_name} — {p.emergency_contact_phone}</td></tr>
                    )}
                  </tbody>
                </table>
                {p.expectation_text && (
                  <div style={{ marginTop: 10, background: '#f8fafc', padding: 10, borderRadius: 6, fontSize: 13 }}>
                    <strong>Aspirations for child:</strong> {p.expectation_text}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Spiritual Notes Section */}
      {(isAdmin || isMentor || isSpiritualLeader) && (
        <div className="card">
          <div
            className="card-title"
            style={{ cursor: 'pointer', userSelect: 'none', display: 'flex', justifyContent: 'space-between' }}
            onClick={() => setSpiritOpen(o => !o)}
          >
            <span>✝️ Spiritual Session Notes ({spiritNotes.length})</span>
            <span>{spiritOpen ? '▲' : '▼'}</span>
          </div>
          {spiritOpen && (
            spiritNotes.length === 0
              ? <p style={{ color: 'var(--muted)', padding: '16px 0', textAlign: 'center' }}>No spiritual notes recorded for this teen yet.</p>
              : spiritNotes.map((n: any) => (
                <div key={n.note_id} style={{ borderBottom: '1px solid var(--border)', paddingBottom: 14, marginBottom: 14 }}>
                  <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 6 }}>
                    <strong>{n.session_date}</strong> · {n.author_name} · {n.created_at?.slice(0, 10)}
                  </div>
                  <p style={{ whiteSpace: 'pre-wrap', lineHeight: 1.7 }}>{n.content}</p>
                  {n.improvement && (
                    <div style={{ marginTop: 8, background: '#fff7ed', padding: '8px 12px', borderRadius: 6, fontSize: 13, borderLeft: '3px solid #f97316' }}>
                      <strong>⚠️ Improvement:</strong> {n.improvement}
                    </div>
                  )}
                  {n.suggestions && (
                    <div style={{ marginTop: 6, background: '#f0fdf4', padding: '8px 12px', borderRadius: 6, fontSize: 13, borderLeft: '3px solid #22c55e' }}>
                      <strong>💡 Suggestions:</strong> {n.suggestions}
                    </div>
                  )}
                </div>
              ))
          )}
        </div>
      )}
      {/* Schedule Session Modal */}
      {showScheduleModal && (isSpiritualLeader || isAdmin) && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
          <div className="card" style={{ width: '100%', maxWidth: 520, margin: 0 }}>
            <div className="card-title">📅 Schedule Spiritual Session</div>
            <p style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 12 }}>
              Create a new session involving <strong>{kid.first_name} {kid.last_name}</strong>.
            </p>
            {scheduleError && <div className="alert alert-error" style={{ marginBottom: 8 }}>{scheduleError}</div>}
            <div className="form-grid">
              <div className="field">
                <label className="required">Session Date</label>
                <input type="date" value={scheduleForm.session_date}
                  onChange={e => setScheduleForm(f => ({ ...f, session_date: e.target.value }))} />
              </div>
              <div className="field">
                <label className="required">Session Type</label>
                <select value={scheduleForm.session_type}
                  onChange={e => setScheduleForm(f => ({ ...f, session_type: e.target.value, additionalKidIds: [] }))}>
                  <option value="ONE_ON_ONE_KID">1:1 with this teen</option>
                  <option value="SMALL_GROUP">Small Group (add more teens)</option>
                </select>
              </div>
              <div className="field form-full">
                <label className="required">Topic / Title</label>
                <input value={scheduleForm.topic}
                  onChange={e => setScheduleForm(f => ({ ...f, topic: e.target.value }))}
                  placeholder="Session topic or title" maxLength={200} />
              </div>
              {scheduleForm.session_type === 'SMALL_GROUP' && (
                <div className="field form-full">
                  <label>Add More Teens to this Group</label>
                  <p style={{ fontSize: 12, color: 'var(--muted)', margin: '0 0 6px' }}>Select additional teens (up to 9 more). {kid.first_name} {kid.last_name} is already included.</p>
                  <div style={{ border: '1px solid var(--border)', borderRadius: 8, padding: '8px 12px', maxHeight: 200, overflowY: 'auto', background: '#fafafa' }}>
                    {allKids.filter((k: any) => k.kid_id !== id).map((k: any) => (
                      <label key={k.kid_id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '3px 0', cursor: 'pointer', fontSize: 13 }}>
                        <input type="checkbox" checked={scheduleForm.additionalKidIds.includes(k.kid_id)}
                          onChange={() => setScheduleForm(f => ({
                            ...f,
                            additionalKidIds: f.additionalKidIds.includes(k.kid_id)
                              ? f.additionalKidIds.filter(i => i !== k.kid_id)
                              : [...f.additionalKidIds, k.kid_id],
                          }))} />
                        {k.first_name} {k.last_name} <span style={{ color: 'var(--muted)', fontSize: 11 }}>({k.registration_id})</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <div className="btn-row">
              <button className="btn btn-outline btn-sm" onClick={() => setShowScheduleModal(false)}>Cancel</button>
              <button className="btn btn-sm" style={{ background: '#7c3aed', color: '#fff', border: 'none' }}
                disabled={scheduleSaving}
                onClick={async () => {
                  if (!scheduleForm.topic.trim()) { setScheduleError('Topic is required'); return; }
                  setScheduleSaving(true); setScheduleError('');
                  try {
                    const body: any = {
                      session_date: scheduleForm.session_date,
                      topic: scheduleForm.topic.trim(),
                      session_type: scheduleForm.session_type,
                      target_id: scheduleForm.session_type === 'ONE_ON_ONE_KID' ? id : null,
                    };
                    if (scheduleForm.session_type === 'SMALL_GROUP') {
                      body.kid_ids = [id!, ...scheduleForm.additionalKidIds];
                    }
                    const res = await createSpiritualSession(body);
                    setShowScheduleModal(false);
                    navigate(`/spiritual/session/${res.session_id}`);
                  } catch (e: any) { setScheduleError(e.response?.data?.error || 'Failed to create session'); }
                  finally { setScheduleSaving(false); }
                }}>
                {scheduleSaving ? 'Creating...' : '✅ Create Session'}
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
