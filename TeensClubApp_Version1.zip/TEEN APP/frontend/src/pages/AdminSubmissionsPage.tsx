import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getPendingSubmissions, approveKidSubmission, approveBatchSubmissions, denyKidSubmission } from '../api';

interface PendingKid {
  kid_id: string;
  registration_id: string;
  first_name: string;
  last_name: string;
  age_snapshot: number;
  gender: string;
  education_level: string;
  phone_normalized: string;
  submission_status: string;
  submitted_at: string;
  submitter_name: string;
  submitter_username: string;
  parents: { full_name: string; relationship: string; phone_normalized: string }[];
}

const AdminSubmissionsPage: React.FC = () => {
  const navigate = useNavigate();
  const [kids, setKids]           = useState<PendingKid[]>([]);
  const [loading, setLoading]     = useState(true);
  const [msg, setMsg]             = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [selected, setSelected]   = useState<Set<string>>(new Set());
  const [saving, setSaving]       = useState(false);
  const [denyKid, setDenyKid]     = useState<PendingKid | null>(null);
  const [denyNote, setDenyNote]   = useState('');

  // Auto-dismiss notifications after 2 seconds
  useEffect(() => {
    if (msg) { const t = setTimeout(() => setMsg(null), 2000); return () => clearTimeout(t); }
  }, [msg]);

  const load = () => {
    setLoading(true); setSelected(new Set());
    getPendingSubmissions()
      .then(setKids)
      .catch(() => setMsg({ type: 'error', text: 'Failed to load submissions' }))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const allIds     = kids.map(k => k.kid_id);
  const allChecked = allIds.length > 0 && allIds.every(id => selected.has(id));
  const toggleOne  = (id: string) => setSelected(s => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const toggleAll  = () => setSelected(allChecked ? new Set() : new Set(allIds));

  const handleApproveSingle = async (kid: PendingKid) => {
    if (!confirm('Approve & sign registration for ' + kid.first_name + ' ' + kid.last_name + '?')) return;
    setSaving(true);
    try { await approveKidSubmission(kid.kid_id); setMsg({ type: 'success', text: kid.first_name + "'s registration approved and signed." }); window.dispatchEvent(new CustomEvent('tc-refresh-counts')); load(); }
    catch (e: any) { setMsg({ type: 'error', text: e.response?.data?.error || 'Failed' }); }
    finally { setSaving(false); }
  };

  const handleApproveBatch = async (ids: string[], label: string) => {
    if (ids.length === 0) return;
    if (!confirm('Approve & sign ' + label + '?')) return;
    setSaving(true);
    try { const r = await approveBatchSubmissions(ids); setMsg({ type: 'success', text: r.approved + ' registration(s) approved and signed.' }); window.dispatchEvent(new CustomEvent('tc-refresh-counts')); load(); }
    catch (e: any) { setMsg({ type: 'error', text: e.response?.data?.error || 'Failed' }); }
    finally { setSaving(false); }
  };

  const handleDenySubmit = async () => {
    if (!denyNote.trim() || !denyKid) return;
    setSaving(true);
    try { await denyKidSubmission(denyKid.kid_id, denyNote.trim()); setMsg({ type: 'success', text: denyKid.first_name + "'s registration denied — reason sent back." }); setDenyKid(null); setDenyNote(''); window.dispatchEvent(new CustomEvent('tc-refresh-counts')); load(); }
    catch (e: any) { setMsg({ type: 'error', text: e.response?.data?.error || 'Failed' }); }
    finally { setSaving(false); }
  };

  return (
    <div style={{ padding: '1.5rem', maxWidth: 960, margin: '0 auto' }}>
      <h2 style={{ marginBottom: '1rem' }}>📋 Pending Registration Submissions</h2>

      {msg && (
        <div style={{ padding: '0.75rem 1rem', borderRadius: 6, marginBottom: '1rem', background: msg.type === 'success' ? '#d4edda' : '#f8d7da', color: msg.type === 'success' ? '#155724' : '#721c24', border: '1px solid ' + (msg.type === 'success' ? '#c3e6cb' : '#f5c6cb') }}>
          {msg.text}<button onClick={() => setMsg(null)} style={{ float: 'right', background: 'none', border: 'none', cursor: 'pointer', fontWeight: 'bold' }}>✕</button>
        </div>
      )}

      {!loading && kids.length > 0 && (
        <div style={{ display: 'flex', gap: 8, marginBottom: 16, flexWrap: 'wrap', alignItems: 'center', padding: '0.75rem', background: '#f8f9fa', borderRadius: 8, border: '1px solid #dee2e6' }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, cursor: 'pointer' }}>
            <input type="checkbox" checked={allChecked} onChange={toggleAll} />
            {allChecked ? 'Deselect All' : 'Select All'}
          </label>
          {selected.size > 0 && (
            <button onClick={() => handleApproveBatch([...selected], selected.size + ' selected registration(s)')} disabled={saving}
              style={{ padding: '0.4rem 1rem', borderRadius: 6, border: 'none', background: '#28a745', color: '#fff', cursor: 'pointer', fontWeight: 600 }}>
              ✅ Approve Selected ({selected.size})
            </button>
          )}
          <button onClick={() => handleApproveBatch(allIds, 'ALL ' + kids.length + ' pending registrations')} disabled={saving}
            style={{ padding: '0.4rem 1rem', borderRadius: 6, border: 'none', background: '#0d6efd', color: '#fff', cursor: 'pointer', fontWeight: 600 }}>
            ✅ Approve All ({kids.length})
          </button>
          <span style={{ fontSize: 12, color: '#6c757d', marginLeft: 'auto' }}>Denial is done one at a time (with reason)</span>
        </div>
      )}

      {loading ? <p>Loading…</p> : kids.length === 0 ? (
        <div style={{ padding: '2rem', textAlign: 'center', background: '#f8f9fa', borderRadius: 8 }}>
          <p style={{ margin: 0, color: '#6c757d' }}>✅ No pending registrations at this time.</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {kids.map(kid => (
            <div key={kid.kid_id} style={{ border: selected.has(kid.kid_id) ? '2px solid #0d6efd' : '1px solid #dee2e6', borderRadius: 8, padding: '1rem', background: selected.has(kid.kid_id) ? '#f0f6ff' : '#fff', boxShadow: '0 1px 3px rgba(0,0,0,.06)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 8 }}>
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
                  <input type="checkbox" checked={selected.has(kid.kid_id)} onChange={() => toggleOne(kid.kid_id)} style={{ marginTop: 4, cursor: 'pointer', width: 16, height: 16 }} />
                  <div>
                    <h3 style={{ margin: '0 0 0.25rem', fontSize: '1.05rem' }}>
                      {kid.first_name} {kid.last_name}
                      <span style={{ marginLeft: 8, fontSize: '0.8rem', color: '#6c757d' }}>#{kid.registration_id}</span>
                    </h3>
                    <p style={{ margin: '0 0 0.3rem', color: '#495057', fontSize: '0.9rem' }}>Age {kid.age_snapshot} · {kid.gender} · {kid.education_level} · 📞 {kid.phone_normalized}</p>
                    {kid.parents?.length > 0 && <p style={{ margin: '0 0 0.3rem', color: '#6c757d', fontSize: '0.85rem' }}>Parent: {kid.parents.map(p => p.full_name + ' (' + p.relationship + ')').join(', ')}</p>}
                    <p style={{ margin: 0, color: '#6c757d', fontSize: '0.8rem' }}>Submitted by <strong>{kid.submitter_name || kid.submitter_username}</strong> on {kid.submitted_at ? new Date(kid.submitted_at).toLocaleString() : '—'}</p>
                  </div>
                </div>
                <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center', flexShrink: 0, flexWrap: 'wrap' }}>
                  <button onClick={() => navigate(`/kid/${kid.kid_id}`)} style={{ padding: '0.4rem 0.9rem', borderRadius: 6, border: '1px solid #6c757d', background: '#fff', color: '#495057', cursor: 'pointer', fontWeight: 500, minHeight: 38 }}>👁 View</button>
                  <button onClick={() => handleApproveSingle(kid)} disabled={saving} style={{ padding: '0.4rem 1rem', borderRadius: 6, border: 'none', background: '#28a745', color: '#fff', cursor: 'pointer', fontWeight: 600, minHeight: 38 }}>✅ Approve</button>
                  <button onClick={() => { setDenyKid(kid); setDenyNote(''); setMsg(null); }} disabled={saving} style={{ padding: '0.4rem 1rem', borderRadius: 6, border: 'none', background: '#dc3545', color: '#fff', cursor: 'pointer', fontWeight: 600, minHeight: 38 }}>❌ Deny</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {denyKid && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
          <div style={{ background: '#fff', borderRadius: 10, padding: '1.5rem', width: '90%', maxWidth: 480, boxShadow: '0 8px 30px rgba(0,0,0,.2)' }}>
            <h3 style={{ marginTop: 0 }}>❌ Deny / Request Changes</h3>
            <p style={{ color: '#495057' }}>Denying: <strong>{denyKid.first_name} {denyKid.last_name}</strong></p>
            <p style={{ color: '#495057', marginBottom: '0.5rem', fontSize: '0.9rem' }}>The reason below will be sent back to the data-entry person so they can correct and resubmit.</p>
            <textarea value={denyNote} onChange={e => setDenyNote(e.target.value)} placeholder="Explain what needs to be corrected…" rows={4}
              style={{ width: '100%', boxSizing: 'border-box', padding: '0.6rem', border: '1px solid #ced4da', borderRadius: 6, fontSize: '0.95rem', resize: 'vertical' }} />
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.5rem', marginTop: '1rem' }}>
              <button onClick={() => { setDenyKid(null); setDenyNote(''); }} style={{ padding: '0.4rem 1rem', borderRadius: 6, border: '1px solid #ccc', background: '#f8f9fa', cursor: 'pointer' }}>Cancel</button>
              <button onClick={handleDenySubmit} disabled={saving || !denyNote.trim()} style={{ padding: '0.4rem 1rem', borderRadius: 6, border: 'none', background: '#dc3545', color: '#fff', cursor: 'pointer', fontWeight: 600 }}>{saving ? 'Saving…' : 'Deny with Reason'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminSubmissionsPage;
