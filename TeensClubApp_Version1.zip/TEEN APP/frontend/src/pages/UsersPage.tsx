import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getUsers, createUser, toggleUser, resetPassword } from '../api';
import { useAuth } from '../AuthContext';

export default function UsersPage() {
  const navigate = useNavigate();
  const { user: currentUser } = useAuth();
  const [users, setUsers] = useState<any[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ username: '', password: '', full_name: '', role: 'DATA_ENTRY' });
  const [resetPwd, setResetPwd] = useState<{ id: string; name: string } | null>(null);
  const [newPwd, setNewPwd] = useState('');
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');

  const load = () => getUsers().then(setUsers);
  useEffect(() => { load(); }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault(); setMsg(''); setError('');
    try {
      await createUser(form);
      setMsg(`User "${form.username}" created successfully!`);
      setForm({ username: '', password: '', full_name: '', role: 'DATA_ENTRY' });
      setShowForm(false);
      load();
    } catch (e: any) { setError(e.response?.data?.error || 'Error creating user'); }
  };

  const handleToggle = async (id: string) => {
    await toggleUser(id); load();
  };

  const handleResetPwd = async () => {
    if (!resetPwd || !newPwd.trim()) return;
    await resetPassword(resetPwd.id, newPwd);
    setMsg(`Password reset for ${resetPwd.name}`);
    setResetPwd(null); setNewPwd('');
  };

  return (
    <main className="page">
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24 }}>
        <button className="btn btn-outline btn-sm" onClick={() => navigate('/')}>← Home</button>
        <h2 style={{ fontSize: 22, fontWeight: 700 }}>👥 User Management</h2>
        <div style={{ flex: 1 }} />
        <button className="btn btn-primary btn-sm" onClick={() => { setShowForm(!showForm); setError(''); setMsg(''); }}>
          {showForm ? 'Cancel' : '+ New User'}
        </button>
      </div>

      {msg && <div className="alert alert-success">{msg}</div>}
      {error && <div className="alert alert-error">{error}</div>}

      {/* Create User Form */}
      {showForm && (
        <div className="card" style={{ marginBottom: 20 }}>
          <div className="card-title">Create New User</div>
          <form onSubmit={handleCreate}>
            <div className="form-grid">
              <div className="field">
                <label className="required">Full Name</label>
                <input value={form.full_name} onChange={e => setForm(f => ({ ...f, full_name: e.target.value }))}
                  placeholder="Full name" required maxLength={80} />
              </div>
              <div className="field">
                <label className="required">Username</label>
                <input value={form.username} onChange={e => setForm(f => ({ ...f, username: e.target.value.toLowerCase().trim() }))}
                  placeholder="username (no spaces)" required maxLength={40} />
              </div>
              <div className="field">
                <label className="required">Password</label>
                <input type="password" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                  placeholder="Min 8 characters" required minLength={6} />
              </div>
              <div className="field">
                <label>Role</label>
                <select value={form.role} onChange={e => setForm(f => ({ ...f, role: e.target.value }))}>
                  <option value="DATA_ENTRY">Data Entry (add/edit registrations, no analytics)</option>
                  <option value="MENTOR">Mentor (view assigned teens + session notes)</option>
                  <option value="ADMIN">Admin (full access)</option>
                  <option value="SPIRITUAL_LEADER">Spiritual Leader (sessions, attendance, notes)</option>
                </select>
              </div>
            </div>
            <div className="btn-row">
              <button type="submit" className="btn btn-success">✅ Create User</button>
            </div>
          </form>
        </div>
      )}

      {/* Users Table */}
      <div className="card">
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Full Name</th>
                <th>Username</th>
                <th>Role</th>
                <th>Status</th>
                <th>Created</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u: any) => (
                <tr key={u.user_id} style={{ cursor: 'default' }} onClick={undefined}>
                  <td><strong>{u.full_name}</strong></td>
                  <td><code>{u.username}</code></td>
                  <td><span className={`badge ${u.role === 'ADMIN' ? 'badge-admin' : u.role === 'MENTOR' ? 'badge-mentor' : u.role === 'SPIRITUAL_LEADER' ? 'badge-sl' : 'badge-sub'}`}>{u.role}</span></td>
                  <td>
                    <span style={{ color: u.is_active ? 'var(--success)' : 'var(--danger)', fontWeight: 500 }}>
                      {u.is_active ? '✅ Active' : '❌ Inactive'}
                    </span>
                  </td>
                  <td style={{ color: 'var(--muted)', fontSize: 12 }}>{u.created_at?.slice(0, 10)}</td>
                  <td style={{ display: 'flex', gap: 8 }}>
                    <button
                      className="btn btn-outline btn-sm"
                      onClick={() => handleToggle(u.user_id)}
                      disabled={u.user_id === currentUser?.user_id}
                      title={u.user_id === currentUser?.user_id ? 'You cannot deactivate your own account' : ''}
                      style={u.user_id === currentUser?.user_id ? { opacity: 0.4, cursor: 'not-allowed' } : {}}
                    >
                      {u.is_active ? 'Deactivate' : 'Activate'}
                    </button>
                    <button className="btn btn-outline btn-sm"
                      onClick={() => { setResetPwd({ id: u.user_id, name: u.full_name }); setNewPwd(''); }}>
                      Reset Pwd
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Reset Password Modal */}
      {resetPwd && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,.4)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 999
        }}>
          <div className="card" style={{ width: 360 }}>
            <div className="card-title">Reset Password for {resetPwd.name}</div>
            <div className="field" style={{ marginBottom: 16 }}>
              <label>New Password</label>
              <input type="password" value={newPwd} onChange={e => setNewPwd(e.target.value)}
                placeholder="Enter new password" autoFocus />
            </div>
            <div className="btn-row">
              <button className="btn btn-outline btn-sm" onClick={() => setResetPwd(null)}>Cancel</button>
              <button className="btn btn-primary btn-sm" onClick={handleResetPwd}>Set Password</button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
