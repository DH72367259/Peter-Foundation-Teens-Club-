import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getEditRequests, approveEditRequest, denyEditRequest, approveBatchEditRequests } from '../api';

const STATUS_TABS = ['PENDING', 'APPROVED', 'DENIED'] as const;
type StatusTab = typeof STATUS_TABS[number];

const ENTITY_LABELS: Record<string, string> = {
  KID: '👦 Registration',
  MENTOR_NOTE: '🗒 Session Note',
  SPIRITUAL_SESSION: '✝️ Spiritual Session',
};

export default function AdminEditRequestsPage() {
  const navigate = useNavigate();
  const [tab, setTab] = useState<StatusTab>('PENDING');
  const [requests, setRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [batchSaving, setBatchSaving] = useState(false);

  // Review modal state
  const [reviewModal, setReviewModal] = useState<{ requestId: string; action: 'approve' | 'deny'; requesterName: string; label: string } | null>(null);
  const [reviewNote, setReviewNote] = useState('');
  const [reviewSaving, setReviewSaving] = useState(false);

  const loadRequests = (status?: StatusTab) => {
    setLoading(true);
    setSelected(new Set());
    getEditRequests(status).then(setRequests).finally(() => setLoading(false));
  };

  useEffect(() => { loadRequests(tab); }, [tab]);

  // Auto-dismiss success/error messages after 2 seconds
  useEffect(() => {
    if (msg) { const t = setTimeout(() => setMsg(''), 2000); return () => clearTimeout(t); }
  }, [msg]);
  useEffect(() => {
    if (error) { const t = setTimeout(() => setError(''), 4000); return () => clearTimeout(t); }
  }, [error]);

  const handleReview = async () => {
    if (!reviewModal) return;
    if (reviewModal.action === 'deny' && !reviewNote.trim()) {
      setError('Please provide a reason for denying the request.'); return;
    }
    setReviewSaving(true); setMsg(''); setError('');
    try {
      if (reviewModal.action === 'approve') {
        await approveEditRequest(reviewModal.requestId, reviewNote.trim() || undefined);
        setMsg(`Request approved — record unlocked for ${reviewModal.requesterName}.`);
      } else {
        await denyEditRequest(reviewModal.requestId, reviewNote.trim());
        setMsg(`Request denied.`);
      }
      window.dispatchEvent(new CustomEvent('tc-refresh-counts'));
      setReviewModal(null);
      setReviewNote('');
      loadRequests(tab);
    } catch (e: any) {
      setError(e.response?.data?.error || 'Action failed');
    } finally {
      setReviewSaving(false);
    }
  };

  const pendingIds = requests.filter(r => r.status === 'PENDING').map(r => r.request_id);
  const allChecked = pendingIds.length > 0 && pendingIds.every((id: string) => selected.has(id));
  const toggleOne  = (id: string) => setSelected(s => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const toggleAll  = () => setSelected(allChecked ? new Set() : new Set(pendingIds));

  const handleApproveBatch = async (ids: string[]) => {
    if (ids.length === 0) return;
    if (!confirm('Approve ' + ids.length + ' selected edit request(s)?')) return;
    setBatchSaving(true); setMsg(''); setError('');
    try {
      const r = await approveBatchEditRequests(ids);
      setMsg(r.approved + ' request(s) approved — records unlocked.');
      loadRequests(tab);
    } catch (e: any) { setError(e.response?.data?.error || 'Batch approve failed'); }
    finally { setBatchSaving(false); }
  };

  const formatDate = (s?: string) => s ? s.slice(0, 16).replace('T', ' ') : '—';

  return (
    <main className="page">
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24 }}>
        <button className="btn btn-outline btn-sm" onClick={() => navigate('/')}>← Home</button>
        <h2 style={{ fontSize: 22, fontWeight: 700 }}>📩 Edit Requests</h2>
      </div>

      {msg   && <div className="alert alert-success">{msg}</div>}
      {error && <div className="alert alert-error">{error}</div>}

      {/* Tabs */}
      <div className="tabs" style={{ marginBottom: 20 }}>
        {STATUS_TABS.map(s => (
          <button key={s} className={`tab-btn ${tab === s ? 'active' : ''}`} onClick={() => { setTab(s); setMsg(''); setError(''); }}>
            {s === 'PENDING' ? '⏳ Pending' : s === 'APPROVED' ? '✅ Approved' : '❌ Denied'}
          </button>
        ))}
      </div>

      {/* Bulk action bar for PENDING tab */}
      {tab === 'PENDING' && !loading && requests.length > 0 && (
        <div style={{ display: 'flex', gap: 8, marginBottom: 16, flexWrap: 'wrap', alignItems: 'center', padding: '0.75rem', background: '#f8f9fa', borderRadius: 8, border: '1px solid #dee2e6' }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, cursor: 'pointer' }}>
            <input type="checkbox" checked={allChecked} onChange={toggleAll} />
            {allChecked ? 'Deselect All' : 'Select All'}
          </label>
          {selected.size > 0 && (
            <button onClick={() => handleApproveBatch([...selected])} disabled={batchSaving}
              style={{ padding: '0.4rem 1rem', borderRadius: 6, border: 'none', background: '#22c55e', color: '#fff', cursor: 'pointer', fontWeight: 600 }}>
              ✅ Approve Selected ({selected.size})
            </button>
          )}
          <button onClick={() => handleApproveBatch(pendingIds)} disabled={batchSaving}
            style={{ padding: '0.4rem 1rem', borderRadius: 6, border: 'none', background: '#0d6efd', color: '#fff', cursor: 'pointer', fontWeight: 600 }}>
            ✅ Approve All ({pendingIds.length})
          </button>
          <span style={{ fontSize: 12, color: '#6c757d', marginLeft: 'auto' }}>Deny is done one at a time (with reason)</span>
        </div>
      )}

      {loading ? (
        <div className="card"><p style={{ color: 'var(--muted)', textAlign: 'center', padding: '32px 0' }}>Loading...</p></div>
      ) : requests.length === 0 ? (
        <div className="card">
          <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '32px 0' }}>
            No {tab.toLowerCase()} requests.
          </p>
        </div>
      ) : (
        requests.map((r: any) => (
          <div key={r.request_id} className="card" style={{ marginBottom: 14, border: tab === 'PENDING' && selected.has(r.request_id) ? '2px solid #0d6efd' : undefined, background: tab === 'PENDING' && selected.has(r.request_id) ? '#f0f6ff' : undefined }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 8 }}>
              {tab === 'PENDING' && (
                <input type="checkbox" checked={selected.has(r.request_id)} onChange={() => toggleOne(r.request_id)}
                  style={{ marginTop: 4, cursor: 'pointer', width: 16, height: 16, flexShrink: 0 }} />
              )}
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 4 }}>
                  {ENTITY_LABELS[r.entity_type] || r.entity_type}
                  {r.entity_label && <span style={{ color: 'var(--muted)', fontWeight: 400, marginLeft: 8, fontSize: 14 }}>{r.entity_label}</span>}
                </div>
                <div style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 6 }}>
                  Requested by <strong>{r.requester_name}</strong> ({r.requester_username}) · {formatDate(r.requested_at)}
                </div>
                <div style={{ fontSize: 14, background: '#f8fafc', padding: '8px 12px', borderRadius: 6, borderLeft: '3px solid #6366f1', marginBottom: 8 }}>
                  <strong>Reason:</strong> {r.reason}
                </div>
                {r.reviewed_at && (
                  <div style={{ fontSize: 12, color: 'var(--muted)' }}>
                    {r.status === 'APPROVED' ? '✅ Approved' : '❌ Denied'} by {r.reviewer_name} on {formatDate(r.reviewed_at)}
                    {r.review_note && <span> — "{r.review_note}"</span>}
                  </div>
                )}
              </div>
              {tab === 'PENDING' && (
                <div style={{ display: 'flex', gap: 8, flexShrink: 0 }}>
                  <button className="btn btn-sm" style={{ background: '#22c55e', color: '#fff' }}
                    onClick={() => { setReviewModal({ requestId: r.request_id, action: 'approve', requesterName: r.requester_name, label: r.entity_label || r.entity_type }); setReviewNote(''); setError(''); }}>
                    ✅ Approve
                  </button>
                  <button className="btn btn-sm" style={{ background: '#ef4444', color: '#fff' }}
                    onClick={() => { setReviewModal({ requestId: r.request_id, action: 'deny', requesterName: r.requester_name, label: r.entity_label || r.entity_type }); setReviewNote(''); setError(''); }}>
                    ❌ Deny
                  </button>
                </div>
              )}
            </div>
          </div>
        ))
      )}

      {/* Review Modal */}
      {reviewModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
          <div className="card" style={{ width: '100%', maxWidth: 480, margin: 0 }}>
            <div className="card-title">
              {reviewModal.action === 'approve' ? '✅ Approve Edit Request' : '❌ Deny Edit Request'}
            </div>
            <p style={{ fontSize: 14, color: 'var(--muted)', marginBottom: 12 }}>
              {reviewModal.action === 'approve'
                ? `Approving will unlock the record "${reviewModal.label}" so ${reviewModal.requesterName} can edit it.`
                : `Denying will keep the record locked. Please provide a reason.`}
            </p>
            <div className="field">
              <label className={reviewModal.action === 'deny' ? 'required' : undefined}>
                {reviewModal.action === 'approve' ? 'Admin Note (optional)' : 'Reason for Denial'}
              </label>
              <textarea rows={3} value={reviewNote} onChange={e => setReviewNote(e.target.value)}
                placeholder={reviewModal.action === 'approve' ? 'Optional note to the requester...' : 'Explain why the request was denied...'}
                maxLength={500} />
            </div>
            {error && <div className="alert alert-error" style={{ marginBottom: 8 }}>{error}</div>}
            <div className="btn-row">
              <button className="btn btn-outline btn-sm" onClick={() => { setReviewModal(null); setError(''); }}>Cancel</button>
              <button
                className="btn btn-primary btn-sm"
                style={reviewModal.action === 'approve' ? { background: '#22c55e' } : { background: '#ef4444' }}
                onClick={handleReview} disabled={reviewSaving}>
                {reviewSaving ? 'Saving...' : reviewModal.action === 'approve' ? '✅ Confirm Approve' : '❌ Confirm Deny'}
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
