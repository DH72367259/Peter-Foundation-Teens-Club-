import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getRecordsKidsList, getRecordsMentorsList, getKidRecord, getMentorRecord, adminUpdateAttendance } from '../api';
import { useAuth } from '../AuthContext';

const TYPE_LABEL: Record<string, string> = {
  GROUP: 'Group', SMALL_GROUP: 'Small Group',
  ALL_MENTORS: 'All Mentors', ONE_ON_ONE_KID: '1:1 Teen', ONE_ON_ONE_MENTOR: '1:1 Mentor',
};
const TYPE_COLOR: Record<string, { bg: string; color: string }> = {
  GROUP:             { bg: '#dbeafe', color: '#1d4ed8' },
  SMALL_GROUP:       { bg: '#e0f2fe', color: '#0369a1' },
  ALL_MENTORS:       { bg: '#fef3c7', color: '#92400e' },
  ONE_ON_ONE_KID:    { bg: '#fce7f3', color: '#be185d' },
  ONE_ON_ONE_MENTOR: { bg: '#f3e8ff', color: '#6b21a8' },
};

const isGroupType      = (t: string) => ['GROUP', 'SMALL_GROUP', 'ALL_MENTORS'].includes(t);
const isIndividualType = (t: string) => ['ONE_ON_ONE_KID', 'ONE_ON_ONE_MENTOR'].includes(t);

const PCT_COLOR = (pct: number) =>
  pct >= 80 ? '#16a34a' : pct >= 50 ? '#d97706' : '#dc2626';

function StatCard({ label, value, color }: { label: string; value: string | number; color: string }) {
  return (
    <div style={{
      background: '#fff', border: '1px solid var(--border)', borderRadius: 10,
      padding: '14px 18px', minWidth: 120, textAlign: 'center',
    }}>
      <div style={{ fontSize: 24, fontWeight: 800, color }}>{value}</div>
      <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--muted)', marginTop: 2 }}>{label}</div>
    </div>
  );
}

function calcStats(arr: any[]) {
  const total    = arr.length;
  const attended = arr.filter(s => s.is_present).length;
  const missed   = total - attended;
  const rate     = total > 0 ? Math.round((attended / total) * 100) : 0;
  return { total, attended, missed, rate };
}

interface SessionSectionProps {
  title: string;
  sessions: any[];
  entityId: string;
  entityType: 'kid' | 'mentor';
  isAdmin: boolean;
  togglingId: string | null;
  onToggle: (session_id: string, entity_id: string, currentPresent: boolean) => void;
  navigate: (path: string) => void;
}

function SessionSection({ title, sessions, entityId, entityType, isAdmin, togglingId, onToggle, navigate }: SessionSectionProps) {
  const stats = calcStats(sessions);
  return (
    <div className="card" style={{ marginBottom: 20 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap' as const, gap: 8, marginBottom: 12 }}>
        <div className="card-title" style={{ marginBottom: 0 }}>{title}</div>
        {sessions.length > 0 && (
          <div style={{ display: 'flex', gap: 12, fontSize: 13 }}>
            <span style={{ color: '#16a34a', fontWeight: 700 }}>✅ {stats.attended} attended</span>
            <span style={{ color: '#dc2626', fontWeight: 700 }}>❌ {stats.missed} missed</span>
            <span style={{ fontWeight: 700, color: PCT_COLOR(stats.rate) }}>{stats.rate}%</span>
          </div>
        )}
      </div>
      {sessions.length === 0 ? (
        <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '16px 0' }}>No sessions of this type.</p>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Topic</th>
                <th>Type</th>
                <th>Attendance</th>
                {isAdmin && <th>Admin Toggle</th>}
              </tr>
            </thead>
            <tbody>
              {sessions.map((s: any) => {
                const isPresent = !!s.is_present;
                const tc = TYPE_COLOR[s.session_type] || { bg: '#e5e7eb', color: '#374151' };
                return (
                  <tr key={s.session_id} style={{ background: isPresent ? '#f0fdf4' : undefined }}>
                    <td><strong>{s.session_date}</strong></td>
                    <td style={{ maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      <span
                        style={{ cursor: 'pointer', color: 'var(--primary)', textDecoration: 'underline' }}
                        onClick={() => navigate(`/spiritual/session/${s.session_id}`)}>
                        {s.topic}
                      </span>
                    </td>
                    <td>
                      <span style={{ fontSize: 11, padding: '1px 7px', borderRadius: 10, fontWeight: 600, background: tc.bg, color: tc.color }}>
                        {TYPE_LABEL[s.session_type] || s.session_type}
                      </span>
                    </td>
                    <td>
                      {isPresent
                        ? <span style={{ color: '#16a34a', fontWeight: 700 }}>✅ Present</span>
                        : <span style={{ color: '#dc2626', fontWeight: 700 }}>❌ Absent</span>}
                    </td>
                    {isAdmin && (
                      <td>
                        <button
                          disabled={togglingId === s.session_id}
                          onClick={() => onToggle(s.session_id, entityId, isPresent)}
                          style={{
                            fontSize: 11, padding: '3px 10px', borderRadius: 5, cursor: 'pointer',
                            background: isPresent ? '#fee2e2' : '#dcfce7',
                            color: isPresent ? '#991b1b' : '#166534',
                            border: `1px solid ${isPresent ? '#fca5a5' : '#86efac'}`,
                            opacity: togglingId === s.session_id ? 0.6 : 1,
                          }}>
                          {togglingId === s.session_id ? '…' : isPresent ? 'Mark Absent' : 'Mark Present'}
                        </button>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default function AttendancePage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const isAdmin = user?.role === 'ADMIN';

  const [viewType,       setViewType]       = useState<'kid' | 'mentor'>('kid');
  const [kidsList,       setKidsList]       = useState<any[]>([]);
  const [mentorsList,    setMentorsList]    = useState<any[]>([]);
  const [selectedKid,    setSelectedKid]    = useState('');
  const [selectedMentor, setSelectedMentor] = useState('');
  const [data,           setData]           = useState<any>(null);
  const [loading,        setLoading]        = useState(false);
  const [togglingId,     setTogglingId]     = useState<string | null>(null);
  const [toggleMsg,      setToggleMsg]      = useState('');

  useEffect(() => {
    getRecordsKidsList().then(setKidsList).catch(() => {});
    getRecordsMentorsList().then(setMentorsList).catch(() => {});
  }, []);

  const loadData = (kt = viewType, kid = selectedKid, mentor = selectedMentor) => {
    if (kt === 'kid' && kid) {
      setLoading(true);
      getKidRecord(kid).then(setData).finally(() => setLoading(false));
    } else if (kt === 'mentor' && mentor) {
      setLoading(true);
      getMentorRecord(mentor).then(setData).finally(() => setLoading(false));
    } else {
      setData(null);
    }
  };

  useEffect(() => { loadData(); }, [viewType, selectedKid, selectedMentor]);

  const handleToggle = async (session_id: string, entity_id: string, currentPresent: boolean) => {
    if (!isAdmin) return;
    setTogglingId(session_id);
    setToggleMsg('');
    try {
      await adminUpdateAttendance({ session_id, entity_type: viewType, entity_id, is_present: !currentPresent });
      setToggleMsg(`Attendance updated to ${!currentPresent ? 'Present' : 'Absent'}`);
      loadData();
    } catch (e: any) {
      setToggleMsg('Error: ' + (e.response?.data?.error || 'Update failed'));
    } finally {
      setTogglingId(null);
    }
  };

  // Derive session lists from fetched data
  let sessions: any[] = [];
  let entityId = '';
  if (viewType === 'kid' && data) {
    sessions  = (data.spiritualSessions || []).filter((s: any) => !s.is_cancelled && s.is_signed);
    entityId  = selectedKid;
  } else if (viewType === 'mentor' && data) {
    sessions  = (data.sessions || []).filter((s: any) => !s.is_cancelled && s.is_signed);
    entityId  = selectedMentor;
  }

  const groupSessions      = sessions.filter(s => isGroupType(s.session_type));
  const individualSessions = sessions.filter(s => isIndividualType(s.session_type));
  const totalStats         = calcStats(sessions);

  const selectedName = viewType === 'kid'
    ? kidsList.find(k => k.kid_id === selectedKid)
    : mentorsList.find(m => m.user_id === selectedMentor);

  return (
    <main className="page">
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 20 }}>
        <button className="btn btn-outline btn-sm" onClick={() => navigate('/')}>← Home</button>
        <h2 style={{ fontSize: 22, fontWeight: 700 }}>✅ Attendance</h2>
      </div>

      {isAdmin && (
        <div className="alert alert-success" style={{ marginBottom: 16, fontSize: 13 }}>
          👤 <strong>Admin Mode:</strong> You can toggle attendance for any signed session. Changes are reflected immediately for all users.
        </div>
      )}

      {/* Person selector */}
      <div className="card" style={{ marginBottom: 20, padding: '16px 20px' }}>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' as const }}>
          <div className="tabs" style={{ marginBottom: 0 }}>
            <button className={`tab-btn ${viewType === 'kid' ? 'active' : ''}`}
              onClick={() => { setViewType('kid'); setSelectedKid(''); setSelectedMentor(''); setData(null); setToggleMsg(''); }}>
              👤 Teen
            </button>
            <button className={`tab-btn ${viewType === 'mentor' ? 'active' : ''}`}
              onClick={() => { setViewType('mentor'); setSelectedKid(''); setSelectedMentor(''); setData(null); setToggleMsg(''); }}>
              🧑‍🏫 Mentor
            </button>
          </div>
          {viewType === 'kid' && (
            <select value={selectedKid} onChange={e => setSelectedKid(e.target.value)} style={{ fontSize: 14, minWidth: 260 }}>
              <option value="">— Select a teen —</option>
              {kidsList.map(k => (
                <option key={k.kid_id} value={k.kid_id}>{k.first_name} {k.last_name} ({k.registration_id})</option>
              ))}
            </select>
          )}
          {viewType === 'mentor' && (
            <select value={selectedMentor} onChange={e => setSelectedMentor(e.target.value)} style={{ fontSize: 14, minWidth: 220 }}>
              <option value="">— Select a mentor —</option>
              {mentorsList.map(m => (
                <option key={m.user_id} value={m.user_id}>{m.full_name} (@{m.username})</option>
              ))}
            </select>
          )}
        </div>
      </div>

      {loading && <p style={{ color: 'var(--muted)' }}>Loading…</p>}

      {!loading && !data && (
        <div className="card">
          <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '32px 0' }}>
            Select a {viewType === 'kid' ? 'teen' : 'mentor'} above to view their attendance breakdown.
          </p>
        </div>
      )}

      {!loading && data && (
        <div>
          {toggleMsg && (
            <div className={`alert ${toggleMsg.startsWith('Error') ? 'alert-error' : 'alert-success'}`} style={{ marginBottom: 16 }}>
              {toggleMsg}
              <button style={{ float: 'right', background: 'none', border: 'none', cursor: 'pointer', fontWeight: 700 }}
                onClick={() => setToggleMsg('')}>✕</button>
            </div>
          )}

          {/* Name + overall stats */}
          <div className="card" style={{ marginBottom: 20, borderColor: 'var(--primary)' }}>
            <div className="card-title">
              {viewType === 'kid' && selectedName
                ? `${selectedName.first_name} ${selectedName.last_name} (${selectedName.registration_id})`
                : selectedName ? `${selectedName.full_name} (@${selectedName.username})` : 'Selected Person'}
            </div>
            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' as const }}>
              <StatCard label="Total Signed Sessions" value={totalStats.total}    color="#1d4ed8" />
              <StatCard label="Attended"               value={totalStats.attended} color="#16a34a" />
              <StatCard label="Missed"                 value={totalStats.missed}   color="#dc2626" />
              <StatCard label="Overall Rate"           value={`${totalStats.rate}%`} color={PCT_COLOR(totalStats.rate)} />
            </div>
          </div>

          {/* Group sessions */}
          <SessionSection
            title="🏛 Group / All-Mentor Sessions"
            sessions={groupSessions}
            entityId={entityId}
            entityType={viewType}
            isAdmin={isAdmin}
            togglingId={togglingId}
            onToggle={handleToggle}
            navigate={navigate}
          />

          {/* Individual / 1:1 sessions */}
          <SessionSection
            title="👤 Individual Sessions (1:1)"
            sessions={individualSessions}
            entityId={entityId}
            entityType={viewType}
            isAdmin={isAdmin}
            togglingId={togglingId}
            onToggle={handleToggle}
            navigate={navigate}
          />
        </div>
      )}
    </main>
  );
}
