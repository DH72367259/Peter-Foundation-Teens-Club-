﻿import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  getSpiritualSessions, createSpiritualSession,
  getSpiritualKidsList, getSpiritualMentors, deleteSpiritualSession,
  getSpiritualUpcoming, getSessionRequests, approveSessionRequest, denySessionRequest,
} from '../api';
import { useAuth } from '../AuthContext';

// helpers
const SESSION_TYPE_LABEL: Record<string, string> = {
  GROUP: 'Group', SMALL_GROUP: 'Small Group', ALL_MENTORS: 'All Mentors',
  ONE_ON_ONE_KID: '1:1 Teen', ONE_ON_ONE_MENTOR: '1:1 Mentor',
};
const SESSION_TYPE_COLOR: Record<string, { bg: string; color: string }> = {
  GROUP:             { bg: '#dbeafe', color: '#1d4ed8' },
  SMALL_GROUP:       { bg: '#e0f2fe', color: '#0369a1' },
  ALL_MENTORS:       { bg: '#fef3c7', color: '#92400e' },
  ONE_ON_ONE_KID:    { bg: '#fce7f3', color: '#be185d' },
  ONE_ON_ONE_MENTOR: { bg: '#f3e8ff', color: '#6b21a8' },
};

function daysUntilLabel(daysUntil: number): { label: string; color: string } {
  if (daysUntil < 0)   return { label: 'Past',       color: '#6b7280' };
  if (daysUntil === 0) return { label: 'Today!',     color: '#dc2626' };
  if (daysUntil === 1) return { label: 'Tomorrow!',  color: '#ea580c' };
  if (daysUntil <= 3)  return { label: `In ${daysUntil} days`, color: '#d97706' };
  if (daysUntil <= 7)  return { label: `In ${daysUntil} days`, color: '#2563eb' };
  return { label: `In ${daysUntil} days`, color: '#6b7280' };
}

export default function SpiritualLeaderPage() {
  const navigate = useNavigate();
  const { isAdmin, isSpiritualLeader } = useAuth();
  const canWrite = isAdmin || isSpiritualLeader;

  // main page tabs
  const [mainTab, setMainTab] = useState<'dashboard' | 'sessions' | 'approvals'>('dashboard');

  // ── approval sub-tabs ──────────────────────────────────────────────────────
  const [approvalSub, setApprovalSub] = useState<'pending' | 'approved' | 'denied'>('pending');

  // dashboard
  const [upcoming, setUpcoming]             = useState<any[]>([]);
  const [upcomingDays, setUpcomingDays]     = useState(14);
  const [typeFilter, setTypeFilter]         = useState('all');
  const [upcomingLoading, setUpcomingLoading] = useState(true);

  // sessions list
  const [activeTab, setActiveTab]   = useState<'group' | 'smallGroup' | 'oneOnOne' | 'allMentors'>('group');
  const [sessionSub, setSessionSub] = useState<'active' | 'completed'>('active');
  const [sessions, setSessions]     = useState<any[]>([]);
  const [loading, setLoading]       = useState(true);
  // Pagination state per tab+sub
  const [pages, setPages] = useState<Record<string, number>>({});
  const PAGE_SIZE = 10;
  const getPage   = (key: string) => pages[key] ?? 1;
  const setPage   = (key: string, p: number) => setPages(prev => ({ ...prev, [key]: p }));
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({
    session_date: new Date().toISOString().slice(0, 10),
    topic: '', session_type: 'GROUP', target_id: '',
  });
  const [selectedKidIds, setSelectedKidIds] = useState<string[]>([]);
  const [kids, setKids]     = useState<any[]>([]);
  const [mentors, setMentors] = useState<any[]>([]);
  const [creating, setCreating] = useState(false);

  // session requests
  const [requests, setRequests]           = useState<any[]>([]);
  const [reqLoading, setReqLoading]       = useState(true);
  const [approveForm, setApproveForm]     = useState<{ id: string; date: string; topic: string } | null>(null);
  const [approveSaving, setApproveSaving] = useState(false);
  const [denyId, setDenyId]               = useState<string | null>(null);
  const [denyNote, setDenyNote]           = useState('');
  const [denySaving, setDenySaving]       = useState(false);

  const [msg, setMsg]     = useState('');
  const [error, setError] = useState('');

  const loadUpcoming = (days = upcomingDays, filter = typeFilter) => {
    setUpcomingLoading(true);
    getSpiritualUpcoming(days, filter).then(setUpcoming).finally(() => setUpcomingLoading(false));
  };
  const loadSessions = () => {
    setLoading(true);
    getSpiritualSessions().then(setSessions).finally(() => setLoading(false));
  };
  const loadRequests = () => {
    setReqLoading(true);
    getSessionRequests().then(setRequests).finally(() => setReqLoading(false));
  };

  useEffect(() => {
    loadUpcoming(14, 'all');
    loadSessions();
    if (canWrite) {
      Promise.all([getSpiritualKidsList(), getSpiritualMentors()])
        .then(([k, m]) => { setKids(k); setMentors(m); });
      loadRequests();
    }
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(''); setMsg('');
    if (!form.topic.trim()) { setError('Topic is required'); return; }
    if ((form.session_type === 'ONE_ON_ONE_KID' || form.session_type === 'ONE_ON_ONE_MENTOR') && !form.target_id) {
      setError('Please select a target for 1:1 sessions'); return;
    }
    if (form.session_type === 'SMALL_GROUP' && selectedKidIds.length === 0) {
      setError('Please select at least one teen for the small group'); return;
    }
    setCreating(true);
    try {
      const body: any = { ...form, target_id: form.target_id || null };
      if (form.session_type === 'SMALL_GROUP') body.kid_ids = selectedKidIds;
      const res = await createSpiritualSession(body);
      setMsg('Session created!');
      setShowCreate(false);
      setForm({ session_date: new Date().toISOString().slice(0, 10), topic: '', session_type: 'GROUP', target_id: '' });
      setSelectedKidIds([]);
      loadSessions(); loadUpcoming();
      setTimeout(() => navigate(`/spiritual/session/${res.session_id}`), 600);
    } catch (ex: any) {
      setError(ex.response?.data?.error || 'Failed to create session');
    } finally { setCreating(false); }
  };

  const handleDelete = async (sessionId: string) => {
    if (!window.confirm('Delete this session and all its attendance/notes?')) return;
    try {
      await deleteSpiritualSession(sessionId);
      setMsg('Session deleted');
      loadSessions(); loadUpcoming();
    } catch (ex: any) { setError(ex.response?.data?.error || 'Delete failed'); }
  };

  const handleApprove = async () => {
    if (!approveForm) return;
    if (!approveForm.date)         { setError('Session date is required'); return; }
    if (!approveForm.topic.trim()) { setError('Session topic is required'); return; }
    setApproveSaving(true); setError('');
    try {
      const res = await approveSessionRequest(approveForm.id, { session_date: approveForm.date, topic: approveForm.topic.trim() });
      setMsg('Request approved! Session created.');
      setApproveForm(null);
      loadRequests();
      if (res.session_id) setTimeout(() => navigate(`/spiritual/session/${res.session_id}`), 600);
    } catch (ex: any) { setError(ex.response?.data?.error || 'Approval failed'); }
    finally { setApproveSaving(false); }
  };

  const handleDeny = async () => {
    if (!denyId) return;
    setDenySaving(true); setError('');
    try {
      await denySessionRequest(denyId, { review_note: denyNote.trim() });
      setMsg('Request denied.');
      setDenyId(null); setDenyNote('');
      loadRequests();
    } catch (ex: any) { setError(ex.response?.data?.error || 'Deny failed'); }
    finally { setDenySaving(false); }
  };

  const groupSessions      = sessions.filter(s => s.session_type === 'GROUP');
  const smallGroupSessions = sessions.filter(s => s.session_type === 'SMALL_GROUP');
  const oneOnOneSessions   = sessions.filter(s => s.session_type === 'ONE_ON_ONE_KID' || s.session_type === 'ONE_ON_ONE_MENTOR');
  const allMentorSessions  = sessions.filter(s => s.session_type === 'ALL_MENTORS');
  const pendingRequests    = requests.filter(r => r.status === 'PENDING');
  const approvedRequests   = requests.filter(r => r.status === 'APPROVED');
  const deniedRequests     = requests.filter(r => r.status === 'DENIED');

  const renderList = (list: any[], showTarget: boolean, pageKey: string) => {
    if (list.length === 0) return (
      <div className="card">
        <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '32px 0' }}>
          No sessions here.{canWrite && sessionSub === 'active' ? ' Click "+ New Session" to create one.' : ''}
        </p>
      </div>
    );
    const currentPage = getPage(pageKey);
    const totalPages  = Math.ceil(list.length / PAGE_SIZE);
    const pageSlice   = list.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
    return (
      <div>
        <div className="card">
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Date</th><th>Topic</th>
                  {showTarget && <th>With</th>}
                  <th>Type</th><th>Attendance</th><th>Notes</th><th>Status</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {pageSlice.map(s => {
                  const tc = SESSION_TYPE_COLOR[s.session_type] || { bg: '#e5e7eb', color: '#374151' };
                  return (
                    <tr key={s.session_id} style={{ opacity: s.is_cancelled ? 0.6 : 1 }}>
                      <td><strong>{s.session_date}</strong></td>
                      <td style={{ maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {s.is_cancelled && (
                          <span style={{ fontSize: 10, background: '#fee2e2', color: '#991b1b', padding: '1px 5px', borderRadius: 6, marginRight: 4, fontWeight: 700 }}>CANCELLED</span>
                        )}
                        <span style={{ cursor: 'pointer', color: 'var(--primary)', textDecoration: 'underline' }}
                          onClick={() => navigate(`/spiritual/session/${s.session_id}`)}>
                          {s.topic}
                        </span>
                      </td>
                      {showTarget && <td>{s.targetName || '—'}</td>}
                      <td>
                        <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 12, fontWeight: 600, background: tc.bg, color: tc.color }}>
                          {SESSION_TYPE_LABEL[s.session_type] || s.session_type}
                        </span>
                      </td>
                      <td>
                        {s.session_type === 'GROUP' || s.session_type === 'SMALL_GROUP'
                          ? `${s.present_count ?? 0}/${s.total_registered ?? 0}`
                          : s.session_type === 'ALL_MENTORS'
                            ? <span style={{ fontSize: 12 }}>{s.rsvp_accepted ?? 0}/{s.rsvp_total ?? 0} RSVP</span>
                            : s.one_on_one_attended ? 'Present' : '—'}
                      </td>
                      <td>
                        {s.has_group_note
                          ? <span style={{ color: 'var(--success)', fontSize: 12 }}>Added</span>
                          : <span style={{ color: 'var(--muted)', fontSize: 12 }}>—</span>}
                        {s.note_count > 0 && <span style={{ fontSize: 11, color: 'var(--primary)', marginLeft: 4 }}>+{s.note_count}</span>}
                      </td>
                      <td>
                        {s.is_cancelled
                          ? <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 12, fontWeight: 700, background: '#fee2e2', color: '#991b1b' }}>Cancelled</span>
                          : s.is_signed
                            ? <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 12, fontWeight: 700, background: '#1d4ed8', color: '#fff' }}>✅ Signed</span>
                            : <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 12, fontWeight: 700, background: '#d97706', color: '#fff' }}>Draft</span>}
                      </td>
                      <td style={{ display: 'flex', gap: 6 }}>
                        <button className="btn btn-primary btn-sm" onClick={() => navigate(`/spiritual/session/${s.session_id}`)}>
                          {canWrite ? 'Open' : 'View'}
                        </button>
                        {isAdmin && <button className="btn btn-danger btn-sm" onClick={() => handleDelete(s.session_id)}>Del</button>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
        {/* Pagination */}
        {totalPages > 1 && (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 12 }}>
            <button className="btn btn-outline btn-sm" disabled={currentPage === 1} onClick={() => setPage(pageKey, currentPage - 1)}>← Prev</button>
            <span style={{ fontSize: 13, color: 'var(--muted)' }}>Page {currentPage} of {totalPages}</span>
            <button className="btn btn-outline btn-sm" disabled={currentPage === totalPages} onClick={() => setPage(pageKey, currentPage + 1)}>Next →</button>
          </div>
        )}
        <div style={{ textAlign: 'right', fontSize: 12, color: 'var(--muted)', marginTop: 6 }}>
          {list.length} session{list.length !== 1 ? 's' : ''} total
        </div>
      </div>
    );
  };

  const renderUpcoming = (s: any) => {
    const { label, color } = daysUntilLabel(s.daysUntil);
    const tc = SESSION_TYPE_COLOR[s.session_type] || { bg: '#e5e7eb', color: '#374151' };
    return (
      <div key={s.session_id} style={{
        padding: '14px 16px', borderRadius: 10, marginBottom: 10,
        background: s.is_cancelled ? '#fef2f2' : s.daysUntil <= 1 ? '#fefce8' : '#f8fafc',
        border: `1px solid ${s.is_cancelled ? '#fca5a5' : s.daysUntil <= 1 ? '#fde047' : 'var(--border)'}`,
        display: 'flex', alignItems: 'center', flexWrap: 'wrap' as const, gap: 10,
      }}>
        <div style={{ flex: 1, minWidth: 200 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' as const }}>
            <strong style={{ fontSize: 15 }}>{s.topic}</strong>
            <span style={{ fontSize: 11, padding: '2px 7px', borderRadius: 10, fontWeight: 600, background: tc.bg, color: tc.color }}>
              {SESSION_TYPE_LABEL[s.session_type] || s.session_type}
            </span>
            {s.is_cancelled && <span style={{ fontSize: 11, background: '#fee2e2', color: '#991b1b', padding: '2px 7px', borderRadius: 10, fontWeight: 700 }}>CANCELLED</span>}
          </div>
          <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 4 }}>
            {s.session_date}{s.targetName ? ` — with ${s.targetName}` : ''}{s.created_by_name ? ` — by ${s.created_by_name}` : ''}
          </div>
          {s.is_cancelled && s.cancelled_reason && (
            <div style={{ fontSize: 12, color: '#dc2626', marginTop: 4 }}>Reason: {s.cancelled_reason}</div>
          )}
          {s.is_cancelled && s.proposed_new_date && (
            <div style={{ fontSize: 12, color: '#16a34a', marginTop: 2 }}>
              Proposed new date: {s.proposed_new_date}{s.proposed_new_topic ? ` — "${s.proposed_new_topic}"` : ''}
            </div>
          )}
        </div>
        <div style={{ display: 'flex', flexDirection: 'column' as const, alignItems: 'flex-end', gap: 6 }}>
          <span style={{ fontSize: 12, fontWeight: 700, color, background: '#fff', border: `1px solid ${color}`, borderRadius: 8, padding: '3px 10px' }}>
            {label}
          </span>
          {!s.is_cancelled && (
            <button className="btn btn-primary btn-sm" onClick={() => navigate(`/spiritual/session/${s.session_id}`)}>Open</button>
          )}
        </div>
      </div>
    );
  };

  return (
    <main className="page">
      {/* header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 20 }}>
        <h2 style={{ fontSize: 22, fontWeight: 700 }}>Spiritual Sessions</h2>
        <div style={{ flex: 1 }} />
        {canWrite && (
          <button className="btn btn-primary btn-sm" onClick={() => { setMainTab('sessions'); setShowCreate(v => !v); setError(''); setMsg(''); }}>
            {showCreate && mainTab === 'sessions' ? 'Cancel' : '+ New Session'}
          </button>
        )}
      </div>

      {msg   && <div className="alert alert-success" style={{ marginBottom: 12 }}>{msg}</div>}
      {error && <div className="alert alert-error"   style={{ marginBottom: 12 }}>{error}</div>}

      {/* main tabs */}
      <div className="tabs" style={{ marginBottom: 20 }}>
        <button className={`tab-btn ${mainTab === 'dashboard' ? 'active' : ''}`} onClick={() => setMainTab('dashboard')}>
          Upcoming Events
        </button>
        <button className={`tab-btn ${mainTab === 'sessions' ? 'active' : ''}`} onClick={() => setMainTab('sessions')}>
          All Sessions
        </button>
        {canWrite && (
          <button className={`tab-btn ${mainTab === 'approvals' ? 'active' : ''}`} onClick={() => { setMainTab('approvals'); loadRequests(); }}>
            Approvals{pendingRequests.length > 0 ? ` (${pendingRequests.length})` : ''}
          </button>
        )}
      </div>

      {/*  UPCOMING tab  */}
      {mainTab === 'dashboard' && (
        <div>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' as const, marginBottom: 16, alignItems: 'center' }}>
            <div>
              <label style={{ fontSize: 13, color: 'var(--muted)', marginRight: 6 }}>Window:</label>
              <select value={upcomingDays} style={{ fontSize: 13 }}
                onChange={e => { const d = Number(e.target.value); setUpcomingDays(d); loadUpcoming(d, typeFilter); }}>
                <option value={7}>Next 7 days</option>
                <option value={14}>Next 2 weeks (default)</option>
                <option value={30}>Next month</option>
                <option value={60}>Next 2 months</option>
              </select>
            </div>
            <div>
              <label style={{ fontSize: 13, color: 'var(--muted)', marginRight: 6 }}>Filter:</label>
              <select value={typeFilter} style={{ fontSize: 13 }}
                onChange={e => { setTypeFilter(e.target.value); loadUpcoming(upcomingDays, e.target.value); }}>
                <option value="all">All types</option>
                <option value="GROUP">Group only</option>
                <option value="SMALL_GROUP">Small Group only</option>
                <option value="ALL_MENTORS">Mentor meetings only</option>
                <option value="ONE_ON_ONE_KID">1:1 with teen only</option>
                <option value="ONE_ON_ONE_MENTOR">1:1 with mentor only</option>
              </select>
            </div>
            <button className="btn btn-outline btn-sm" onClick={() => loadUpcoming(upcomingDays, typeFilter)}>Refresh</button>
          </div>

          {upcomingLoading ? <p style={{ color: 'var(--muted)' }}>Loading upcoming events</p> : (
            upcoming.length === 0 ? (
              <div className="card">
                <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '32px 0' }}>
                  No upcoming sessions in the next {upcomingDays} days.
                  {canWrite ? ' Use "+ New Session" to schedule one.' : ''}
                </p>
              </div>
            ) : (
              <div className="card" style={{ padding: '16px 20px' }}>
                <div style={{ fontWeight: 700, fontSize: 14, color: 'var(--muted)', marginBottom: 12 }}>
                  {upcoming.length} session{upcoming.length !== 1 ? 's' : ''} in the next {upcomingDays} days
                </div>
                {upcoming.map(renderUpcoming)}
              </div>
            )
          )}
        </div>
      )}

      {/*  ALL SESSIONS tab  */}
      {mainTab === 'sessions' && (
        <div>
          {showCreate && canWrite && (
            <div className="card" style={{ marginBottom: 20 }}>
              <div className="card-title">New Session</div>
              <form onSubmit={handleCreate}>
                <div className="form-grid">
                  <div className="field">
                    <label className="required">Session Date</label>
                    <input type="date" value={form.session_date}
                      min={new Date().toISOString().slice(0, 10)}
                      max={new Date(Date.now() + 60 * 86400000).toISOString().slice(0, 10)}
                      onChange={e => setForm(f => ({ ...f, session_date: e.target.value }))} required />
                    <span style={{ fontSize: 11, color: 'var(--muted)' }}>Max 2 months ahead</span>
                  </div>
                  <div className="field">
                    <label className="required">Session Type</label>
                    <select value={form.session_type}
                      onChange={e => { setForm(f => ({ ...f, session_type: e.target.value, target_id: '' })); setSelectedKidIds([]); }}>
                      <option value="GROUP">Group Session</option>
                      <option value="SMALL_GROUP">Small Group</option>
                      <option value="ALL_MENTORS">All-Mentors Meeting</option>
                      <option value="ONE_ON_ONE_KID">1:1 with a Teen</option>
                      <option value="ONE_ON_ONE_MENTOR">1:1 with a Mentor</option>
                    </select>
                  </div>
                  {form.session_type === 'ONE_ON_ONE_KID' && (
                    <div className="field">
                      <label className="required">Select Teen</label>
                      <select value={form.target_id} onChange={e => setForm(f => ({ ...f, target_id: e.target.value }))} required>
                        <option value="">— Select Teen —</option>
                        {kids.map(k => <option key={k.kid_id} value={k.kid_id}>{k.first_name} {k.last_name} ({k.registration_id})</option>)}
                      </select>
                    </div>
                  )}
                  {form.session_type === 'ONE_ON_ONE_MENTOR' && (
                    <div className="field">
                      <label className="required">Select Mentor</label>
                      <select value={form.target_id} onChange={e => setForm(f => ({ ...f, target_id: e.target.value }))} required>
                        <option value="">— Select Mentor —</option>
                        {mentors.map(m => <option key={m.user_id} value={m.user_id}>{m.full_name} ({m.username})</option>)}
                      </select>
                    </div>
                  )}
                  {form.session_type === 'SMALL_GROUP' && (
                    <div className="field form-full">
                      <label className="required">Select Teens (small group)</label>
                      <div style={{ border: '1px solid var(--border)', borderRadius: 8, overflow: 'hidden', background: '#fafafa' }}>
                        <div style={{ overflowX: 'auto', WebkitOverflowScrolling: 'touch' as any }}>
                          <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 320 }}>
                            <thead>
                              <tr style={{ background: '#f1f5f9' }}>
                                <th style={{ width: 40, padding: '8px 10px', textAlign: 'center', fontWeight: 600, fontSize: 13, borderBottom: '1px solid var(--border)' }}>✓</th>
                                <th style={{ padding: '8px 10px', textAlign: 'left', fontWeight: 600, fontSize: 13, borderBottom: '1px solid var(--border)' }}>Name</th>
                                <th style={{ padding: '8px 10px', textAlign: 'left', fontWeight: 600, fontSize: 13, borderBottom: '1px solid var(--border)' }}>ID</th>
                              </tr>
                            </thead>
                            <tbody>
                              {kids.map(k => {
                                const checked = selectedKidIds.includes(k.kid_id);
                                return (
                                  <tr key={k.kid_id}
                                    style={{ background: checked ? '#eff6ff' : 'transparent', cursor: 'pointer', borderBottom: '1px solid #f1f5f9' }}
                                    onClick={() => setSelectedKidIds(ids => ids.includes(k.kid_id) ? ids.filter(i => i !== k.kid_id) : [...ids, k.kid_id])}>
                                    <td style={{ textAlign: 'center', padding: '8px 10px' }}>
                                      <input type="checkbox" checked={checked}
                                        onChange={() => setSelectedKidIds(ids => ids.includes(k.kid_id) ? ids.filter(i => i !== k.kid_id) : [...ids, k.kid_id])}
                                        onClick={e => e.stopPropagation()}
                                        style={{ width: 16, height: 16, cursor: 'pointer' }} />
                                    </td>
                                    <td style={{ padding: '8px 10px', fontSize: 13, fontWeight: checked ? 600 : 400, color: checked ? '#1d4ed8' : 'var(--text)' }}>
                                      {k.first_name} {k.last_name}
                                    </td>
                                    <td style={{ padding: '8px 10px', fontSize: 12, color: 'var(--muted)' }}>{k.registration_id}</td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>
                      </div>
                      {selectedKidIds.length > 0 && <p style={{ fontSize: 12, color: 'var(--primary)', marginTop: 4 }}>{selectedKidIds.length} teen(s) selected</p>}
                    </div>
                  )}
                  <div className="field form-full">
                    <label className="required">Topic / Title</label>
                    <input value={form.topic} onChange={e => setForm(f => ({ ...f, topic: e.target.value }))}
                      placeholder="Session topic or title" required maxLength={200} />
                  </div>
                </div>
                <div className="btn-row">
                  <button type="submit" className="btn btn-success" disabled={creating}>
                    {creating ? 'Creating...' : 'Create Session'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Active / Completed sub-tabs */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, flexWrap: 'wrap' as const, gap: 10 }}>
            <div className="tabs" style={{ marginBottom: 0 }}>
              <button className={`tab-btn ${sessionSub === 'active' ? 'active' : ''}`}
                onClick={() => setSessionSub('active')}>
                Active
              </button>
              <button className={`tab-btn ${sessionSub === 'completed' ? 'active' : ''}`}
                onClick={() => setSessionSub('completed')}>
                Completed ✅
              </button>
            </div>
          </div>

          {/* Type sub-tabs */}
          <div className="tabs" style={{ marginBottom: 16 }}>
            <button className={`tab-btn ${activeTab === 'group' ? 'active' : ''}`} onClick={() => setActiveTab('group')}>
              Group ({groupSessions.length})
            </button>
            <button className={`tab-btn ${activeTab === 'smallGroup' ? 'active' : ''}`} onClick={() => setActiveTab('smallGroup')}>
              Small Group ({smallGroupSessions.length})
            </button>
            <button className={`tab-btn ${activeTab === 'oneOnOne' ? 'active' : ''}`} onClick={() => setActiveTab('oneOnOne')}>
              1:1 Sessions ({oneOnOneSessions.length})
            </button>
            <button className={`tab-btn ${activeTab === 'allMentors' ? 'active' : ''}`} onClick={() => setActiveTab('allMentors')}>
              Mentor Meetings ({allMentorSessions.length})
            </button>
          </div>

          {loading ? <p>Loading...</p> : (() => {
            const filterBySub = (list: any[]) =>
              sessionSub === 'active'
                ? list.filter(s => !s.is_signed && !s.is_cancelled)
                : list.filter(s => s.is_signed);
            const pageKey = (t: string) => `${t}-${sessionSub}`;
            return (
              <>
                {activeTab === 'group'      && renderList(filterBySub(groupSessions), false, pageKey('group'))}
                {activeTab === 'smallGroup' && renderList(filterBySub(smallGroupSessions), false, pageKey('sg'))}
                {activeTab === 'oneOnOne'   && renderList(filterBySub(oneOnOneSessions), true, pageKey('oo'))}
                {activeTab === 'allMentors' && renderList(filterBySub(allMentorSessions), false, pageKey('am'))}
              </>
            );
          })()}
        </div>
      )}

      {/*  APPROVALS tab  */}
      {mainTab === 'approvals' && canWrite && (
        <div>
          {/* sub-tab bar */}
          <div className="tabs" style={{ marginBottom: 16 }}>
            <button className={`tab-btn ${approvalSub === 'pending' ? 'active' : ''}`}
              onClick={() => setApprovalSub('pending')}>
              Pending{pendingRequests.length > 0 ? ` (${pendingRequests.length})` : ''}
            </button>
            {isAdmin && (
              <button className={`tab-btn ${approvalSub === 'approved' ? 'active' : ''}`}
                onClick={() => setApprovalSub('approved')}>
                Approved{approvedRequests.length > 0 ? ` (${approvedRequests.length})` : ''}
              </button>
            )}
            <button className={`tab-btn ${approvalSub === 'denied' ? 'active' : ''}`}
              onClick={() => setApprovalSub('denied')}>
              Denied{deniedRequests.length > 0 ? ` (${deniedRequests.length})` : ''}
            </button>
          </div>

          {reqLoading ? <p style={{ color: 'var(--muted)' }}>Loading</p> : (
            <>
              {/* PENDING */}
              {approvalSub === 'pending' && (
                pendingRequests.length === 0 ? (
                  <div className="card"><p style={{ color: 'var(--muted)', textAlign: 'center', padding: '32px 0' }}>No pending session requests.</p></div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column' as const, gap: 12 }}>
                    {pendingRequests.map((r: any) => {
                      const kidIds: string[] = r.kid_ids ? JSON.parse(r.kid_ids) : [];
                      return (
                        <div key={r.request_id} className="card" style={{ borderColor: '#a78bfa', borderWidth: 2 }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap' as const, gap: 8 }}>
                            <div>
                              <strong style={{ fontSize: 14 }}>{r.requester_name}</strong>
                              <span style={{ marginLeft: 8, fontSize: 12, color: 'var(--muted)' }}>@{r.requester_username}</span>
                              <span style={{ marginLeft: 8, fontSize: 12, padding: '2px 7px', borderRadius: 8, fontWeight: 600,
                                background: r.request_type === 'ONE_ON_ONE_SL' ? '#ede9fe' : '#e0f2fe',
                                color: r.request_type === 'ONE_ON_ONE_SL' ? '#6d28d9' : '#0369a1',
                              }}>
                                {r.request_type === 'ONE_ON_ONE_SL' ? '1:1 with you' : `1:1 for ${kidIds.length} teen(s)`}
                              </span>
                            </div>
                            <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 10, fontWeight: 700, background: '#ede9fe', color: '#5b21b6' }}>⏳ PENDING</span>
                          </div>
                          <p style={{ fontSize: 13, marginTop: 8, color: '#374151' }}>{r.message}</p>
                          <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 4 }}>Requested: {r.created_at?.slice(0, 10)}</div>
                          <div className="btn-row" style={{ marginTop: 10 }}>
                            <button className="btn btn-success btn-sm"
                              onClick={() => { setApproveForm({ id: r.request_id, date: new Date().toISOString().slice(0, 10), topic: '' }); setError(''); }}>
                              ✅ Approve &amp; Schedule
                            </button>
                            <button className="btn btn-danger btn-sm"
                              onClick={() => { setDenyId(r.request_id); setDenyNote(''); setError(''); }}>
                              ❌ Deny
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )
              )}

              {/* APPROVED — admin only */}
              {approvalSub === 'approved' && isAdmin && (
                approvedRequests.length === 0 ? (
                  <div className="card"><p style={{ color: 'var(--muted)', textAlign: 'center', padding: '32px 0' }}>No approved requests yet.</p></div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column' as const, gap: 12 }}>
                    {approvedRequests.map((r: any) => {
                      const kidIds: string[] = r.kid_ids ? JSON.parse(r.kid_ids) : [];
                      return (
                        <div key={r.request_id} className="card" style={{ borderColor: '#86efac', borderWidth: 2 }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap' as const, gap: 8 }}>
                            <div>
                              <strong style={{ fontSize: 14 }}>{r.requester_name}</strong>
                              <span style={{ marginLeft: 8, fontSize: 12, color: 'var(--muted)' }}>@{r.requester_username}</span>
                              <span style={{ marginLeft: 8, fontSize: 12, padding: '2px 7px', borderRadius: 8, fontWeight: 600,
                                background: r.request_type === 'ONE_ON_ONE_SL' ? '#ede9fe' : '#e0f2fe',
                                color: r.request_type === 'ONE_ON_ONE_SL' ? '#6d28d9' : '#0369a1',
                              }}>
                                {r.request_type === 'ONE_ON_ONE_SL' ? '1:1 with SL' : `1:1 for ${kidIds.length} teen(s)`}
                              </span>
                            </div>
                            <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 10, fontWeight: 700, background: '#dcfce7', color: '#166534' }}>✅ APPROVED</span>
                          </div>
                          <p style={{ fontSize: 13, marginTop: 8, color: '#374151' }}>{r.message}</p>
                          <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 4 }}>Requested: {r.created_at?.slice(0, 10)}</div>
                          {r.approved_session_id && (
                            <div className="btn-row" style={{ marginTop: 10 }}>
                              <button className="btn btn-primary btn-sm"
                                onClick={() => navigate(`/spiritual/session/${r.approved_session_id}`)}>
                                View Session →
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )
              )}

              {/* DENIED */}
              {approvalSub === 'denied' && (
                deniedRequests.length === 0 ? (
                  <div className="card"><p style={{ color: 'var(--muted)', textAlign: 'center', padding: '32px 0' }}>No denied requests.</p></div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column' as const, gap: 12 }}>
                    {deniedRequests.map((r: any) => {
                      const kidIds: string[] = r.kid_ids ? JSON.parse(r.kid_ids) : [];
                      return (
                        <div key={r.request_id} className="card" style={{ borderColor: '#fca5a5', borderWidth: 2 }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap' as const, gap: 8 }}>
                            <div>
                              <strong style={{ fontSize: 14 }}>{r.requester_name}</strong>
                              <span style={{ marginLeft: 8, fontSize: 12, color: 'var(--muted)' }}>@{r.requester_username}</span>
                              <span style={{ marginLeft: 8, fontSize: 12, padding: '2px 7px', borderRadius: 8, fontWeight: 600,
                                background: r.request_type === 'ONE_ON_ONE_SL' ? '#ede9fe' : '#e0f2fe',
                                color: r.request_type === 'ONE_ON_ONE_SL' ? '#6d28d9' : '#0369a1',
                              }}>
                                {r.request_type === 'ONE_ON_ONE_SL' ? '1:1 with you' : `1:1 for ${kidIds.length} teen(s)`}
                              </span>
                            </div>
                            <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 10, fontWeight: 700, background: '#fee2e2', color: '#991b1b' }}>❌ DENIED</span>
                          </div>
                          <p style={{ fontSize: 13, marginTop: 8, color: '#374151' }}>{r.message}</p>
                          {r.review_note && (
                            <div style={{ marginTop: 8, padding: '8px 12px', background: '#fef2f2', borderRadius: 8, borderLeft: '3px solid #dc2626' }}>
                              <strong style={{ fontSize: 12, color: '#dc2626' }}>Reason given:</strong>
                              <p style={{ fontSize: 13, margin: '4px 0 0', color: '#374151' }}>{r.review_note}</p>
                            </div>
                          )}
                          <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 6 }}>Requested: {r.created_at?.slice(0, 10)}</div>
                        </div>
                      );
                    })}
                  </div>
                )
              )}
            </>
          )}
        </div>
      )}

      {/* approve modal */}
      {approveForm && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
          <div className="card" style={{ width: '100%', maxWidth: 440, margin: 0 }}>
            <div className="card-title">Approve Request — Set Date &amp; Topic</div>
            <div className="form-grid">
              <div className="field">
                <label className="required">Session Date</label>
                <input type="date" value={approveForm.date}
                  min={new Date().toISOString().slice(0, 10)}
                  max={new Date(Date.now() + 60 * 86400000).toISOString().slice(0, 10)}
                  onChange={e => setApproveForm(f => f ? { ...f, date: e.target.value } : f)} />
              </div>
              <div className="field form-full">
                <label className="required">Session Topic</label>
                <input value={approveForm.topic} onChange={e => setApproveForm(f => f ? { ...f, topic: e.target.value } : f)}
                  placeholder="e.g. 1:1 Leadership Session" maxLength={200} />
              </div>
            </div>
            {error && <div className="alert alert-error" style={{ marginBottom: 8 }}>{error}</div>}
            <div className="btn-row">
              <button className="btn btn-outline btn-sm" onClick={() => { setApproveForm(null); setError(''); }}>Cancel</button>
              <button className="btn btn-success btn-sm" onClick={handleApprove} disabled={approveSaving}>
                {approveSaving ? 'Creating' : 'Confirm &amp; Create Session'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* deny modal */}
      {denyId && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
          <div className="card" style={{ width: '100%', maxWidth: 400, margin: 0 }}>
            <div className="card-title">Deny Session Request</div>
            <div className="field">
              <label>Reason / Note (optional)</label>
              <textarea rows={3} value={denyNote} onChange={e => setDenyNote(e.target.value)} placeholder="Reason for denial" maxLength={300} />
            </div>
            {error && <div className="alert alert-error" style={{ marginBottom: 8 }}>{error}</div>}
            <div className="btn-row">
              <button className="btn btn-outline btn-sm" onClick={() => { setDenyId(null); setError(''); }}>Cancel</button>
              <button className="btn btn-danger btn-sm" onClick={handleDeny} disabled={denySaving}>
                {denySaving ? 'Saving' : 'Deny Request'}
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}