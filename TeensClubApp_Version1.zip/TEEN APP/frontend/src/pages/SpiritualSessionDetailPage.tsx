import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  getSpiritualSessionDetail, updateSpiritualSession,
  saveSpiritualAttendance, addSpiritualKidNote, deleteSpiritualKidNote,
  signSpiritualSession,
  saveSpiritualAddon, signSpiritualAddon,
  cancelSpiritualSession,
} from '../api';
import { useAuth } from '../AuthContext';

// ── helpers ───────────────────────────────────────────────────────────────────
const MAX_BOX = 600;

function splitIntoBoxes(text: string): string[] {
  if (!text) return [''];
  const boxes: string[] = [];
  for (let i = 0; i < text.length; i += MAX_BOX) boxes.push(text.slice(i, i + MAX_BOX));
  if (boxes[boxes.length - 1].length === MAX_BOX) boxes.push('');
  return boxes;
}
function joinBoxes(boxes: string[]): string { return boxes.join(''); }

// ── ChainedBoxes ──────────────────────────────────────────────────────────────
interface ChainedBoxesProps {
  boxes: string[];
  onChange: (boxes: string[]) => void;
  readOnly: boolean;
  placeholder?: string;
  rows?: number;
}
function ChainedBoxes({ boxes, onChange, readOnly, placeholder = '', rows = 8 }: ChainedBoxesProps) {
  const handleChange = (idx: number, val: string) => {
    if (readOnly || val.length > MAX_BOX) return;
    const next = [...boxes];
    next[idx] = val;
    if (val.length === MAX_BOX && idx === boxes.length - 1) next.push('');
    onChange(next);
  };
  return (
    <div>
      {boxes.map((b, i) => {
        const isFull = b.length === MAX_BOX;
        const isPrev = i < boxes.length - 1;
        return (
          <div key={i} style={{ marginBottom: 12 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
              <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--muted)' }}>
                {i === 0 ? 'Notes' : `Continued — Part ${i + 1}`}
              </span>
              <span style={{ fontSize: 12, fontWeight: 600, color: isFull ? '#16a34a' : b.length > 550 ? '#d97706' : 'var(--muted)' }}>
                {b.length} / {MAX_BOX}
              </span>
            </div>
            {readOnly ? (
              <div style={{ border: '1px solid var(--border)', borderRadius: 8, padding: '10px 14px', background: '#f9fafb', whiteSpace: 'pre-wrap', lineHeight: 1.8, minHeight: 48, fontSize: 14 }}>
                {b || <span style={{ color: 'var(--muted)' }}>—</span>}
              </div>
            ) : (
              <>
                <textarea
                  rows={isPrev ? 4 : rows} value={b}
                  onChange={e => handleChange(i, e.target.value)}
                  placeholder={i === 0 ? placeholder : `Continue writing part ${i + 1}...`}
                  disabled={isPrev} maxLength={MAX_BOX}
                  style={isPrev ? { background: '#f9fafb', opacity: 0.85, resize: 'none' } : undefined}
                />
                {isFull && !isPrev && (
                  <div className="alert alert-success" style={{ margin: '4px 0 0', fontSize: 12, padding: '6px 12px' }}>
                    ✅ Part {i + 1} is full ({MAX_BOX} chars) — continue writing in the new box below
                  </div>
                )}
              </>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ── StatusBadge ───────────────────────────────────────────────────────────────
function StatusBadge({ session }: { session: any }) {
  if (session.is_cancelled) return <span style={{ fontSize: 12, padding: '3px 12px', borderRadius: 20, fontWeight: 700, background: '#dc2626', color: '#fff' }}>🚫 CANCELLED</span>;
  if (session.is_signed) return <span style={{ fontSize: 12, padding: '3px 12px', borderRadius: 20, fontWeight: 700, background: '#1d4ed8', color: '#fff' }}>✍️ SIGNED</span>;
  return <span style={{ fontSize: 12, padding: '3px 12px', borderRadius: 20, fontWeight: 700, background: '#d97706', color: '#fff' }}>📝 DRAFT</span>;
}

// ── Main component ────────────────────────────────────────────────────────────
export default function SpiritualSessionDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { isAdmin, isSpiritualLeader, isMentor } = useAuth();
  const canWrite = isAdmin || isSpiritualLeader;
  const canEditContent = isSpiritualLeader; // only SL can edit notes, sign, cancel

  const [session, setSession] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [section, setSection] = useState<'notes' | 'attendance' | 'kidNotes'>('notes');

  // Group note (chained boxes)
  const [noteBoxes, setNoteBoxes] = useState<string[]>(['']);
  const [savingNote, setSavingNote] = useState(false);
  const [noteMsg, setNoteMsg] = useState('');
  const [noteError, setNoteError] = useState('');

  // Attendance
  const [attEdits, setAttEdits] = useState<Record<string, boolean>>({});
  const [mentorAttEdits, setMentorAttEdits] = useState<Record<string, boolean>>({});
  const [oneOnOneAttended, setOneOnOneAttended] = useState(false);
  const [savingAtt, setSavingAtt] = useState(false);
  const [attMsg, setAttMsg] = useState('');

  // Individual kid notes
  const [showKidForm, setShowKidForm] = useState(false);
  const [kidForm, setKidForm] = useState({ kid_id: '', content: '', improvement: '', suggestions: '' });
  const [savingKid, setSavingKid] = useState(false);
  const [kidMsg, setKidMsg] = useState('');
  const [kidError, setKidError] = useState('');

  // Sign
  const [signing, setSigning] = useState(false);
  const [signConfirm, setSignConfirm] = useState(false);

  // Post-sign addon (chained boxes)
  const [addonBoxes, setAddonBoxes] = useState<string[]>(['']);
  const [savingAddon, setSavingAddon] = useState(false);
  const [addonMsg, setAddonMsg] = useState('');
  const [addonError, setAddonError] = useState('');
  const [signingAddon, setSigningAddon] = useState(false);

  // Cancel
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [cancelReason, setCancelReason]       = useState('');
  const [proposeNewDate, setProposeNewDate]   = useState('');
  const [proposeNewTopic, setProposeNewTopic] = useState('');
  const [cancelling, setCancelling]           = useState(false);
  const [cancelError, setCancelError]         = useState('');

  const [topMsg, setTopMsg] = useState('');

  const load = () => {
    if (!id) return;
    getSpiritualSessionDetail(id).then(data => {
      setSession(data);
      setNoteBoxes(splitIntoBoxes(data.group_note || ''));
      setOneOnOneAttended(!!data.one_on_one_attended);
      setAddonBoxes(splitIntoBoxes(data.addon_text || ''));
      const att: Record<string, boolean> = {};
      (data.attendance || []).forEach((a: any) => { att[a.kid_id] = !!a.is_present; });
      setAttEdits(att);
      const mAtt: Record<string, boolean> = {};
      (data.mentorAttendance || []).forEach((m: any) => { mAtt[m.mentor_id] = !!m.is_present; });
      setMentorAttEdits(mAtt);
    }).catch(() => setSession(null)).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [id]);

  const handleSaveNote = async () => {
    setNoteError(''); setNoteMsg(''); setSavingNote(true);
    try {
      await updateSpiritualSession(id!, { group_note: joinBoxes(noteBoxes).trim() || null });
      setNoteMsg('Notes saved!');
      load();
    } catch (e: any) { setNoteError(e.response?.data?.error || 'Save failed'); }
    finally { setSavingNote(false); }
  };

  const handleSaveAttendance = async () => {
    setSavingAtt(true); setAttMsg('');
    try {
      if (session.session_type === 'GROUP' || session.session_type === 'SMALL_GROUP') {
        const attendance = Object.entries(attEdits).map(([kid_id, is_present]) => ({ kid_id, is_present }));
        const mentor_attendance = Object.entries(mentorAttEdits).map(([mentor_id, is_present]) => ({ mentor_id, is_present }));
        await saveSpiritualAttendance(id!, { attendance, mentor_attendance });
      } else if (session.session_type === 'ALL_MENTORS') {
        const mentor_attendance = Object.entries(mentorAttEdits).map(([mentor_id, is_present]) => ({ mentor_id, is_present }));
        await saveSpiritualAttendance(id!, { mentor_attendance });
      } else {
        await saveSpiritualAttendance(id!, { one_on_one_attended: oneOnOneAttended });
      }
      setAttMsg('Attendance saved!');
      load();
    } catch (e: any) { setAttMsg('Error: ' + (e.response?.data?.error || 'Failed')); }
    finally { setSavingAtt(false); }
  };

  const handleAddKidNote = async () => {
    setKidError(''); setKidMsg('');
    if (!kidForm.kid_id) { setKidError('Please select a teen'); return; }
    if (!kidForm.content.trim()) { setKidError('Note content is required'); return; }
    setSavingKid(true);
    try {
      await addSpiritualKidNote(id!, kidForm);
      setKidMsg('Note added!');
      setKidForm({ kid_id: '', content: '', improvement: '', suggestions: '' });
      setShowKidForm(false);
      load();
    } catch (e: any) { setKidError(e.response?.data?.error || 'Save failed'); }
    finally { setSavingKid(false); }
  };

  const handleDeleteKidNote = async (noteId: string) => {
    if (!window.confirm('Delete this individual note?')) return;
    try { await deleteSpiritualKidNote(noteId); setTopMsg('Note deleted'); load(); }
    catch (e: any) { setTopMsg('Error: ' + (e.response?.data?.error || 'Failed')); }
  };

  const handleSign = async () => {
    setSigning(true);
    try { await signSpiritualSession(id!); setTopMsg('Session signed and locked successfully!'); setSignConfirm(false); load(); }
    catch (e: any) { setTopMsg('Error: ' + (e.response?.data?.error || 'Sign failed')); }
    finally { setSigning(false); }
  };

  const handleSaveAddon = async () => {
    setSavingAddon(true); setAddonError(''); setAddonMsg('');
    try {
      await saveSpiritualAddon(id!, joinBoxes(addonBoxes).trim());
      setAddonMsg('Additional notes saved!'); load();
    } catch (e: any) { setAddonError(e.response?.data?.error || 'Save failed'); }
    finally { setSavingAddon(false); }
  };

  const handleSignAddon = async () => {
    setSigningAddon(true); setAddonError('');
    try { await signSpiritualAddon(id!); setAddonMsg('Additional notes signed!'); load(); }
    catch (e: any) { setAddonError(e.response?.data?.error || 'Sign failed'); }
    finally { setSigningAddon(false); }
  };

  const handleCancel = async () => {
    if (!cancelReason.trim()) { setCancelError('A reason is required to cancel'); return; }
    setCancelling(true); setCancelError('');
    try {
      await cancelSpiritualSession(id!, {
        cancelled_reason: cancelReason.trim(),
        proposed_new_date: proposeNewDate || undefined,
        proposed_new_topic: proposeNewTopic.trim() || undefined,
      });
      setShowCancelModal(false); setCancelReason(''); setProposeNewDate(''); setProposeNewTopic('');
      setTopMsg('Session cancelled. All mentors have been notified.');
      load();
    } catch (ex: any) { setCancelError(ex.response?.data?.error || 'Cancel failed'); }
    finally { setCancelling(false); }
  };

  if (loading) return <main className="page"><p>Loading...</p></main>;
  if (!session) return <main className="page"><p style={{ color: 'var(--danger)' }}>Session not found.</p></main>;

  const isGroup      = session.session_type === 'GROUP' || session.session_type === 'SMALL_GROUP';
  const isAllMentors = session.session_type === 'ALL_MENTORS';
  const isOneKid     = session.session_type === 'ONE_ON_ONE_KID';
  const presentCount = (session.attendance || []).filter((a: any) => a.is_present).length;
  const locked       = !!session.is_signed || !!session.is_cancelled;  // cancelled = fully locked
  const showKidNotesTab = isGroup || isOneKid;

  const SESSION_TYPE_LABELS: Record<string, string> = {
    GROUP: 'Group Session', SMALL_GROUP: 'Small Group', ALL_MENTORS: 'All-Mentors Meeting',
    ONE_ON_ONE_KID: '1:1 with Teen', ONE_ON_ONE_MENTOR: '1:1 with Mentor',
  };
  const SESSION_TYPE_COLORS: Record<string, { bg: string; color: string }> = {
    GROUP:           { bg: '#dbeafe', color: '#1d4ed8' },
    SMALL_GROUP:     { bg: '#e0f2fe', color: '#0369a1' },
    ALL_MENTORS:     { bg: '#fef3c7', color: '#92400e' },
    ONE_ON_ONE_KID:  { bg: '#fce7f3', color: '#be185d' },
    ONE_ON_ONE_MENTOR: { bg: '#f3e8ff', color: '#6b21a8' },
  };
  const typeLabel = SESSION_TYPE_LABELS[session.session_type] || session.session_type;
  const typeColor = SESSION_TYPE_COLORS[session.session_type] || { bg: '#e5e7eb', color: '#374151' };

  const rsvpAccepted = (session.mentorAttendance || []).filter((m: any) => m.rsvp_status === 'ACCEPTED').length;
  const rsvpTotal    = (session.mentorAttendance || []).length;

  const tabs: { key: 'notes' | 'attendance' | 'kidNotes'; label: string }[] = [
    { key: 'notes',      label: `📝 Notes${session.group_note ? ' ✅' : ''}` },
    { key: 'attendance', label: isAllMentors
        ? `📋 Mentors (${rsvpAccepted}/${rsvpTotal} RSVP’d)`
        : isGroup
          ? `📋 Attendance (${presentCount}/${session.attendance?.length ?? 0})`
          : '📋 Attendance' },
    ...(showKidNotesTab ? [{ key: 'kidNotes' as const, label: `👤 Individual Notes (${session.kidNotes?.length ?? 0})` }] : []),
  ];

  return (
    <main className="page">
      {/* ── Header ─────────────────────────────────────────────────── */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24 }}>
        <button className="btn btn-outline btn-sm" onClick={() => navigate('/spiritual')}>Back</button>
        {canEditContent && !session.is_cancelled && !session.is_signed && (
          <button className="btn btn-danger btn-sm" onClick={() => { setShowCancelModal(true); setCancelReason(''); setCancelError(''); setProposeNewDate(''); setProposeNewTopic(''); }}>
            Cancel Session
          </button>
        )}
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
            <h2 style={{ fontSize: 22, fontWeight: 700, margin: 0 }}>
              {isAllMentors ? '🧑‍🤝 Mentors Meeting' : isGroup ? '✝️ Group Session' : isOneKid ? '👤 1:1 with Teen' : '🧑‍🏫 1:1 with Mentor'}
            </h2>
            <StatusBadge session={session} />
          </div>
          <p style={{ color: 'var(--muted)', fontSize: 13, marginTop: 4 }}>
            {session.session_date} · by {session.created_by_name}
            {session.targetName && <> · <strong>{session.targetName}</strong></>}
          </p>
        </div>
      </div>

      {session.is_cancelled === 1 && (
        <div className="alert alert-error" style={{ marginBottom: 16 }}>
          <strong>This session was cancelled</strong>
          {session.cancelled_at ? ` on ${session.cancelled_at.slice(0, 10)}` : ''}
          {session.cancelled_by ? ` by ${session.cancelled_by}` : ''}.
          {session.cancelled_reason ? ` Reason: ${session.cancelled_reason}` : ''}
          {session.proposed_new_date && (
            <div style={{ marginTop: 4, color: '#166534' }}>
              Proposed new date: {session.proposed_new_date}
              {session.proposed_new_topic ? ` — "${session.proposed_new_topic}"` : ''}
            </div>
          )}
        </div>
      )}

      {topMsg && <div className="alert alert-success" style={{ marginBottom: 16 }}>{topMsg}</div>}

      {/* ── Session Info ────────────────────────────────────────────── */}
      <div className="card" style={{ marginBottom: 20 }}>
        <div className="card-title">📋 Session Info</div>
        <div className="form-grid" style={{ fontSize: 14 }}>
          <div><span style={{ color: 'var(--muted)' }}>Date</span><br /><strong>{session.session_date}</strong></div>
          <div><span style={{ color: 'var(--muted)' }}>Type</span><br />
            <span style={{ fontSize: 12, padding: '2px 10px', borderRadius: 12, fontWeight: 600,
              background: typeColor.bg, color: typeColor.color }}>
              {typeLabel}
            </span>
          </div>
          <div><span style={{ color: 'var(--muted)' }}>Topic</span><br /><strong>{session.topic}</strong></div>
          {session.targetName && <div><span style={{ color: 'var(--muted)' }}>With</span><br /><strong>{session.targetName}</strong></div>}
          <div><span style={{ color: 'var(--muted)' }}>Status</span><br /><StatusBadge session={session} /></div>
          {isGroup && <div><span style={{ color: 'var(--muted)' }}>Attendance</span><br /><strong>{presentCount} / {session.attendance?.length ?? 0} present</strong></div>}
          {isAllMentors && rsvpTotal > 0 && <div><span style={{ color: 'var(--muted)' }}>RSVP’d</span><br /><strong>{rsvpAccepted} / {rsvpTotal} confirmed</strong></div>}
          {session.is_signed && <div><span style={{ color: 'var(--muted)' }}>Signed by</span><br />{session.signed_by} <span style={{ color: 'var(--muted)', fontSize: 12 }}>({session.signed_at?.slice(0, 10)})</span></div>}
        </div>
      </div>

      {/* ── Tabs ────────────────────────────────────────────────────── */}
      {session.is_cancelled && (
        <div className="alert alert-error" style={{ marginBottom: 12, fontSize: 14, fontWeight: 600, textAlign: 'center' }}>
          🚫 This session was cancelled — all data is read-only. Editing, saving, and signing are disabled.
        </div>
      )}
      <div className="tabs" style={{ marginBottom: 20 }}>
        {tabs.map(t => (
          <button key={t.key} className={`tab-btn ${section === t.key ? 'active' : ''}`} onClick={() => setSection(t.key)}>{t.label}</button>
        ))}
      </div>

      {/* ═══════════════════════════════════════════════════════════ */}
      {/* NOTES TAB                                                   */}
      {/* ═══════════════════════════════════════════════════════════ */}
      {section === 'notes' && (
        <div className="card" style={{ marginBottom: 16 }}>
          <div className="card-title">
            📝 {isGroup ? 'Group Session Notes' : 'Session Notes / Outcome'}
            {isGroup && <span style={{ fontSize: 12, color: 'var(--muted)', fontWeight: 400, marginLeft: 8 }}>— visible to all mentors</span>}
            {locked && <span style={{ fontSize: 12, color: 'var(--danger)', fontWeight: 700, marginLeft: 8 }}>🔒 Locked</span>}
          </div>
          {canEditContent && !locked ? (
            <>
              <ChainedBoxes boxes={noteBoxes} onChange={setNoteBoxes} readOnly={false}
                placeholder="Document the session discussion, spiritual insights, takeaways and outcomes... (max 600 chars per box)" />
              {noteMsg   && <div className="alert alert-success" style={{ marginBottom: 8 }}>{noteMsg}</div>}
              {noteError && <div className="alert alert-error"   style={{ marginBottom: 8 }}>{noteError}</div>}
              <div className="btn-row">
                <button className="btn btn-success" onClick={handleSaveNote} disabled={savingNote}>
                  {savingNote ? 'Saving...' : '💾 Save Notes'}
                </button>
              </div>
            </>
          ) : (
            session.group_note
              ? <ChainedBoxes boxes={splitIntoBoxes(session.group_note)} onChange={() => {}} readOnly />
              : <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '20px 0' }}>No notes recorded for this session yet.</p>
          )}
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════ */}
      {/* ATTENDANCE TAB                                              */}
      {/* ═══════════════════════════════════════════════════════════ */}
      {section === 'attendance' && (
        <div className="card" style={{ marginBottom: 16 }}>
          <div className="card-title">
            📋 Attendance
            {locked && <span style={{ fontSize: 12, color: 'var(--danger)', fontWeight: 700, marginLeft: 8 }}>🔒 Locked</span>}
          </div>

          {/* ALL_MENTORS: only mentor rows, no kid table */}
          {isAllMentors && (
            <>
              {(!session.mentorAttendance || session.mentorAttendance.length === 0)
                ? <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '24px 0' }}>No mentors registered yet.</p>
                : <>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginBottom: 16 }}>
                    {session.mentorAttendance.map((m: any) => {
                      const rsvpChip = m.rsvp_status === 'ACCEPTED'
                        ? { label: '✅ Accepted', bg: '#dcfce7', color: '#166534' }
                        : m.rsvp_status === 'DECLINED'
                          ? { label: '❌ Declined', bg: '#fee2e2', color: '#991b1b' }
                          : { label: '⏳ Pending', bg: '#fef3c7', color: '#92400e' };
                      return (
                        <label key={m.mentor_id} style={{
                          display: 'flex', alignItems: 'center', gap: 8, cursor: canWrite && !locked ? 'pointer' : 'default',
                          background: mentorAttEdits[m.mentor_id] ? '#f0fdf4' : '#f8fafc',
                          border: `1px solid ${mentorAttEdits[m.mentor_id] ? '#86efac' : 'var(--border)'}`,
                          borderRadius: 8, padding: '8px 14px', fontSize: 14, userSelect: 'none',
                        }}>
                          {canWrite && !locked ? (
                            <input type="checkbox" checked={!!mentorAttEdits[m.mentor_id]}
                              onChange={e => setMentorAttEdits(prev => ({ ...prev, [m.mentor_id]: e.target.checked }))}
                              style={{ width: 16, height: 16 }} />
                          ) : (
                            <span style={{ fontSize: 16 }}>{mentorAttEdits[m.mentor_id] ? '✅' : '❌'}</span>
                          )}
                          <span style={{ fontWeight: 600 }}>{m.mentor_name || m.mentor_id}</span>
                          <span style={{ fontSize: 11, padding: '2px 7px', borderRadius: 10, fontWeight: 600, background: rsvpChip.bg, color: rsvpChip.color }}>
                            {rsvpChip.label}
                          </span>
                        </label>
                      );
                    })}
                  </div>
                  {canWrite && !locked && (
                    <>
                      {attMsg && <div className={`alert ${attMsg.startsWith('Error') ? 'alert-error' : 'alert-success'}`} style={{ marginBottom: 12 }}>{attMsg}</div>}
                      <div className="btn-row">
                        <button className="btn btn-success" onClick={handleSaveAttendance} disabled={savingAtt}>
                          {savingAtt ? 'Saving...' : '💾 Save Attendance'}
                        </button>
                      </div>
                    </>
                  )}
                </>
              }
            </>
          )}

          {/* 1:1 attendance (single checkbox) */}
          {!isGroup && !isAllMentors && (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '16px 0', borderBottom: '1px solid var(--border)', marginBottom: 16 }}>
                <div style={{ flex: 1, fontWeight: 600, fontSize: 15 }}>
                  {isOneKid ? `👤 ${session.targetName} (Teen)` : `🧑‍🏫 ${session.targetName} (Mentor)`}
                </div>
                {canWrite && !locked ? (
                  <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: 14 }}>
                    <input type="checkbox" checked={oneOnOneAttended}
                      onChange={e => setOneOnOneAttended(e.target.checked)} style={{ width: 18, height: 18 }} />
                    Mark as Present / Attended
                  </label>
                ) : (
                  <span style={{ fontSize: 18 }}>{session.one_on_one_attended ? '✅ Present' : '❌ Absent / Not recorded'}</span>
                )}
              </div>
              {canWrite && !locked && (
                <>
                  {attMsg && <div className={`alert ${attMsg.startsWith('Error') ? 'alert-error' : 'alert-success'}`} style={{ marginBottom: 12 }}>{attMsg}</div>}
                  <div className="btn-row">
                    <button className="btn btn-success" onClick={handleSaveAttendance} disabled={savingAtt}>
                      {savingAtt ? 'Saving...' : '💾 Save Attendance'}
                    </button>
                  </div>
                </>
              )}
            </div>
          )}

          {/* GROUP / SMALL_GROUP attendance (teen table + mentor attendance) */}
          {isGroup && (
            <>
              {session.attendance?.length === 0
                ? <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '24px 0' }}>No teens enrolled yet.</p>
                : <>
                  {canWrite && !locked && (
                    <div style={{ marginBottom: 12, display: 'flex', gap: 8 }}>
                      <button className="btn btn-outline btn-sm" onClick={() => {
                        const all: Record<string, boolean> = {};
                        session.attendance.forEach((a: any) => { all[a.kid_id] = true; });
                        setAttEdits(all);
                      }}>Mark All Present</button>
                      <button className="btn btn-outline btn-sm" onClick={() => {
                        const none: Record<string, boolean> = {};
                        session.attendance.forEach((a: any) => { none[a.kid_id] = false; });
                        setAttEdits(none);
                      }}>Clear All</button>
                    </div>
                  )}
                  <div className="table-wrap">
                    <table>
                      <thead><tr>
                        <th>Present</th><th>Reg ID</th><th>Name</th><th>Age</th><th>Education</th>
                        {!isMentor && <th>Mentor</th>}
                      </tr></thead>
                      <tbody>
                        {session.attendance.map((a: any) => (
                          <tr key={a.kid_id} style={{ background: attEdits[a.kid_id] ? '#f0fdf4' : undefined }}>
                            <td>
                              {canWrite && !locked
                                ? <input type="checkbox" checked={!!attEdits[a.kid_id]}
                                    onChange={e => setAttEdits(prev => ({ ...prev, [a.kid_id]: e.target.checked }))} />
                                : <span style={{ fontSize: 16 }}>{a.is_present ? '✅' : '❌'}</span>}
                            </td>
                            <td><code style={{ fontSize: 11 }}>{a.registration_id}</code></td>
                            <td><span style={{ cursor: 'pointer', color: 'var(--primary)', fontWeight: 600 }}
                              onClick={() => navigate(`/kid/${a.kid_id}`)}>{a.first_name} {a.last_name}</span></td>
                            <td>{a.age_snapshot}</td>
                            <td style={{ fontSize: 12 }}>{a.education_level || '—'}</td>
                            {!isMentor && <td style={{ fontSize: 12, color: 'var(--muted)' }}>{a.mentor_name || '—'}</td>}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* ── Mentor Attendance with RSVP badges ────────────── */}
                  {(session.mentorAttendance && session.mentorAttendance.length > 0) && (
                    <div style={{ marginTop: 24, paddingTop: 16, borderTop: '2px solid var(--border)' }}>
                      <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 10, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                        🧑‍🏫 Mentor Attendance & RSVP
                      </div>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
                        {session.mentorAttendance.map((m: any) => {
                          const rsvpChip = m.rsvp_status === 'ACCEPTED'
                            ? { label: '✅ Accepted', bg: '#dcfce7', color: '#166534' }
                            : m.rsvp_status === 'DECLINED'
                              ? { label: '❌ Declined', bg: '#fee2e2', color: '#991b1b' }
                              : { label: '⏳ Pending', bg: '#fef3c7', color: '#92400e' };
                          return (
                            <label key={m.mentor_id} style={{
                              display: 'flex', alignItems: 'center', gap: 8, cursor: canWrite && !locked ? 'pointer' : 'default',
                              background: mentorAttEdits[m.mentor_id] ? '#f0fdf4' : '#f8fafc',
                              border: `1px solid ${mentorAttEdits[m.mentor_id] ? '#86efac' : 'var(--border)'}`,
                              borderRadius: 8, padding: '8px 14px', fontSize: 14, userSelect: 'none',
                            }}>
                              {canWrite && !locked ? (
                                <input type="checkbox" checked={!!mentorAttEdits[m.mentor_id]}
                                  onChange={e => setMentorAttEdits(prev => ({ ...prev, [m.mentor_id]: e.target.checked }))}
                                  style={{ width: 16, height: 16 }} />
                              ) : (
                                <span style={{ fontSize: 16 }}>{mentorAttEdits[m.mentor_id] ? '✅' : '❌'}</span>
                              )}
                              <span style={{ fontWeight: 600 }}>{m.mentor_name || m.mentor_id}</span>
                              <span style={{ fontSize: 11, padding: '2px 7px', borderRadius: 10, fontWeight: 600, background: rsvpChip.bg, color: rsvpChip.color }}>
                                {rsvpChip.label}
                              </span>
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {canWrite && !locked && (
                    <>
                      {attMsg && <div className={`alert ${attMsg.startsWith('Error') ? 'alert-error' : 'alert-success'}`} style={{ marginTop: 12 }}>{attMsg}</div>}
                      <div className="btn-row" style={{ marginTop: 12 }}>
                        <button className="btn btn-success" onClick={handleSaveAttendance} disabled={savingAtt}>
                          {savingAtt ? 'Saving...' : '💾 Save Attendance'}
                        </button>
                      </div>
                    </>
                  )}
                  {locked && <p style={{ fontSize: 13, color: 'var(--muted)', marginTop: 8 }}>Attendance is locked after signing.</p>}
                </>
              }
            </>
          )}
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════ */}
      {/* INDIVIDUAL KID NOTES TAB                                    */}
      {/* ═══════════════════════════════════════════════════════════ */}
      {section === 'kidNotes' && showKidNotesTab && (
        <div>
          {canEditContent && !locked && (
            <div style={{ marginBottom: 16, display: 'flex', justifyContent: 'flex-end' }}>
              <button className="btn btn-primary btn-sm" onClick={() => { setShowKidForm(!showKidForm); setKidError(''); setKidMsg(''); }}>
                {showKidForm ? 'Cancel' : '+ Add Individual Note'}
              </button>
            </div>
          )}
          {locked && canEditContent && (
            <div className="alert alert-error" style={{ marginBottom: 12, fontSize: 13 }}>
              🔒 Individual notes are locked after signing. No new notes can be added.
            </div>
          )}

          {showKidForm && canEditContent && !locked && (
            <div className="card" style={{ marginBottom: 16, borderColor: '#a78bfa', background: '#faf5ff' }}>
              <div className="card-title">👤 Add Individual Note</div>
              <div className="alert alert-success" style={{ marginBottom: 12, fontSize: 13 }}>
                ℹ️ This note is <strong>only visible to that teen's assigned mentor and admin</strong>
              </div>
              {kidError && <div className="alert alert-error"   style={{ marginBottom: 12 }}>{kidError}</div>}
              {kidMsg   && <div className="alert alert-success" style={{ marginBottom: 12 }}>{kidMsg}</div>}
              <div className="form-grid">
                <div className="field">
                  <label className="required">Select Teen</label>
                  <select value={kidForm.kid_id} onChange={e => setKidForm(f => ({ ...f, kid_id: e.target.value }))}>
                    <option value="">— Select Teen —</option>
                    {session.attendance?.map((a: any) => (
                      <option key={a.kid_id} value={a.kid_id}>{a.first_name} {a.last_name}{a.is_present ? ' ✅' : ''}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="field" style={{ marginBottom: 12 }}>
                <label className="required">Notes / Observations</label>
                <textarea rows={5} value={kidForm.content} maxLength={2000}
                  onChange={e => setKidForm(f => ({ ...f, content: e.target.value }))}
                  placeholder="Observations, spiritual assessment, behavioral notes about this teen..." />
              </div>
              <div className="field" style={{ marginBottom: 12 }}>
                <label>Areas for Improvement <span style={{ color: 'var(--muted)', fontWeight: 400, fontSize: 12 }}>(for mentor)</span></label>
                <textarea rows={3} value={kidForm.improvement} maxLength={1000}
                  onChange={e => setKidForm(f => ({ ...f, improvement: e.target.value }))}
                  placeholder="What areas need improvement? What should the mentor focus on?" />
              </div>
              <div className="field" style={{ marginBottom: 16 }}>
                <label>Suggestions for Mentor</label>
                <textarea rows={3} value={kidForm.suggestions} maxLength={1000}
                  onChange={e => setKidForm(f => ({ ...f, suggestions: e.target.value }))}
                  placeholder="Specific suggestions or action items for the mentor..." />
              </div>
              <div className="btn-row">
                <button className="btn btn-success" onClick={handleAddKidNote} disabled={savingKid}>
                  {savingKid ? 'Saving...' : '✅ Save Note'}
                </button>
              </div>
            </div>
          )}

          {(!session.kidNotes || session.kidNotes.length === 0)
            ? <div className="card"><p style={{ color: 'var(--muted)', textAlign: 'center', padding: '32px 0' }}>
                No individual notes yet.{canWrite && !locked ? ' Click "+ Add Individual Note" to add one.' : ''}
              </p></div>
            : session.kidNotes.map((note: any) => (
              <div key={note.note_id} className="card" style={{ marginBottom: 14 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                  <div>
                    <span style={{ fontWeight: 700, fontSize: 15, cursor: 'pointer', color: 'var(--primary)' }}
                      onClick={() => navigate(`/kid/${note.kid_id}`)}>
                      {note.first_name} {note.last_name}
                    </span>
                    <span style={{ fontSize: 12, color: 'var(--muted)', marginLeft: 10 }}>
                      <code>{note.registration_id}</code> · by {note.author_name} · {note.created_at?.slice(0, 10)}
                    </span>
                  </div>
                  {canEditContent && !locked && (
                    <button className="btn btn-danger btn-sm" onClick={() => handleDeleteKidNote(note.note_id)}>🗑</button>
                  )}
                </div>
                <div style={{ marginBottom: note.improvement ? 10 : 0 }}>
                  <div style={{ fontWeight: 600, fontSize: 12, color: 'var(--muted)', marginBottom: 4 }}>NOTES / OBSERVATIONS</div>
                  <p style={{ lineHeight: 1.7, whiteSpace: 'pre-wrap' }}>{note.content}</p>
                </div>
                {note.improvement && (
                  <div style={{ marginBottom: note.suggestions ? 10 : 0, background: '#fff7ed', padding: '10px 14px', borderRadius: 8, borderLeft: '4px solid #f97316' }}>
                    <div style={{ fontWeight: 600, fontSize: 12, color: '#c2410c', marginBottom: 4 }}>⚠️ AREAS FOR IMPROVEMENT</div>
                    <p style={{ lineHeight: 1.7, whiteSpace: 'pre-wrap' }}>{note.improvement}</p>
                  </div>
                )}
                {note.suggestions && (
                  <div style={{ background: '#f0fdf4', padding: '10px 14px', borderRadius: 8, borderLeft: '4px solid #22c55e' }}>
                    <div style={{ fontWeight: 600, fontSize: 12, color: '#15803d', marginBottom: 4 }}>💡 SUGGESTIONS FOR MENTOR</div>
                    <p style={{ lineHeight: 1.7, whiteSpace: 'pre-wrap' }}>{note.suggestions}</p>
                  </div>
                )}
              </div>
            ))
          }
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════ */}
      {/* SIGN BUTTON (draft only, canWrite, not cancelled)           */}
      {/* ═══════════════════════════════════════════════════════════ */}
      {canEditContent && !session.is_signed && !session.is_cancelled && (
        <div className="card" style={{ marginBottom: 16, borderColor: '#1d4ed8', background: '#eff6ff' }}>
          <div className="card-title" style={{ color: '#1d4ed8' }}>✍️ Sign This Session</div>
          <p style={{ fontSize: 13, color: '#374151', marginBottom: 12 }}>
            Once signed, all session notes, attendance, and individual notes are <strong>permanently locked</strong>.
            You may still add supplementary notes afterwards.
          </p>
          {!signConfirm
            ? <div className="btn-row"><button className="btn btn-primary" onClick={() => setSignConfirm(true)}>✍️ Sign Session</button></div>
            : <div>
                <div className="alert alert-error" style={{ marginBottom: 12, fontSize: 13 }}>⚠️ This cannot be undone — all session data will be locked permanently.</div>
                <div className="btn-row">
                  <button className="btn btn-danger" onClick={handleSign} disabled={signing}>{signing ? 'Signing...' : '✅ Yes, Sign & Lock'}</button>
                  <button className="btn btn-outline" onClick={() => setSignConfirm(false)}>Cancel</button>
                </div>
              </div>
          }
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════ */}
      {/* POST-SIGN ADDON SECTION                                     */}
      {/* ═══════════════════════════════════════════════════════════ */}
      {session.is_signed && canEditContent && !session.is_cancelled && (
        <div className="card" style={{ marginBottom: 16, borderColor: '#7c3aed', background: '#faf5ff' }}>
          <div className="card-title" style={{ color: '#7c3aed' }}>
            📎 Additional Notes
            {session.addon_is_signed && <span style={{ fontSize: 12, color: '#16a34a', fontWeight: 700, marginLeft: 8 }}>✍️ Signed</span>}
          </div>
          <p style={{ fontSize: 13, color: '#374151', marginBottom: 12 }}>
            Add supplementary notes below (max {MAX_BOX} chars per box). Sign them to lock the additional notes.
          </p>
          {session.addon_is_signed ? (
            <ChainedBoxes boxes={splitIntoBoxes(session.addon_text || '')} onChange={() => {}} readOnly />
          ) : (
            <>
              <ChainedBoxes boxes={addonBoxes} onChange={setAddonBoxes} readOnly={false}
                placeholder="Add supplementary notes, follow-ups, or additional observations..." />
              {addonMsg   && <div className="alert alert-success" style={{ marginBottom: 8 }}>{addonMsg}</div>}
              {addonError && <div className="alert alert-error"   style={{ marginBottom: 8 }}>{addonError}</div>}
              <div className="btn-row">
                <button className="btn btn-outline" onClick={handleSaveAddon} disabled={savingAddon}>
                  {savingAddon ? 'Saving...' : '💾 Save Additional Notes'}
                </button>
                {joinBoxes(addonBoxes).trim() && (
                  <button className="btn btn-primary" onClick={handleSignAddon} disabled={signingAddon}>
                    {signingAddon ? 'Signing...' : '✍️ Sign Additional Notes'}
                  </button>
                )}
              </div>
            </>
          )}
        </div>
      )}

      {/* Read-only addon for mentors */}
      {!canWrite && session.addon_text && (
        <div className="card" style={{ marginBottom: 16 }}>
          <div className="card-title">
            📎 Additional Notes
            {session.addon_is_signed && <span style={{ fontSize: 12, color: '#16a34a', marginLeft: 8 }}>✍️ Signed</span>}
          </div>
          <ChainedBoxes boxes={splitIntoBoxes(session.addon_text)} onChange={() => {}} readOnly />
        </div>
      )}

      {/* Cancel modal */}
      {showCancelModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
          <div className="card" style={{ width: '100%', maxWidth: 480, margin: 0 }}>
            <div className="card-title" style={{ color: '#dc2626' }}>Cancel Session</div>
            <p style={{ fontSize: 13, color: '#374151', marginBottom: 12 }}>
              All mentors will be notified immediately. This cannot be undone.
            </p>
            <div className="field">
              <label className="required">Reason for cancellation</label>
              <textarea rows={3} value={cancelReason} onChange={e => setCancelReason(e.target.value)}
                placeholder="Explain why the session is being cancelled…" maxLength={300} />
            </div>
            <div className="field">
              <label>Propose a new date (optional)</label>
              <input type="date" value={proposeNewDate}
                min={new Date().toISOString().slice(0, 10)}
                max={new Date(Date.now() + 60 * 86400000).toISOString().slice(0, 10)}
                onChange={e => setProposeNewDate(e.target.value)} />
            </div>
            {proposeNewDate && (
              <div className="field">
                <label>New topic / title (optional)</label>
                <input value={proposeNewTopic} onChange={e => setProposeNewTopic(e.target.value)}
                  placeholder="Topic for the proposed new session" maxLength={200} />
              </div>
            )}
            {cancelError && <div className="alert alert-error" style={{ marginBottom: 8 }}>{cancelError}</div>}
            <div className="btn-row">
              <button className="btn btn-outline btn-sm" onClick={() => setShowCancelModal(false)}>Keep Session</button>
              <button className="btn btn-danger btn-sm" onClick={handleCancel} disabled={cancelling}>
                {cancelling ? 'Cancelling…' : 'Confirm Cancel'}
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
