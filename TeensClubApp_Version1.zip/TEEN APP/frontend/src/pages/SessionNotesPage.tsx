import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  getKid, getSessionNotes, addSessionNote, deleteSessionNote,
  signSessionNote, unlockSessionNote, createEditRequest, updateSessionNote,
} from '../api';
import { useAuth } from '../AuthContext';

function CharCount({ value, max }: { value: string; max: number }) {
  const over = value.length > max;
  return <span className={`char-count ${over ? 'over' : ''}`}>{value.length}/{max}</span>;
}

function NoteBadge({ note }: { note: any }) {
  if (note.is_signed) return <span style={{ background: '#f59e0b', color: '#fff', borderRadius: 12, padding: '2px 8px', fontSize: 11, fontWeight: 700 }}>✍️ Signed</span>;
  return <span style={{ background: '#94a3b8', color: '#fff', borderRadius: 12, padding: '2px 8px', fontSize: 11, fontWeight: 700 }}>📝 Draft</span>;
}

export default function SessionNotesPage() {
  const { kidId } = useParams<{ kidId: string }>();
  const navigate = useNavigate();
  const { isAdmin, user } = useAuth();
  const isMentor = user?.role === 'MENTOR';

  const [kid, setKid] = useState<any>(null);
  const [notes, setNotes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);

  const [form, setForm] = useState({
    session_date: new Date().toISOString().slice(0, 10),
    discussion: '', outcome: '', next_steps: '',
  });
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');

  // Per-note action state
  const [noteAction, setNoteAction] = useState<{ [noteId: string]: string }>({});
  const [noteError, setNoteError] = useState<{ [noteId: string]: string }>({});

  // Inline edit state for draft notes
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState({ session_date: '', discussion: '', outcome: '', next_steps: '' });
  const [editSaving, setEditSaving] = useState(false);

  // Request edit modal
  const [requestModal, setRequestModal] = useState<{ noteId: string; label: string } | null>(null);
  const [requestReason, setRequestReason] = useState('');
  const [requestSaving, setRequestSaving] = useState(false);
  const [globalMsg, setGlobalMsg] = useState('');

  const loadNotes = () => getSessionNotes(kidId!).then(setNotes);

  useEffect(() => {
    if (!kidId) return;
    Promise.all([getKid(kidId), getSessionNotes(kidId)])
      .then(([k, n]) => { setKid(k); setNotes(n); })
      .finally(() => setLoading(false));
  }, [kidId]);

  const handleSave = async () => {
    if (!form.session_date) { setError('Session date is required'); return; }
    if (!form.discussion.trim()) { setError('Discussion field is required'); return; }
    setSaving(true); setMsg(''); setError('');
    try {
      await addSessionNote({ kid_id: kidId, ...form });
      setMsg('Session note saved successfully!');
      setForm({ session_date: new Date().toISOString().slice(0, 10), discussion: '', outcome: '', next_steps: '' });
      setShowForm(false);
      loadNotes();
    } catch (e: any) {
      setError(e.response?.data?.error || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (noteId: string) => {
    if (!window.confirm('Delete this session note?')) return;
    try { await deleteSessionNote(noteId); setMsg('Note deleted'); loadNotes(); }
    catch (e: any) { setError(e.response?.data?.error || 'Delete failed'); }
  };

  const noteAction_ = async (noteId: string, action: 'sign' | 'unlock') => {
    const labels = { sign: 'sign', unlock: 'unlock' };
    if (!window.confirm(`Are you sure you want to ${labels[action]} this note?`)) return;
    setNoteError(e => ({ ...e, [noteId]: '' }));
    setNoteAction(a => ({ ...a, [noteId]: action }));
    try {
      if (action === 'sign')   await signSessionNote(noteId);
      if (action === 'unlock') await unlockSessionNote(noteId);
      setGlobalMsg(`Note ${action === 'sign' ? 'signed and locked' : 'unlocked'}.`);
      loadNotes();
    } catch (e: any) {
      setNoteError(ne => ({ ...ne, [noteId]: e.response?.data?.error || `${action} failed` }));
    } finally {
      setNoteAction(a => ({ ...a, [noteId]: '' }));
    }
  };

  const handleRequestEdit = async () => {
    if (!requestReason.trim() || !requestModal) return;
    setRequestSaving(true);
    try {
      await createEditRequest({
        entity_type: 'MENTOR_NOTE',
        entity_id: requestModal.noteId,
        entity_label: requestModal.label,
        reason: requestReason.trim(),
      });
      setGlobalMsg('Edit request submitted. Admin will review and unlock the note if approved.');
      setRequestModal(null);
      setRequestReason('');
    } catch (e: any) {
      setNoteError(ne => ({ ...ne, [requestModal.noteId]: e.response?.data?.error || 'Request failed' }));
    } finally {
      setRequestSaving(false);
    }
  };

  const startEditNote = (note: any) => {
    setEditingNoteId(note.note_id);
    setEditForm({
      session_date: note.session_date || '',
      discussion:   note.discussion  || '',
      outcome:      note.outcome     || '',
      next_steps:   note.next_steps  || '',
    });
    setNoteError(e => ({ ...e, [note.note_id]: '' }));
  };

  const handleSaveEdit = async (noteId: string) => {
    if (!editForm.session_date) { setNoteError(e => ({ ...e, [noteId]: 'Session date required' })); return; }
    if (!editForm.discussion.trim()) { setNoteError(e => ({ ...e, [noteId]: 'Discussion is required' })); return; }
    setEditSaving(true);
    try {
      await updateSessionNote(noteId, editForm);
      setGlobalMsg('Note updated successfully.');
      setEditingNoteId(null);
      loadNotes();
    } catch (e: any) {
      setNoteError(ne => ({ ...ne, [noteId]: e.response?.data?.error || 'Update failed' }));
    } finally { setEditSaving(false); }
  };

  if (loading) return <main className="page"><p>Loading...</p></main>;
  if (!kid) return <main className="page"><p style={{ color: 'var(--danger)' }}>Student not found.</p></main>;

  return (
    <main className="page">
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24 }}>
        <button className="btn btn-outline btn-sm" onClick={() => navigate(-1)}>← Back</button>
        <div>
          <h2 style={{ fontSize: 22, fontWeight: 700 }}>🗒 Session Notes</h2>
          <p style={{ fontSize: 13, color: 'var(--muted)', marginTop: 2 }}>
            {kid.first_name} {kid.last_name} · <code>{kid.registration_id}</code>
          </p>
        </div>
        <div style={{ flex: 1 }} />
        {(isMentor || isAdmin) && (
          <button className="btn btn-primary btn-sm" onClick={() => { setShowForm(!showForm); setMsg(''); setError(''); }}>
            {showForm ? 'Cancel' : '+ Add Note'}
          </button>
        )}
      </div>

      {globalMsg && <div className="alert alert-success">{globalMsg}</div>}
      {msg && <div className="alert alert-success">{msg}</div>}
      {error && <div className="alert alert-error">{error}</div>}

      {/* Add Note Form */}
      {showForm && (
        <div className="card" style={{ marginBottom: 20 }}>
          <div className="card-title">New Session Note</div>
          <div className="form-grid">
            <div className="field">
              <label className="required">Session Date</label>
              <input type="date" value={form.session_date}
                onChange={e => setForm(f => ({ ...f, session_date: e.target.value }))} />
            </div>
          </div>
          <div className="field" style={{ marginBottom: 12 }}>
            <label className="required" style={{ display: 'flex', justifyContent: 'space-between' }}>
              Discussion <CharCount value={form.discussion} max={1000} />
            </label>
            <textarea value={form.discussion} rows={4}
              onChange={e => setForm(f => ({ ...f, discussion: e.target.value }))}
              placeholder="What was discussed in this session? (max 1000 characters)"
              maxLength={1000} />
          </div>
          <div className="field" style={{ marginBottom: 12 }}>
            <label style={{ display: 'flex', justifyContent: 'space-between' }}>
              Outcome <CharCount value={form.outcome} max={500} />
            </label>
            <textarea value={form.outcome} rows={3}
              onChange={e => setForm(f => ({ ...f, outcome: e.target.value }))}
              placeholder="What was the outcome or progress? (max 500 characters)"
              maxLength={500} />
          </div>
          <div className="field" style={{ marginBottom: 16 }}>
            <label style={{ display: 'flex', justifyContent: 'space-between' }}>
              Next Steps <CharCount value={form.next_steps} max={500} />
            </label>
            <textarea value={form.next_steps} rows={3}
              onChange={e => setForm(f => ({ ...f, next_steps: e.target.value }))}
              placeholder="Planned next steps or follow-up actions (max 500 characters)"
              maxLength={500} />
          </div>
          <div className="btn-row">
            <button className="btn btn-success" onClick={handleSave} disabled={saving}>
              {saving ? 'Saving...' : '💾 Save Note'}
            </button>
          </div>
        </div>
      )}

      {/* Notes list */}
      {notes.length === 0 ? (
        <div className="card">
          <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '32px 0' }}>
            No session notes yet. Click "+ Add Note" to record the first session.
          </p>
        </div>
      ) : (
        notes.map((note: any) => {
          const isLocked = note.is_signed;
          const isMyNote = note.mentor_id === user?.user_id;
          const canActOnNote = isMentor ? isMyNote : isAdmin;
          const isInherited = !!note.is_inherited;
          const canEdit = canActOnNote && !isLocked && !isInherited;

          return (
            <div key={note.note_id} className="card" style={{ marginBottom: 14 }}>
              {/* Note header */}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
                  <span style={{ fontWeight: 700, fontSize: 15 }}>🗒 {note.session_date}</span>
                  <span style={{ fontSize: 13, color: 'var(--muted)' }}>by {note.mentor_name}</span>
                  <NoteBadge note={note} />
                  {isInherited && (
                    <span style={{ background: '#6c757d', color: '#fff', borderRadius: 12, padding: '2px 8px', fontSize: 11, fontWeight: 700 }}>
                      📎 Transferred
                    </span>
                  )}
                </div>
                <div style={{ display: 'flex', gap: 6 }}>
                  {canEdit && editingNoteId !== note.note_id && (
                    <button className="btn btn-outline btn-sm" onClick={() => startEditNote(note)}>
                      ✏️ Edit
                    </button>
                  )}
                  {editingNoteId === note.note_id && (
                    <button className="btn btn-outline btn-sm" onClick={() => setEditingNoteId(null)}>
                      Cancel
                    </button>
                  )}
                  {isAdmin && !isLocked && editingNoteId !== note.note_id && (
                    <button className="btn btn-danger btn-sm" onClick={() => handleDelete(note.note_id)}>Delete</button>
                  )}
                </div>
              </div>

              {/* Sign info */}
              {note.is_signed && (
                <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 8 }}>
                  Signed by {note.signed_by} on {note.signed_at?.slice(0, 10)}
                </div>
              )}

              {noteError[note.note_id] && (
                <div className="alert alert-error" style={{ marginBottom: 8, padding: '6px 10px', fontSize: 13 }}>{noteError[note.note_id]}</div>
              )}

              {/* Inline edit form for draft notes */}
              {editingNoteId === note.note_id ? (
                <div>
                  <div className="field" style={{ marginBottom: 10 }}>
                    <label style={{ fontWeight: 600, fontSize: 13 }}>Session Date</label>
                    <input type="date" value={editForm.session_date}
                      onChange={e => setEditForm(f => ({ ...f, session_date: e.target.value }))} />
                  </div>
                  <div className="field" style={{ marginBottom: 10 }}>
                    <label style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 600, fontSize: 13 }}>
                      Discussion <CharCount value={editForm.discussion} max={1000} />
                    </label>
                    <textarea rows={4} maxLength={1000} value={editForm.discussion}
                      onChange={e => setEditForm(f => ({ ...f, discussion: e.target.value }))} />
                  </div>
                  <div className="field" style={{ marginBottom: 10 }}>
                    <label style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 600, fontSize: 13 }}>
                      Outcome <CharCount value={editForm.outcome} max={500} />
                    </label>
                    <textarea rows={3} maxLength={500} value={editForm.outcome}
                      onChange={e => setEditForm(f => ({ ...f, outcome: e.target.value }))} />
                  </div>
                  <div className="field" style={{ marginBottom: 12 }}>
                    <label style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 600, fontSize: 13 }}>
                      Next Steps <CharCount value={editForm.next_steps} max={500} />
                    </label>
                    <textarea rows={3} maxLength={500} value={editForm.next_steps}
                      onChange={e => setEditForm(f => ({ ...f, next_steps: e.target.value }))} />
                  </div>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button className="btn btn-success btn-sm" onClick={() => handleSaveEdit(note.note_id)} disabled={editSaving}>
                      {editSaving ? 'Saving…' : '💾 Save Changes'}
                    </button>
                    <button className="btn btn-outline btn-sm" onClick={() => setEditingNoteId(null)}>Cancel</button>
                  </div>
                </div>
              ) : (
                <>
                  {/* Content (read-only) */}
                  {note.discussion && (
                    <div style={{ marginBottom: 10 }}>
                      <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--muted)', marginBottom: 4, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Discussion</div>
                      <p style={{ whiteSpace: 'pre-wrap', margin: 0, lineHeight: 1.6 }}>{note.discussion}</p>
                    </div>
                  )}
                  {note.outcome && (
                    <div style={{ marginBottom: 10 }}>
                      <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--muted)', marginBottom: 4, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Outcome</div>
                      <p style={{ whiteSpace: 'pre-wrap', margin: 0, lineHeight: 1.6 }}>{note.outcome}</p>
                    </div>
                  )}
                  {note.next_steps && (
                    <div style={{ marginBottom: 10 }}>
                      <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--muted)', marginBottom: 4, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Next Steps</div>
                      <p style={{ whiteSpace: 'pre-wrap', margin: 0, lineHeight: 1.6 }}>{note.next_steps}</p>
                    </div>
                  )}
                </>
              )}

              {/* Action buttons */}
              {canActOnNote && (
                <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid var(--border)', display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {!note.is_signed && (
                    <button className="btn btn-sm" style={{ background: '#f59e0b', color: '#fff' }}
                      onClick={() => noteAction_(note.note_id, 'sign')}
                      disabled={!!noteAction[note.note_id]}>
                      ✍️ Sign Note
                    </button>
                  )}
                  {isAdmin && isLocked && (
                    <button className="btn btn-outline btn-sm"
                      onClick={() => noteAction_(note.note_id, 'unlock')}
                      disabled={!!noteAction[note.note_id]}>
                      🔓 Unlock
                    </button>
                  )}
                  {!isAdmin && isLocked && (
                    <button className="btn btn-sm" style={{ background: '#f97316', color: '#fff', border: 'none' }}
                      onClick={() => { setRequestModal({ noteId: note.note_id, label: `Session note ${note.session_date} for ${kid.first_name} ${kid.last_name}` }); setRequestReason(''); }}>
                      📩 Request Edit
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })
      )}

      {/* Request Edit Modal */}
      {requestModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
          <div className="card" style={{ width: '100%', maxWidth: 480, margin: 0 }}>
            <div className="card-title">📩 Request to Edit Session Note</div>
            <p style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 12 }}>
              Describe what needs to be changed. The admin will review and unlock the note if approved.
            </p>
            <div className="field">
              <label className="required">Reason for Edit</label>
              <textarea rows={4} value={requestReason} onChange={e => setRequestReason(e.target.value)}
                placeholder="e.g. Incorrect date, need to update discussion notes..." maxLength={500} />
              <span style={{ fontSize: 12, color: 'var(--muted)' }}>{requestReason.length}/500</span>
            </div>
            {noteError[requestModal.noteId] && (
              <div className="alert alert-error" style={{ marginBottom: 8 }}>{noteError[requestModal.noteId]}</div>
            )}
            <div className="btn-row">
              <button className="btn btn-outline btn-sm" onClick={() => setRequestModal(null)}>Cancel</button>
              <button className="btn btn-primary btn-sm" onClick={handleRequestEdit} disabled={requestSaving || !requestReason.trim()}>
                {requestSaving ? 'Submitting...' : '📩 Submit Request'}
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
