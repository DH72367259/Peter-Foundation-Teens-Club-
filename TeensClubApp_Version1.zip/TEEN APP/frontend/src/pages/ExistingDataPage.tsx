import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { searchKids, getKids, filterKids, getFilterMeta } from '../api';

interface FilterMeta {
  ages: number[];
  education_levels: string[];
  genders: string[];
  schools: string[];
  hobbies: { hobby_id: number; name: string }[];
  interests: { interest_id: number; name: string }[];
}

export default function ExistingDataPage() {
  const navigate = useNavigate();
  const [query, setQuery]     = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [label, setLabel]     = useState('');
  const [hasSearched, setHasSearched] = useState(false);

  // Filter state
  const [showFilters, setShowFilters]   = useState(false);
  const [meta, setMeta]                 = useState<FilterMeta>({ ages: [], education_levels: [], genders: [], schools: [], hobbies: [], interests: [] });
  const [filters, setFilters] = useState({
    age: '', gender: '', education_level: '', school: '',
    interest_ids: [] as number[], ambition: '',
  });

  useEffect(() => {
    getFilterMeta().then(setMeta).catch(() => {});
  }, []);

  const updateFilter = (k: string, v: any) => setFilters(f => ({ ...f, [k]: v }));
  const toggleInterest = (id: number) =>
    setFilters(f => ({
      ...f,
      interest_ids: f.interest_ids.includes(id)
        ? f.interest_ids.filter(x => x !== id)
        : [...f.interest_ids, id]
    }));

  const handleSearch = async () => {
    if (!query.trim()) return;
    setLoading(true); setHasSearched(true);
    setLabel(`Search: "${query}"`);
    try { setResults(await searchKids(query.trim())); }
    catch { setResults([]); }
    finally { setLoading(false); }
  };

  const handleShowAll = useCallback(async () => {
    setLoading(true); setHasSearched(true);
    setLabel('All Approved & Signed Records');
    try {
      const d = await getKids(1);
      setResults(d.data || []);
    } catch { setResults([]); }
    finally { setLoading(false); }
  }, []);

  const handleApplyFilters = async () => {
    const params: Record<string, any> = {};
    if (filters.age)              params.age = parseInt(filters.age);
    if (filters.gender)           params.gender = filters.gender;
    if (filters.education_level)  params.education_level = filters.education_level;
    if (filters.school)           params.school = filters.school;
    if (filters.interest_ids.length > 0) params.interest_ids = filters.interest_ids.join(',');
    if (filters.ambition)         params.ambition = filters.ambition;
    if (Object.keys(params).length === 0) { handleShowAll(); return; }

    setLoading(true); setHasSearched(true);
    const parts: string[] = [];
    if (filters.age)             parts.push(`Age ${filters.age}`);
    if (filters.gender)          parts.push(filters.gender);
    if (filters.education_level) parts.push(filters.education_level);
    if (filters.school)          parts.push(`School: ${filters.school}`);
    if (filters.interest_ids.length > 0) {
      const names = meta.interests.filter(i => filters.interest_ids.includes(i.interest_id)).map(i => i.name);
      parts.push(`Interests: ${names.join(', ')}`);
    }
    setLabel(`Filtered: ${parts.join(' · ')}`);
    try { setResults(await filterKids(params)); }
    catch { setResults([]); }
    finally { setLoading(false); }
  };

  const handleClear = () => {
    setQuery(''); setResults([]); setHasSearched(false); setLabel('');
    setFilters({ age: '', gender: '', education_level: '', school: '', interest_ids: [], ambition: '' });
  };

  const activeFilterCount = [filters.age, filters.gender, filters.education_level, filters.school, filters.ambition]
    .filter(Boolean).length + filters.interest_ids.length;

  return (
    <main className="page">
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 20 }}>
        <h2 style={{ fontSize: 22, fontWeight: 700 }}>Existing Data</h2>
        <span style={{ fontSize: 13, color: 'var(--muted)', marginLeft: 4 }}>Only approved & signed records</span>
      </div>

      <div className="card" style={{ marginBottom: 16 }}>
        <p style={{ color: 'var(--muted)', marginBottom: 12, fontSize: 13 }}>
          Search by <strong>Registration ID</strong>, <strong>Phone</strong>, or <strong>Name</strong>.
          Use <strong>Show All</strong> to list all, or <strong>Filters</strong> for advanced search.
        </p>
        <div className="search-box" style={{ flexWrap: 'wrap', gap: 8 }}>
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSearch()}
            placeholder="Enter name, Reg ID, or phone number…"
            autoFocus
            style={{ flex: '1 1 220px' }}
          />
          <button className="btn btn-primary" onClick={handleSearch} disabled={loading || !query.trim()}>
            {loading ? '🔍…' : '🔍 Search'}
          </button>
          <button className="btn btn-outline" onClick={handleShowAll} disabled={loading}>
            📋 Show All
          </button>
          <button
            className="btn btn-outline"
            onClick={() => setShowFilters(v => !v)}
            style={activeFilterCount > 0 ? { borderColor: '#0d6efd', color: '#0d6efd', fontWeight: 600 } : {}}
          >
            🎛 Filters{activeFilterCount > 0 ? ` (${activeFilterCount})` : ''}
          </button>
          {hasSearched && (
            <button className="btn btn-outline" onClick={handleClear}>✕ Clear</button>
          )}
        </div>

        {/* Dynamic filter panel */}
        {showFilters && (
          <div style={{ marginTop: 16, padding: '1rem', background: '#f8f9fa', borderRadius: 8, border: '1px solid #dee2e6' }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 12 }}>

              {/* Age */}
              <div>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 4 }}>Age</label>
                <select value={filters.age} onChange={e => updateFilter('age', e.target.value)}
                  style={{ width: '100%', padding: '6px 8px', border: '1px solid #ced4da', borderRadius: 4 }}>
                  <option value="">— Any age —</option>
                  {meta.ages.map(a => <option key={a} value={String(a)}>{a} years</option>)}
                </select>
              </div>

              {/* Gender */}
              <div>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 4 }}>Gender</label>
                <select value={filters.gender} onChange={e => updateFilter('gender', e.target.value)}
                  style={{ width: '100%', padding: '6px 8px', border: '1px solid #ced4da', borderRadius: 4 }}>
                  <option value="">— Any gender —</option>
                  {meta.genders.map(g => <option key={g}>{g}</option>)}
                </select>
              </div>

              {/* Education Level */}
              <div>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 4 }}>Education Level</label>
                <select value={filters.education_level} onChange={e => updateFilter('education_level', e.target.value)}
                  style={{ width: '100%', padding: '6px 8px', border: '1px solid #ced4da', borderRadius: 4 }}>
                  <option value="">— Any level —</option>
                  {meta.education_levels.map(l => <option key={l}>{l}</option>)}
                </select>
              </div>

              {/* School */}
              <div>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 4 }}>School / College</label>
                <select value={filters.school} onChange={e => updateFilter('school', e.target.value)}
                  style={{ width: '100%', padding: '6px 8px', border: '1px solid #ced4da', borderRadius: 4 }}>
                  <option value="">— Any school —</option>
                  {meta.schools.map(s => <option key={s}>{s}</option>)}
                </select>
              </div>

              {/* Ambition */}
              <div style={{ gridColumn: '1 / -1' }}>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 4 }}>Ambition / Goal contains</label>
                <input value={filters.ambition} onChange={e => updateFilter('ambition', e.target.value)}
                  placeholder="e.g. engineer, doctor, artist…"
                  style={{ width: '100%', padding: '6px 8px', border: '1px solid #ced4da', borderRadius: 4, boxSizing: 'border-box' }} />
              </div>
            </div>

            {/* Interests chips */}
            {meta.interests.length > 0 && (
              <div style={{ marginTop: 12 }}>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Interests (select one or more)</label>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                  {meta.interests.map(i => (
                    <label key={i.interest_id} style={{
                      display: 'inline-flex', alignItems: 'center', gap: 4, cursor: 'pointer',
                      padding: '4px 12px', borderRadius: 16, border: '1px solid #ced4da',
                      background: filters.interest_ids.includes(i.interest_id) ? '#0d6efd' : '#fff',
                      color: filters.interest_ids.includes(i.interest_id) ? '#fff' : '#212529',
                      fontSize: 13, userSelect: 'none', transition: 'all .15s'
                    }}>
                      <input type="checkbox" style={{ display: 'none' }}
                        checked={filters.interest_ids.includes(i.interest_id)}
                        onChange={() => toggleInterest(i.interest_id)} />
                      {i.name}
                    </label>
                  ))}
                </div>
              </div>
            )}

            <div style={{ marginTop: 14, display: 'flex', gap: 8 }}>
              <button className="btn btn-primary" onClick={handleApplyFilters} disabled={loading}>
                {loading ? 'Searching…' : '🔎 Apply Filters'}
              </button>
              <button className="btn btn-outline" onClick={() => setFilters({ age: '', gender: '', education_level: '', school: '', interest_ids: [], ambition: '' })}>
                🔄 Reset
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Results */}
      {!hasSearched ? (
        <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--muted)', background: '#f8f9fa', borderRadius: 8 }}>
          <p style={{ fontSize: 18, marginBottom: 8 }}>🔍 No data displayed by default.</p>
          <p style={{ margin: 0 }}>Use <strong>Search</strong>, <strong>Show All</strong>, or <strong>Filters</strong> above to load records.</p>
        </div>
      ) : (
        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <div className="card-title" style={{ marginBottom: 0 }}>{label}</div>
            <span style={{ color: 'var(--muted)', fontSize: 13 }}>{results.length} record(s)</span>
          </div>

          {loading ? (
            <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '2rem 0' }}>Loading…</p>
          ) : results.length === 0 ? (
            <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '2rem 0' }}>No approved & signed records match your criteria.</p>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th style={{ width: 56 }}>Photo</th>
                    <th>Reg ID</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Education</th>
                    <th>School</th>
                    <th>Phone</th>
                    <th>Parent(s)</th>
                    <th>Hobbies</th>
                  </tr>
                </thead>
                <tbody>
                  {results.map((k: any) => (
                    <tr key={k.kid_id} onClick={() => navigate(`/kid/${k.kid_id}`)} style={{ cursor: 'pointer' }}>
                      <td>
                        {k.photo_data
                          ? <img src={k.photo_data} alt={k.first_name} style={{ width: 40, height: 40, objectFit: 'cover', borderRadius: '50%', border: '1.5px solid #dee2e6' }} />
                          : <div style={{ width: 40, height: 40, borderRadius: '50%', background: '#e9ecef', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, color: '#adb5bd' }}>👤</div>
                        }
                      </td>
                      <td><code style={{ color: 'var(--primary)', fontWeight: 600 }}>{k.registration_id}</code></td>
                      <td><strong>{k.first_name} {k.last_name}</strong></td>
                      <td>{k.age_snapshot ?? '—'}</td>
                      <td>{k.gender || '—'}</td>
                      <td>{k.education_level || '—'}</td>
                      <td>{k.school_name || '—'}</td>
                      <td>{k.phone_normalized || '—'}</td>
                      <td>
                        {(k.parents || []).map((p: any) => (
                          <div key={p.full_name} style={{ fontSize: 12 }}>
                            {p.full_name} ({p.relationship})
                          </div>
                        ))}
                      </td>
                      <td>
                        {(k.hobbies || []).slice(0, 3).join(', ')}
                        {(k.hobbies || []).length > 3 ? ` +${k.hobbies.length - 3}` : ''}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </main>
  );
}

