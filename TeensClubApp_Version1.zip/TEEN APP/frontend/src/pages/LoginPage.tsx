import { useState } from 'react';
import { login as apiLogin } from '../api';
import { useAuth } from '../AuthContext';

export default function LoginPage() {
  const { login } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = await apiLogin(username.trim(), password);
      login(data.token, data.user);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-wrap">
      <div className="login-card">
        <div className="login-logo">
          <div style={{ fontSize: 40, marginBottom: 8 }}>✝️</div>
          <h1>Peter Foundation Teen's Club</h1>
          <p>Church Registration System</p>
        </div>
        {error && <div className="alert alert-error">{error}</div>}
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div className="field">
            <label className="required">Username</label>
            <input value={username} onChange={e => { setUsername(e.target.value); if (error) setError(''); }}
              placeholder="Enter username" required autoFocus />
          </div>
          <div className="field">
            <label className="required">Password</label>
            <input type="password" value={password} onChange={e => { setPassword(e.target.value); if (error) setError(''); }}
              placeholder="Enter password" required />
          </div>
          <button type="submit" className="btn btn-primary" disabled={loading} style={{ marginTop: 4 }}>
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>

      </div>
    </div>
  );
}
