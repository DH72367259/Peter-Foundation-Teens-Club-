import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { getPendingRequestCount, getPendingSubmissionsCount, getBackupStatus, triggerBackup } from '../api';

export default function HomePage() {
  const navigate = useNavigate();
  const { user, isAdmin } = useAuth();
  const isSpiritualLeader = user?.role === 'SPIRITUAL_LEADER';
  const isDataEntry       = user?.role === 'DATA_ENTRY' || user?.role === 'SUB';
  const isMentor          = user?.role === 'MENTOR';

  const [pendingRequests,    setPendingRequests]    = useState(0);
  const [pendingSubmissions, setPendingSubmissions] = useState(0);
  const [backupStatus, setBackupStatus] = useState<any>(null);
  const [backingUp,    setBackingUp]    = useState(false);
  const [backupMsg,    setBackupMsg]    = useState('');

  useEffect(() => {
    if (isDataEntry)      { navigate('/register',          { replace: true }); return; }
    if (isMentor)         { navigate('/mentor-dashboard',  { replace: true }); return; }
    if (isSpiritualLeader){ navigate('/existing',          { replace: true }); return; }
    if (isAdmin) {
      getPendingRequestCount().then((d: any)    => setPendingRequests(d.count    || 0)).catch(() => {});
      getPendingSubmissionsCount().then((d: any) => setPendingSubmissions(d.count || 0)).catch(() => {});
      getBackupStatus().then(setBackupStatus).catch(() => {});
    }
  }, [isAdmin, isDataEntry, isMentor, isSpiritualLeader]);

  const handleBackupNow = async () => {
    setBackingUp(true); setBackupMsg('');
    try {
      const r = await triggerBackup();
      setBackupMsg('Backup completed ✔');
      setBackupStatus((s: any) => ({ ...s, lastBackup: r }));
    } catch (e: any) {
      setBackupMsg(e.response?.data?.error || 'Backup failed');
    } finally {
      setBackingUp(false);
      setTimeout(() => setBackupMsg(''), 4000);
    }
  };

  if (!isAdmin) return null;

  return (
    <main className="page">
      <div style={{ textAlign: 'center', paddingTop: 16, paddingBottom: 28 }}>
        <h1 style={{ fontSize: 26, fontWeight: 800, color: 'var(--text)' }}>
          Welcome, {user?.full_name}
        </h1>
        <p style={{ color: 'var(--muted)', marginTop: 4 }}>
          Teen's Club — Church Registration System
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: 16 }}>
        <div
          className="card"
          style={{
            textAlign: 'center',
            cursor: 'pointer',
            border: pendingSubmissions > 0 ? '2px solid #0d6efd' : '1px solid var(--border)',
          }}
          onClick={() => navigate('/admin/submissions')}
        >
          <div style={{ fontSize: 32, marginBottom: 8 }}>📋</div>
          <div style={{ fontSize: 30, fontWeight: 800, color: pendingSubmissions > 0 ? '#0d6efd' : 'var(--text)' }}>
            {pendingSubmissions}
          </div>
          <div style={{ color: 'var(--muted)', fontSize: 13, marginTop: 4 }}>Pending Submissions</div>
        </div>

        <div
          className="card"
          style={{
            textAlign: 'center',
            cursor: 'pointer',
            border: pendingRequests > 0 ? '2px solid #f97316' : '1px solid var(--border)',
          }}
          onClick={() => navigate('/admin/edit-requests')}
        >
          <div style={{ fontSize: 32, marginBottom: 8 }}>📩</div>
          <div style={{ fontSize: 30, fontWeight: 800, color: pendingRequests > 0 ? '#f97316' : 'var(--text)' }}>
            {pendingRequests}
          </div>
          <div style={{ color: 'var(--muted)', fontSize: 13, marginTop: 4 }}>Edit Requests</div>
        </div>

        <div
          className="card"
          style={{ textAlign: 'center', cursor: 'pointer' }}
          onClick={() => navigate('/analytics')}
        >
          <div style={{ fontSize: 32, marginBottom: 8 }}>📊</div>
          <div style={{ color: 'var(--muted)', fontSize: 13, marginTop: 12 }}>View Analytics</div>
        </div>

        {/* ── Backup card ─────────────────────────────────────────────────── */}
        <div className="card" style={{ textAlign: 'center', minWidth: 180 }}>
          <div style={{ fontSize: 32, marginBottom: 6 }}>
            {backupStatus?.lastBackup?.success === false ? '⚠️' : '💾'}
          </div>

          {/* Cloud / local label */}
          <div style={{ fontSize: 12, fontWeight: 700, color: backupStatus?.cloudConfigured ? '#16a34a' : '#6c757d', marginBottom: 4 }}>
            {backupStatus?.cloudConfigured
              ? `✅ ${backupStatus.cloudService}`
              : '📁 Local folder'}
          </div>

          {/* Last backup time */}
          <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 10 }}>
            {backupStatus?.lastBackup
              ? (() => {
                  const mins = Math.round((Date.now() - new Date(backupStatus.lastBackup.timestamp).getTime()) / 60000);
                  if (mins < 2)  return 'Just now';
                  if (mins < 60) return `${mins} min ago`;
                  const hrs = Math.floor(mins / 60);
                  return hrs === 1 ? '1 hour ago' : `${hrs} hours ago`;
                })()
              : 'Not yet backed up'}
          </div>

          {backupMsg && (
            <div style={{ fontSize: 11, color: backupMsg.includes('✔') ? '#16a34a' : '#dc2626', marginBottom: 6 }}>
              {backupMsg}
            </div>
          )}

          <button
            onClick={handleBackupNow}
            disabled={backingUp}
            style={{ padding: '5px 14px', borderRadius: 6, border: 'none', background: '#0d6efd', color: '#fff', cursor: backingUp ? 'not-allowed' : 'pointer', fontSize: 12, fontWeight: 600, opacity: backingUp ? 0.7 : 1 }}
          >
            {backingUp ? '⏳ Backing up…' : '💾 Backup Now'}
          </button>

          <div style={{ color: 'var(--muted)', fontSize: 11, marginTop: 6 }}>Auto: every hour</div>
        </div>
      </div>
    </main>
  );
}
