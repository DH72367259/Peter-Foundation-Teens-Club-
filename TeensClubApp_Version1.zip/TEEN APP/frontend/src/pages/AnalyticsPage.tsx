import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  BarChart, Bar, PieChart, Pie, Cell, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';
import {
  getAnalyticsSummary, getHobbyStats, getInterestStats,
  getAgeGroups, getEducationLevels, getRegistrationsPerMonth, getGenderStats
} from '../api';

const COLORS = ['#2563eb','#7c3aed','#16a34a','#d97706','#dc2626','#0891b2',
                 '#9333ea','#ea580c','#0d9488','#be185d','#65a30d','#7c3aed'];

export default function AnalyticsPage() {
  const navigate = useNavigate();
  const [summary, setSummary] = useState<any>({});
  const [hobbies, setHobbies] = useState<any[]>([]);
  const [interests, setInterests] = useState<any[]>([]);
  const [ageGroups, setAgeGroups] = useState<any[]>([]);
  const [eduLevels, setEduLevels] = useState<any[]>([]);
  const [monthly, setMonthly] = useState<any[]>([]);
  const [gender, setGender] = useState<any[]>([]);

  useEffect(() => {
    Promise.all([
      getAnalyticsSummary(), getHobbyStats(), getInterestStats(),
      getAgeGroups(), getEducationLevels(), getRegistrationsPerMonth(), getGenderStats()
    ]).then(([s, h, i, a, e, m, g]) => {
      setSummary(s); setHobbies(h); setInterests(i);
      setAgeGroups(a); setEduLevels(e); setMonthly(m); setGender(g);
    });
  }, []);

  return (
    <main className="page">
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24 }}>
        <button className="btn btn-outline btn-sm" onClick={() => navigate('/')}>← Home</button>
        <h2 style={{ fontSize: 22, fontWeight: 700 }}>📊 Analytics Dashboard</h2>
      </div>

      {/* Summary Stats */}
      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-label">Total Registrations</div>
          <div className="stat-value">{summary.totalKids ?? 0}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Parent Records</div>
          <div className="stat-value">{summary.totalParents ?? 0}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">This Month</div>
          <div className="stat-value" style={{ color: 'var(--success)' }}>{summary.thisMonth ?? 0}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Baptised / Confirmed</div>
          <div className="stat-value" style={{ color: 'var(--secondary)' }}>{summary.baptised ?? 0}</div>
        </div>
      </div>

      {/* Charts grid */}
      <div className="charts-grid">

        {/* Hobbies Bar Chart */}
        <div className="card chart-section">
          <h3>Top Hobbies</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={hobbies.filter(h => h.count > 0)} margin={{ left: -10 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} interval={0} angle={-30} textAnchor="end" height={60} />
              <YAxis allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" name="Members" fill="#2563eb" radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Age Group Pie */}
        <div className="card chart-section">
          <h3>Age Group Distribution</h3>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={ageGroups} dataKey="count" nameKey="group_name" cx="50%" cy="50%" outerRadius={100} label={({ group_name, percent }) => `${group_name} (${(percent * 100).toFixed(0)}%)`} labelLine>
                {ageGroups.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Education Levels Bar */}
        <div className="card chart-section">
          <h3>Education Level Breakdown</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={eduLevels} layout="vertical" margin={{ left: 20 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" allowDecimals={false} />
              <YAxis type="category" dataKey="level" tick={{ fontSize: 11 }} width={160} />
              <Tooltip />
              <Bar dataKey="count" name="Members" fill="#7c3aed" radius={[0,4,4,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Gender Pie */}
        <div className="card chart-section">
          <h3>Gender Distribution</h3>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={gender} dataKey="count" nameKey="gender" cx="50%" cy="50%" outerRadius={90}
                label={({ gender: g, percent }) => `${g} (${(percent * 100).toFixed(0)}%)`} labelLine>
                {gender.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Interests Bar */}
        <div className="card chart-section" style={{ gridColumn: '1 / -1' }}>
          <h3>Top Interests</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={interests.filter(i => i.count > 0)} margin={{ left: -10 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} interval={0} angle={-25} textAnchor="end" height={60} />
              <YAxis allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" name="Members" fill="#16a34a" radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Registrations per month line chart */}
        {monthly.length > 0 && (
          <div className="card chart-section" style={{ gridColumn: '1 / -1' }}>
            <h3>Registrations Per Month</h3>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={monthly} margin={{ left: -10 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Line type="monotone" dataKey="count" name="Registrations" stroke="#2563eb" strokeWidth={2} dot={{ r: 5 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>
    </main>
  );
}
