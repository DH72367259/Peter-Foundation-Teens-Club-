import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  getRecordsKidsList, getRecordsMentorsList,
  getKidRecord, getMentorRecord, getGroupOverview,
} from '../api';
import { useAuth } from '../AuthContext';

// ─── helpers ─────────────────────────────────────────────────────────────────
const PCT_COLOR = (pct: number) =>
  pct >= 80 ? '#16a34a' : pct >= 50 ? '#d97706' : '#dc2626';

const PAGE_SIZE = 10;
function usePagination<T>(items: T[], pageKey: string) {
  const [page, setPage] = useState(1);
  const totalPages = Math.ceil(items.length / PAGE_SIZE);
  const current    = Math.min(page, Math.max(1, totalPages));
  const slice      = items.slice((current - 1) * PAGE_SIZE, current * PAGE_SIZE);
  const Pager = () => totalPages <= 1 ? null : (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 12 }}>
      <button className="btn btn-outline btn-sm" disabled={current === 1} onClick={() => setPage(p => p - 1)}>← Prev</button>
      <span style={{ fontSize: 13, color: 'var(--muted)' }}>Page {current} of {totalPages}</span>
      <button className="btn btn-outline btn-sm" disabled={current === totalPages} onClick={() => setPage(p => p + 1)}>Next →</button>
    </div>
  );
  // reset to page 1 when key changes (different kid/mentor selected)
  useEffect(() => { setPage(1); }, [pageKey]);
  return { slice, Pager };
}

function StatCard({ label, value, sub = '', color = '#1d4ed8' }: { label: string; value: string | number; sub?: string; color?: string }) {
  return (
    <div style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: '14px 18px', minWidth: 110, textAlign: 'center' }}>
      <div style={{ fontSize: 24, fontWeight: 800, color }}>{value}</div>
      <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--muted)', marginTop: 2 }}>{label}</div>
      {sub && <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 2 }}>{sub}</div>}
    </div>
  );
}

function MonthlyTable({ monthly }: { monthly: Record<string, { total: number; present: number }> }) {
  const months = Object.keys(monthly).sort().reverse();
  if (months.length === 0) return null;
  return (
    <div className="table-wrap" style={{ marginTop: 8 }}>
      <table>
        <thead>
          <tr><th>Month</th><th>Sessions</th><th>Attended</th><th>Missed</th><th>Rate</th></tr>
        </thead>
        <tbody>
          {months.map(m => {
            const { total, present } = monthly[m];
            const pct = total > 0 ? Math.round((present / total) * 100) : 0;
            return (
              <tr key={m}>
                <td>{m}</td>
                <td>{total}</td>
                <td style={{ color: '#16a34a', fontWeight: 600 }}>{present}</td>
                <td style={{ color: '#dc2626' }}>{total - present}</td>
                <td>
                  <span style={{ fontWeight: 700, color: PCT_COLOR(pct) }}>{pct}%</span>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// ─── Kid Record view ─────────────────────────────────────────────────────────
function KidRecordView({ kidId, showFull }: { kidId: string; showFull: boolean }) {
  const navigate = useNavigate();
  const [data, setData]       = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [section, setSection] = useState<'overview' | 'spiritual' | 'mentor' | 'slnotes'>('overview');

  useEffect(() => {
    setLoading(true);
    getKidRecord(kidId).then(setData).finally(() => setLoading(false));
  }, [kidId]);

  const { slice: spirSlice, Pager: SpiritualPager } = usePagination(
    data ? data.spiritualSessions.filter((s: any) => !s.is_cancelled) : [],
    `kid-spir-${kidId}`
  );
  const { slice: noteSlice, Pager: NotesPager } = usePagination(
    data ? data.mentorNotes : [],
    `kid-notes-${kidId}`
  );
  const { slice: slSlice, Pager: SLPager } = usePagination(
    data ? data.slNotes : [],
    `kid-sl-${kidId}`
  );

  if (loading) return <p style={{ color: 'var(--muted)', padding: 16 }}>Loading records…</p>;
  if (!data)   return <p style={{ color: '#dc2626', padding: 16 }}>No data found.</p>;

  const { kid, parents, hobbies, interests, mentors, mentorNotes, spiritualSessions, slNotes, spiritualStats } = data;
  const sl_sessions  = spiritualSessions.filter((s: any) => !s.is_cancelled);
  const TYPE_LABEL: Record<string, string> = { GROUP: 'Group', SMALL_GROUP: 'Small Group', ONE_ON_ONE_KID: '1:1', ALL_MENTORS: 'Mentor Mtg' };
  return (
    <div>
      {/* Sub-tabs */}
      <div className="tabs" style={{ marginBottom: 16 }}>
        <button className={`tab-btn ${section === 'overview'  ? 'active' : ''}`} onClick={() => setSection('overview')}>Overview</button>
        <button className={`tab-btn ${section === 'spiritual' ? 'active' : ''}`} onClick={() => setSection('spiritual')}>
          Spiritual ({sl_sessions.length} sessions)
        </button>
        {showFull && (
          <button className={`tab-btn ${section === 'mentor' ? 'active' : ''}`} onClick={() => setSection('mentor')}>
            Mentor Notes ({mentorNotes.length})
          </button>
        )}
        <button className={`tab-btn ${section === 'slnotes' ? 'active' : ''}`} onClick={() => setSection('slnotes')}>
          SL Notes ({slNotes.length})
        </button>
      </div>

      {/* OVERVIEW */}
      {section === 'overview' && (
        <div>
          {/* Stats row */}
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 20 }}>
            <StatCard label="Total Sessions" value={spiritualStats.total} color="#1d4ed8" />
            <StatCard label="Attended" value={spiritualStats.present} color="#16a34a" />
            <StatCard label="Missed" value={spiritualStats.absent} color="#dc2626" />
            <StatCard label="Attendance Rate" value={`${spiritualStats.pct}%`} color={PCT_COLOR(spiritualStats.pct)} />
            <StatCard label="SL Notes" value={slNotes.length} color="#7c3aed" />
            {showFull && <StatCard label="Mentor Notes" value={mentorNotes.length} color="#0369a1" />}
          </div>

          {/* Monthly attendance */}
          {Object.keys(spiritualStats.monthly).length > 0 && (
            <div className="card" style={{ marginBottom: 16 }}>
              <div className="card-title">Monthly Attendance Breakdown</div>
              <MonthlyTable monthly={spiritualStats.monthly} />
            </div>
          )}

          {/* Kid profile (admin/SL only) */}
          {showFull && (
            <div className="card" style={{ marginBottom: 16 }}>
              <div className="card-title">Profile</div>
              <div className="form-grid" style={{ fontSize: 13 }}>
                <div><span style={{ color: 'var(--muted)' }}>Name</span><br /><strong>{kid.first_name} {kid.last_name}</strong></div>
                <div><span style={{ color: 'var(--muted)' }}>Reg ID</span><br /><strong>{kid.registration_id}</strong></div>
                <div><span style={{ color: 'var(--muted)' }}>DOB</span><br />{kid.dob}</div>
                <div><span style={{ color: 'var(--muted)' }}>Gender</span><br />{kid.gender || '—'}</div>
                <div><span style={{ color: 'var(--muted)' }}>Education</span><br />{kid.education_level || '—'}</div>
                <div><span style={{ color: 'var(--muted)' }}>School</span><br />{kid.school_name || '—'}</div>
                <div><span style={{ color: 'var(--muted)' }}>Phone</span><br />{kid.phone_normalized || '—'}</div>
                <div><span style={{ color: 'var(--muted)' }}>Baptism</span><br />{kid.baptism_confirmed ? '✅ Yes' : '—'}</div>
                {hobbies.length > 0 && <div className="form-full"><span style={{ color: 'var(--muted)' }}>Hobbies</span><br />{hobbies.join(', ')}</div>}
                {interests.length > 0 && <div className="form-full"><span style={{ color: 'var(--muted)' }}>Interests</span><br />{interests.join(', ')}</div>}
              </div>
              <div className="btn-row" style={{ marginTop: 12 }}>
                <button className="btn btn-primary btn-sm" onClick={() => navigate(`/kid/${kid.kid_id}`)}>View Full Profile →</button>
              </div>
            </div>
          )}

          {/* Parents */}
          {showFull && parents.length > 0 && (
            <div className="card" style={{ marginBottom: 16 }}>
              <div className="card-title">Parents / Guardians</div>
              {parents.map((p: any, i: number) => (
                <div key={i} style={{ marginBottom: 8, fontSize: 13, borderBottom: i < parents.length - 1 ? '1px solid var(--border)' : 'none', paddingBottom: 8 }}>
                  <strong>{p.full_name}</strong> <span style={{ color: 'var(--muted)' }}>({p.relationship})</span>
                  {p.phone_normalized && <> · {p.phone_normalized}</>}
                  {p.email && <> · {p.email}</>}
                </div>
              ))}
            </div>
          )}

          {/* Assigned mentors */}
          {showFull && mentors.length > 0 && (
            <div className="card" style={{ marginBottom: 16 }}>
              <div className="card-title">Assigned Mentors</div>
              {mentors.map((m: any) => (
                <div key={m.user_id} style={{ fontSize: 13, marginBottom: 6 }}>
                  <strong>{m.full_name}</strong> <span style={{ color: 'var(--muted)' }}>(@{m.username})</span>
                  <span style={{ fontSize: 11, color: 'var(--muted)', marginLeft: 8 }}>Since {m.assigned_at?.slice(0, 10)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SPIRITUAL SESSIONS */}
      {section === 'spiritual' && (
        <div className="card">
          {sl_sessions.length === 0
            ? <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '24px 0' }}>No spiritual session records.</p>
            : (
              <>
                <div className="table-wrap">
                  <table>
                    <thead>
                      <tr><th>Date</th><th>Topic</th><th>Type</th><th>Status</th><th>SL</th></tr>
                    </thead>
                    <tbody>
                      {spirSlice.map((s: any) => (
                        <tr key={s.session_id}>
                          <td><strong>{s.session_date}</strong></td>
                          <td style={{ maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            <span style={{ cursor: 'pointer', color: 'var(--primary)', textDecoration: 'underline' }}
                              onClick={() => navigate(`/spiritual/session/${s.session_id}`)}>
                              {s.topic}
                            </span>
                          </td>
                          <td><span style={{ fontSize: 11, padding: '1px 7px', borderRadius: 10, background: '#e0f2fe', color: '#0369a1', fontWeight: 600 }}>{TYPE_LABEL[s.session_type] || s.session_type}</span></td>
                          <td>
                            {s.is_present
                              ? <span style={{ color: '#16a34a', fontWeight: 700 }}>✅ Present</span>
                              : <span style={{ color: '#dc2626', fontWeight: 700 }}>❌ Absent</span>}
                          </td>
                          <td style={{ fontSize: 12, color: 'var(--muted)' }}>{s.sl_name || '—'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <SpiritualPager />
              </>
            )}
        </div>
      )}

      {/* MENTOR NOTES */}
      {section === 'mentor' && showFull && (
        <div>
          {mentorNotes.length === 0
            ? <div className="card"><p style={{ color: 'var(--muted)', textAlign: 'center', padding: '24px 0' }}>No mentor notes recorded.</p></div>
            : <>
                {noteSlice.map((n: any) => (
                  <div key={n.note_id} className="card" style={{ marginBottom: 12 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8, marginBottom: 8 }}>
                      <span style={{ fontWeight: 700, fontSize: 14 }}>{n.session_date}</span>
                      <span style={{ fontSize: 12, color: 'var(--muted)' }}>by {n.mentor_name}</span>
                      {n.is_signed
                        ? <span style={{ fontSize: 11, padding: '1px 8px', borderRadius: 10, background: '#1d4ed8', color: '#fff', fontWeight: 700 }}>Signed</span>
                        : <span style={{ fontSize: 11, padding: '1px 8px', borderRadius: 10, background: '#d97706', color: '#fff', fontWeight: 700 }}>Draft</span>}
                    </div>
                    {n.discussion  && <p style={{ fontSize: 13, marginBottom: 4 }}><strong>Discussion:</strong> {n.discussion}</p>}
                    {n.outcome     && <p style={{ fontSize: 13, marginBottom: 4 }}><strong>Outcome:</strong> {n.outcome}</p>}
                    {n.next_steps  && <p style={{ fontSize: 13 }}><strong>Next Steps:</strong> {n.next_steps}</p>}
                  </div>
                ))}
                <NotesPager />
              </>
          }
        </div>
      )}

      {/* SL NOTES */}
      {section === 'slnotes' && (
        <div>
          {slNotes.length === 0
            ? <div className="card"><p style={{ color: 'var(--muted)', textAlign: 'center', padding: '24px 0' }}>No SL notes recorded for this teen.</p></div>
            : <>
                {slSlice.map((n: any) => (
                  <div key={n.note_id} className="card" style={{ marginBottom: 12 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8, marginBottom: 8 }}>
                      <span style={{ fontWeight: 700, fontSize: 14 }}>{n.session_date} — {n.topic}</span>
                      <span style={{ fontSize: 12, color: 'var(--muted)' }}>by {n.sl_name}</span>
                    </div>
                    {n.content     && <p style={{ fontSize: 13, marginBottom: 4 }}><strong>Observation:</strong> {n.content}</p>}
                    {n.improvement && <p style={{ fontSize: 13, marginBottom: 4 }}><strong>Improvement:</strong> {n.improvement}</p>}
                    {n.suggestions && <p style={{ fontSize: 13 }}><strong>Suggestions:</strong> {n.suggestions}</p>}
                    <button className="btn btn-primary btn-sm" style={{ marginTop: 8 }} onClick={() => navigate(`/spiritual/session/${n.session_id}`)}>View Session</button>
                  </div>
                ))}
                <SLPager />
              </>
          }
        </div>
      )}
    </div>
  );
}

// ─── Mentor Record view ───────────────────────────────────────────────────────
function MentorRecordView({ mentorId }: { mentorId: string }) {
  const navigate = useNavigate();
  const [data, setData]       = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [section, setSection] = useState<'overview' | 'sessions' | 'kids'>('overview');

  useEffect(() => {
    setLoading(true);
    getMentorRecord(mentorId).then(setData).finally(() => setLoading(false));
  }, [mentorId]);

  const { slice: sessSlice, Pager: SessionPager } = usePagination(
    data ? data.sessions.filter((s: any) => !s.is_cancelled) : [],
    `mentor-sess-${mentorId}`
  );

  if (loading) return <p style={{ color: 'var(--muted)', padding: 16 }}>Loading…</p>;
  if (!data)   return <p style={{ color: '#dc2626', padding: 16 }}>No data found.</p>;

  const { mentor, sessions, kids, stats } = data;

  return (
    <div>
      <div className="tabs" style={{ marginBottom: 16 }}>
        <button className={`tab-btn ${section === 'overview'  ? 'active' : ''}`} onClick={() => setSection('overview')}>Overview</button>
        <button className={`tab-btn ${section === 'sessions'  ? 'active' : ''}`} onClick={() => setSection('sessions')}>Sessions ({sessions.filter((s: any) => !s.is_cancelled).length})</button>
        <button className={`tab-btn ${section === 'kids'      ? 'active' : ''}`} onClick={() => setSection('kids')}>Assigned Teens ({kids.length})</button>
      </div>

      {section === 'overview' && (
        <div>
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 20 }}>
            <StatCard label="Sessions Invited" value={stats.total} color="#1d4ed8" />
            <StatCard label="Attended" value={stats.present} color="#16a34a" />
            <StatCard label="Missed" value={stats.absent} color="#dc2626" />
            <StatCard label="Attendance Rate" value={`${stats.pct}%`} color={PCT_COLOR(stats.pct)} />
            <StatCard label="Teens Assigned" value={kids.length} color="#7c3aed" />
          </div>
          {Object.keys(stats.monthly).length > 0 && (
            <div className="card">
              <div className="card-title">Monthly Attendance Breakdown</div>
              <MonthlyTable monthly={stats.monthly} />
            </div>
          )}
        </div>
      )}

      {section === 'sessions' && (
        <div className="card">
          {sessions.filter((s: any) => !s.is_cancelled).length === 0
            ? <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '24px 0' }}>No session records.</p>
            : (
              <>
                <div className="table-wrap">
                  <table>
                    <thead><tr><th>Date</th><th>Topic</th><th>RSVP</th><th>Attended</th></tr></thead>
                    <tbody>
                      {sessSlice.map((s: any) => (
                        <tr key={s.session_id}>
                          <td><strong>{s.session_date}</strong></td>
                          <td style={{ maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            <span style={{ cursor: 'pointer', color: 'var(--primary)', textDecoration: 'underline' }}
                              onClick={() => navigate(`/spiritual/session/${s.session_id}`)}>
                              {s.topic}
                            </span>
                          </td>
                          <td>
                            <span style={{ fontSize: 11, padding: '1px 7px', borderRadius: 8, fontWeight: 600,
                              background: s.rsvp_status === 'ACCEPTED' ? '#dcfce7' : s.rsvp_status === 'DECLINED' ? '#fee2e2' : '#fef3c7',
                              color: s.rsvp_status === 'ACCEPTED' ? '#166534' : s.rsvp_status === 'DECLINED' ? '#991b1b' : '#92400e',
                            }}>{s.rsvp_status}</span>
                          </td>
                          <td>{s.is_present ? <span style={{ color: '#16a34a', fontWeight: 700 }}>✅</span> : <span style={{ color: '#dc2626' }}>❌</span>}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <SessionPager />
              </>
            )}
        </div>
      )}

      {section === 'kids' && (
        <div className="card">
          {kids.length === 0
            ? <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '24px 0' }}>No teens assigned.</p>
            : (
              <div className="table-wrap">
                <table>
                  <thead><tr><th>Name</th><th>Reg ID</th><th>Since</th><th>Notes</th><th></th></tr></thead>
                  <tbody>
                    {kids.map((k: any) => (
                      <tr key={k.kid_id}>
                        <td><strong>{k.first_name} {k.last_name}</strong></td>
                        <td>{k.registration_id}</td>
                        <td style={{ fontSize: 12, color: 'var(--muted)' }}>{k.assigned_at?.slice(0, 10)}</td>
                        <td>{k.note_count ?? 0}</td>
                        <td><button className="btn btn-primary btn-sm" onClick={() => navigate(`/kid/${k.kid_id}`)}>Profile</button></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
        </div>
      )}
    </div>
  );
}

// ─── Group Overview ───────────────────────────────────────────────────────────
function GroupOverview() {
  const navigate = useNavigate();
  const [data, setData]       = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getGroupOverview().then(setData).finally(() => setLoading(false));
  }, []);

  const { slice: sessSlice, Pager: SessionPager } = usePagination(
    data ? data.sessions : [],
    'group-overview'
  );

  if (loading) return <p style={{ color: 'var(--muted)', padding: 16 }}>Loading…</p>;
  if (!data)   return null;

  const { sessions, kidStats } = data;

  return (
    <div>
      <div className="card" style={{ marginBottom: 16 }}>
        <div className="card-title">Group Sessions</div>
        {sessions.length === 0
          ? <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '24px 0' }}>No group sessions recorded.</p>
          : (
            <>
              <div className="table-wrap">
                <table>
                  <thead><tr><th>Date</th><th>Topic</th><th>Type</th><th>Present</th><th>Total</th><th>Rate</th></tr></thead>
                  <tbody>
                    {sessSlice.map((s: any) => {
                      const pct = s.total > 0 ? Math.round((s.present / s.total) * 100) : 0;
                      return (
                        <tr key={s.session_id}>
                          <td><strong>{s.session_date}</strong></td>
                          <td style={{ maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            <span style={{ cursor: 'pointer', color: 'var(--primary)', textDecoration: 'underline' }}
                              onClick={() => navigate(`/spiritual/session/${s.session_id}`)}>
                              {s.topic}
                            </span>
                          </td>
                          <td><span style={{ fontSize: 11, padding: '1px 7px', borderRadius: 8, background: '#e0f2fe', color: '#0369a1', fontWeight: 600 }}>{s.session_type === 'SMALL_GROUP' ? 'Small Group' : 'Group'}</span></td>
                          <td style={{ color: '#16a34a', fontWeight: 600 }}>{s.present}</td>
                          <td>{s.total}</td>
                          <td><span style={{ fontWeight: 700, color: PCT_COLOR(pct) }}>{pct}%</span></td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              <SessionPager />
            </>
          )}
      </div>

      {kidStats.length > 0 && (
        <div className="card">
          <div className="card-title">Teen Overall Attendance (Group Sessions)</div>
          <div className="table-wrap">
            <table>
              <thead><tr><th>Name</th><th>Reg ID</th><th>Sessions</th><th>Attended</th><th>Missed</th><th>Rate</th></tr></thead>
              <tbody>
                {kidStats.map((k: any) => {
                  const pct = k.total_sessions > 0 ? Math.round((k.sessions_present / k.total_sessions) * 100) : 0;
                  return (
                    <tr key={k.kid_id}>
                      <td><strong>{k.first_name} {k.last_name}</strong></td>
                      <td>{k.registration_id}</td>
                      <td>{k.total_sessions}</td>
                      <td style={{ color: '#16a34a', fontWeight: 600 }}>{k.sessions_present}</td>
                      <td style={{ color: '#dc2626' }}>{k.total_sessions - k.sessions_present}</td>
                      <td><span style={{ fontWeight: 700, color: PCT_COLOR(pct) }}>{pct}%</span></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// MAIN RECORDS PAGE
// ════════════════════════════════════════════════════════════════════════════
export default function RecordsPage() {
  const navigate = useNavigate();
  const { isAdmin, isSpiritualLeader, isMentor } = useAuth();

  const canSeeMentor = isAdmin || isSpiritualLeader;
  const canSeeGroup  = isAdmin || isSpiritualLeader;
  const showFullKid  = isAdmin || isSpiritualLeader;

  type ViewType = 'kid' | 'mentor' | 'group';
  const [viewType, setViewType] = useState<ViewType>('kid');
  const [kidsList, setKidsList]       = useState<any[]>([]);
  const [mentorsList, setMentorsList] = useState<any[]>([]);
  const [selectedKid, setSelectedKid]       = useState('');
  const [selectedMentor, setSelectedMentor] = useState('');

  useEffect(() => {
    getRecordsKidsList().then(setKidsList).catch(() => {});
    if (canSeeMentor) getRecordsMentorsList().then(setMentorsList).catch(() => {});
  }, []);

  const title = isAdmin ? 'Records & Data Centre'
    : isSpiritualLeader ? 'Records & Session Data'
    : 'My Kids\' Records';

  return (
    <main className="page">
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 20 }}>
        <button className="btn btn-outline btn-sm" onClick={() => navigate('/')}>← Home</button>
        <h2 style={{ fontSize: 22, fontWeight: 700 }}>📊 {title}</h2>
      </div>

      {/* Entity type selector */}
      <div className="card" style={{ marginBottom: 20, padding: '16px 20px' }}>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
          {/* View type tabs */}
          <div className="tabs" style={{ marginBottom: 0 }}>
            <button className={`tab-btn ${viewType === 'kid' ? 'active' : ''}`} onClick={() => { setViewType('kid'); setSelectedKid(''); }}>
              👤 Teen
            </button>
            {canSeeMentor && (
              <button className={`tab-btn ${viewType === 'mentor' ? 'active' : ''}`} onClick={() => { setViewType('mentor'); setSelectedMentor(''); }}>
                🧑‍🏫 Mentor
              </button>
            )}
            {canSeeGroup && (
              <button className={`tab-btn ${viewType === 'group' ? 'active' : ''}`} onClick={() => setViewType('group')}>
                👥 Group Overview
              </button>
            )}
          </div>

          {/* Dropdown */}
          {viewType === 'kid' && (
            <select value={selectedKid} onChange={e => setSelectedKid(e.target.value)}
              style={{ fontSize: 14, minWidth: 260 }}>
              <option value="">— Select a teen —</option>
              {kidsList.map(k => (
                <option key={k.kid_id} value={k.kid_id}>
                  {k.first_name} {k.last_name} ({k.registration_id})
                </option>
              ))}
            </select>
          )}
          {viewType === 'mentor' && canSeeMentor && (
            <select value={selectedMentor} onChange={e => setSelectedMentor(e.target.value)}
              style={{ fontSize: 14, minWidth: 220 }}>
              <option value="">— Select a mentor —</option>
              {mentorsList.map(m => (
                <option key={m.user_id} value={m.user_id}>
                  {m.full_name} (@{m.username})
                </option>
              ))}
            </select>
          )}
        </div>
      </div>

      {/* Content area */}
      {viewType === 'kid' && selectedKid && (
        <KidRecordView kidId={selectedKid} showFull={showFullKid} />
      )}
      {viewType === 'kid' && !selectedKid && (
        <div className="card"><p style={{ color: 'var(--muted)', textAlign: 'center', padding: '32px 0' }}>Select a teen above to view their full record.</p></div>
      )}

      {viewType === 'mentor' && canSeeMentor && selectedMentor && (
        <MentorRecordView mentorId={selectedMentor} />
      )}
      {viewType === 'mentor' && canSeeMentor && !selectedMentor && (
        <div className="card"><p style={{ color: 'var(--muted)', textAlign: 'center', padding: '32px 0' }}>Select a mentor above to view their record.</p></div>
      )}

      {viewType === 'group' && canSeeGroup && <GroupOverview />}
    </main>
  );
}
