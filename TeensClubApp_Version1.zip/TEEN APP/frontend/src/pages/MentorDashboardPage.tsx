import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getMyKids, getMyMentorEdits, createEditRequest, submitKidForApproval, submitAllDrafts, getNotifications, markNotificationRead } from '../api';
import { useAuth } from '../AuthContext';

export default function MentorDashboardPage() {
  const navigate  = useNavigate();
  const { user }  = useAuth();

  // Assigned kids list
  const [kids, setKids]       = useState<any[]>([]);
  const [loadingKids, setLoadingKids] = useState(true);
  const [search, setSearch]   = useState('');

  // My edit submissions (records I was granted access to edit)
  const [editKids, setEditKids]     = useState<any[]>([]);
  const [loadingEdits, setLoadingEdits] = useState(true);
  const [submitting, setSubmitting] = useState<string | null>(null);
  const [submitAllBusy, setSubmitAllBusy] = useState(false);

  // Multi-select for bulk edit request
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [requestReason, setRequestReason] = useState('');
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [requestSaving, setRequestSaving] = useState(false);
  const [msg, setMsg]   = useState('');
  const [error, setError] = useState('');

  // Notifications
  const [notifications, setNotifications] = useState<any[]>([]);
  const loadNotifications = () => getNotifications().then(setNotifications).catch(() => {});



  const dismissNotification = async (id: string) => {
    await markNotificationRead(id).catch(() => {});
    setNotifications(ns => ns.map(n => n.notification_id === id ? { ...n, is_read: 1 } : n));
  };

  const loadKids  = () => { setLoadingKids(true);  getMyKids().then(setKids).finally(() => setLoadingKids(false)); };
  const loadEdits = () => { setLoadingEdits(true); getMyMentorEdits().then(setEditKids).finally(() => setLoadingEdits(false)); };

  useEffect(() => {
    loadKids(); loadEdits(); loadNotifications();
    const iv = setInterval(() => { loadNotifications(); loadEdits(); }, 30000);
    window.addEventListener('tc-refresh-counts', loadNotifications);
    return () => { clearInterval(iv); window.removeEventListener('tc-refresh-counts', loadNotifications); };
  }, []);

  const filtered = kids.filter((k: any) => {
    const q = search.toLowerCase();
    return !q || (k.first_name + ' ' + k.last_name).toLowerCase().includes(q)
      || k.registration_id?.toLowerCase().includes(q) || k.phone_normalized?.includes(q);
  });

  // Selection helpers
  const toggleOne = (id: string) => setSelectedIds(s => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const allChecked = filtered.length > 0 && filtered.every(k => selectedIds.has(k.kid_id));
  const toggleAll  = () => setSelectedIds(allChecked ? new Set() : new Set(filtered.map(k => k.kid_id)));

  const handleBulkEditRequest = async () => {
    if (selectedIds.size === 0 || !requestReason.trim()) return;
    setRequestSaving(true); setError('');
    let done = 0;
    for (const kid_id of selectedIds) {
      const kid = kids.find(k => k.kid_id === kid_id);
      try {
        await createEditRequest({
          entity_type: 'KID',
          entity_id: kid_id,
          entity_label: kid ? kid.first_name + ' ' + kid.last_name + ' (' + kid.registration_id + ')' : kid_id,
          reason: requestReason.trim(),
        });
        done++;
      } catch (_) {}
    }
    setMsg('Edit access requested for ' + done + ' record(s). Admin will review shortly.');
    setShowRequestModal(false); setRequestReason(''); setSelectedIds(new Set());
    setRequestSaving(false);
  };

  const handleRowSubmit = async (kid_id: string) => {
    setSubmitting(kid_id);
    try { await submitKidForApproval(kid_id); loadEdits(); }
    catch (e: any) { alert(e.response?.data?.error || 'Submission failed'); }
    finally { setSubmitting(null); }
  };

  const handleSubmitAll = async () => {
    const draftCount = editKids.filter(k => k.submission_status === 'DRAFT').length;
    if (draftCount === 0) { alert('No draft edits to submit.'); return; }
    if (!confirm('Submit all ' + draftCount + ' edited record(s) for admin re-approval?')) return;
    setSubmitAllBusy(true);
    try { const r = await submitAllDrafts(); alert(r.message || 'All submitted!'); loadEdits(); }
    catch (e: any) { alert(e.response?.data?.error || 'Submit all failed'); }
    finally { setSubmitAllBusy(false); }
  };

  const subBadge = (status: string) => {
    const cfg: Record<string, { bg: string; color: string }> = {
      DRAFT:    { bg: '#e2e3e5', color: '#383d41' },
      PENDING:  { bg: '#fff3cd', color: '#856404' },
      APPROVED: { bg: '#d1e7dd', color: '#0a3622' },
      DENIED:   { bg: '#f8d7da', color: '#721c24' },
    };
    const s = cfg[status] || cfg.DRAFT;
    return <span style={{ padding: '2px 8px', borderRadius: 10, fontSize: 11, fontWeight: 700, background: s.bg, color: s.color }}>{status}</span>;
  };

  return (
    <main className="page">
      {/* header — no back button */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 20 }}>
        <h2 style={{ fontSize: 22, fontWeight: 700 }}>👤 My Assigned Teens</h2>
        <span style={{ fontSize: 13, color: 'var(--muted)', marginLeft: 'auto' }}>Mentor: <strong>{user?.full_name}</strong></span>
      </div>

      {msg   && <div className="alert alert-success" style={{ marginBottom: 16 }}>{msg}</div>}
      {error && <div className="alert alert-error"   style={{ marginBottom: 16 }}>{error}</div>}

      {/* Session invites and requests are now in the Sessions tab (📅 My Sessions) */}
      {/* Only show dashboard-relevant notifications: edit approvals & submission approvals */}
      {notifications.filter(n => !n.is_read && (n.type === 'EDIT_REQUEST_APPROVED' || n.type === 'EDIT_SUBMISSION_APPROVED')).map((n: any) => (
        <div key={n.notification_id} style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start',
          gap: 12, marginBottom: 8, padding: '10px 14px', borderRadius: 8,
          background: n.type === 'EDIT_REQUEST_APPROVED' ? '#d1e7dd' : '#cce5ff',
          border: n.type === 'EDIT_REQUEST_APPROVED' ? '1px solid #badbcc' : '1px solid #b8daff',
          color: n.type === 'EDIT_REQUEST_APPROVED' ? '#0a3622' : '#004085',
          fontSize: 13,
        }}>
          <span style={{ flex: 1 }}>{n.message}</span>
          <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
            {n.entity_id && n.type === 'EDIT_REQUEST_APPROVED' && (
              <button className="btn btn-sm" style={{ fontSize: 12, padding: '2px 10px', background: '#0a3622', color: '#fff', border: 'none', borderRadius: 5, cursor: 'pointer' }}
                onClick={() => { dismissNotification(n.notification_id); navigate('/register/' + n.entity_id); }}>
                ✏️ Edit Now
              </button>
            )}
            {n.entity_id && n.type === 'EDIT_SUBMISSION_APPROVED' && (
              <button className="btn btn-sm" style={{ fontSize: 12, padding: '2px 10px', background: '#004085', color: '#fff', border: 'none', borderRadius: 5, cursor: 'pointer' }}
                onClick={() => { dismissNotification(n.notification_id); navigate('/kid/' + n.entity_id); }}>
                👁 View
              </button>
            )}
            <button style={{ background: 'none', border: 'none', cursor: 'pointer', fontWeight: 700, fontSize: 16, color: 'inherit', lineHeight: 1 }}
              onClick={() => dismissNotification(n.notification_id)}>&#x2715;</button>
          </div>
        </div>
      ))}

      {/* ── Edit Submissions section ── */}
      {(loadingEdits || editKids.length > 0) && (
        <div className="card" style={{ marginBottom: 24 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <div className="card-title" style={{ marginBottom: 0 }}>\u270F️ My Edit Submissions</div>
            {editKids.filter(k => k.submission_status === 'DRAFT').length > 0 && (
              <button className="btn btn-primary btn-sm" onClick={handleSubmitAll} disabled={submitAllBusy} style={{ background: '#0d6efd' }}>
                {submitAllBusy ? 'Submitting…' : '📤 Submit All Fixed (' + editKids.filter(k => k.submission_status === 'DRAFT').length + ')'}
              </button>
            )}
          </div>
          {loadingEdits ? <p style={{ color: 'var(--muted)' }}>Loading…</p> : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {editKids.map((k: any) => (
                <div key={k.kid_id} style={{
                  padding: '12px 14px', borderRadius: 8,
                  border: k.submission_status === 'DENIED' ? '1px solid #f5c6cb' : '1px solid #dee2e6',
                  background: k.submission_status === 'DENIED' ? '#fff8f8' : '#fff'
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
                    <div>
                      <strong>{k.first_name} {k.last_name}</strong>
                      <span style={{ marginLeft: 8, fontFamily: 'monospace', fontSize: 12, color: 'var(--muted)' }}>{k.registration_id}</span>
                      <span style={{ marginLeft: 8 }}>{subBadge(k.submission_status)}</span>
                    </div>
                    <div style={{ display: 'flex', gap: 6 }}>
                      {k.submission_status !== 'PENDING' && (
                        <button className="btn btn-outline btn-sm" onClick={() => navigate('/register/' + k.kid_id)}>
                          {k.submission_status === 'DENIED' ? '\u270F️ Fix & Re-edit' : '\u270F️ Edit'}
                        </button>
                      )}
                      {k.submission_status === 'DRAFT' && (
                        <button className="btn btn-primary btn-sm" onClick={() => handleRowSubmit(k.kid_id)}
                          disabled={submitting === k.kid_id} style={{ background: '#0d6efd' }}>
                          {submitting === k.kid_id ? '…' : '📤 Submit'}
                        </button>
                      )}
                      {k.submission_status === 'PENDING' && (
                        <span style={{ fontSize: 12, color: 'var(--muted)', padding: '2px 8px' }}>\u23F3 Awaiting admin approval</span>
                      )}
                    </div>
                  </div>
                  {k.submission_status === 'DENIED' && k.submission_note && (
                    <div style={{ marginTop: 8, padding: '8px 10px', background: '#f8d7da', borderRadius: 6, fontSize: 13, borderLeft: '3px solid #dc3545' }}>
                      <strong>\u26A0️ Admin requested changes:</strong> {k.submission_note}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── Assigned Teens + bulk edit request ── */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 12, flexWrap: 'wrap', alignItems: 'center' }}>
        <input value={search} onChange={e => setSearch(e.target.value)}
          placeholder="Search by name, Reg ID or phone..." style={{ flex: 1, minWidth: 200, maxWidth: 400 }} />
        {selectedIds.size > 0 && (
          <button className="btn btn-sm" style={{ background: '#6f42c1', color: '#fff', border: 'none' }}
            onClick={() => { setShowRequestModal(true); setError(''); }}>
            📩 Request Edit for Selected ({selectedIds.size})
          </button>
        )}
        <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, cursor: 'pointer' }}>
          <input type="checkbox" checked={allChecked} onChange={toggleAll} />
          {allChecked ? 'Deselect All' : 'Select All Visible'}
        </label>
      </div>

      {loadingKids ? <div className="card"><p style={{ color: 'var(--muted)', padding: '24px 0', textAlign: 'center' }}>Loading…</p></div>
        : filtered.length === 0 ? (
          <div className="card">
            <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '32px 0' }}>
              {kids.length === 0 ? 'No teens assigned to you yet.' : 'No results match your search.'}
            </p>
          </div>
        ) : (
          <div className="card">
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th style={{ width: 32 }}><input type="checkbox" checked={allChecked} onChange={toggleAll} /></th>
                    <th>Reg ID</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Education</th>
                    <th>Gender</th>
                    <th>Phone</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((k: any) => (
                    <tr key={k.kid_id} style={{ background: selectedIds.has(k.kid_id) ? '#f0f6ff' : undefined }}>
                      <td><input type="checkbox" checked={selectedIds.has(k.kid_id)} onChange={() => toggleOne(k.kid_id)} /></td>
                      <td><code style={{ fontSize: 12 }}>{k.registration_id}</code></td>
                      <td>
                        <span style={{ cursor: 'pointer', color: 'var(--primary)', fontWeight: 600 }} onClick={() => navigate('/kid/' + k.kid_id)}>
                          {k.first_name} {k.last_name}
                        </span>
                      </td>
                      <td>{k.age_snapshot}</td>
                      <td>{k.education_level || '—'}</td>
                      <td>{k.gender || '—'}</td>
                      <td>{k.phone_normalized || '—'}</td>
                      <td style={{ display: 'flex', gap: 6 }}>
                        <button className="btn btn-outline btn-sm" onClick={() => navigate('/kid/' + k.kid_id)}>View</button>
                        <button className="btn btn-primary btn-sm" onClick={() => navigate('/notes/' + k.kid_id)}>🗒 Notes</button>
                        <button className="btn btn-sm" style={{ background: '#6f42c1', color: '#fff', border: 'none', borderRadius: 6, padding: '3px 10px', fontSize: 12, cursor: 'pointer' }}
                          onClick={() => { setSelectedIds(new Set([k.kid_id])); setShowRequestModal(true); setError(''); }}>
                          📩 Request Edit
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div style={{ textAlign: 'right', fontSize: 12, color: 'var(--muted)', marginTop: 8 }}>
              {filtered.length} of {kids.length} teens
            </div>
          </div>
        )
      }

      {/* Request Edit Modal */}
      {showRequestModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
          <div className="card" style={{ width: '100%', maxWidth: 500, margin: 0 }}>
            <div className="card-title">📩 Request Edit Access</div>
            <p style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 8 }}>
              Requesting edit access for <strong>{selectedIds.size}</strong> record(s).
              Admin will review and approve or deny.
            </p>
            <div className="field">
              <label className="required">Reason for Edit</label>
              <textarea rows={4} value={requestReason} onChange={e => setRequestReason(e.target.value)}
                placeholder="Describe what needs to be changed and why..." maxLength={500} />
              <span style={{ fontSize: 12, color: 'var(--muted)' }}>{requestReason.length}/500</span>
            </div>
            {error && <div className="alert alert-error" style={{ marginBottom: 8 }}>{error}</div>}
            <div className="btn-row">
              <button className="btn btn-outline btn-sm" onClick={() => { setShowRequestModal(false); setError(''); }}>Cancel</button>
              <button className="btn btn-primary btn-sm" style={{ background: '#6f42c1' }}
                onClick={handleBulkEditRequest} disabled={requestSaving || !requestReason.trim()}>
                {requestSaving ? 'Submitting…' : '📩 Submit Request'}
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
