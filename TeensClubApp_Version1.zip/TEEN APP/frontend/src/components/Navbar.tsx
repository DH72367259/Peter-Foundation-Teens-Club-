import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';

export default function Navbar() {
  const { user, logout, isAdmin, isMentor } = useAuth();
  const isSpiritualLeader = user?.role === 'SPIRITUAL_LEADER';
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  const roleBadgeClass = isAdmin ? 'badge-admin' : isMentor ? 'badge-mentor' : isSpiritualLeader ? 'badge-sl' : 'badge-sub';

  return (
    <nav className="navbar">
      <div className="navbar-brand" style={{ cursor: 'pointer' }} onClick={() => navigate('/')}>
        ✝️ Peter Foundation Teen's Club
      </div>
      <div className="navbar-right">
        <span className="navbar-user" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ maxWidth: 120, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {user?.full_name}
          </span>
          <span className={`badge ${roleBadgeClass}`}>
            {user?.role}
          </span>
        </span>
        <button className="btn-logout" onClick={logout}>Logout</button>
      </div>
    </nav>
  );
}

