import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './AuthContext';
import './styles.css';

import LoginPage from './pages/LoginPage';
import HomePage from './pages/HomePage';
import RegistrationPage from './pages/RegistrationPage';
import ExistingDataPage from './pages/ExistingDataPage';
import KidProfilePage from './pages/KidProfilePage';
import AnalyticsPage from './pages/AnalyticsPage';
import UsersPage from './pages/UsersPage';
import MentorsAdminPage from './pages/MentorsAdminPage';
import MentorDashboardPage from './pages/MentorDashboardPage';
import SessionNotesPage from './pages/SessionNotesPage';
import SpiritualLeaderPage from './pages/SpiritualLeaderPage';
import SpiritualSessionDetailPage from './pages/SpiritualSessionDetailPage';
import AdminEditRequestsPage from './pages/AdminEditRequestsPage';
import AdminSubmissionsPage from './pages/AdminSubmissionsPage';
import RecordsPage from './pages/RecordsPage';
import MentorSessionsPage from './pages/MentorSessionsPage';
import AttendancePage from './pages/AttendancePage';
import Navbar from './components/Navbar';
import TabBar from './components/TabBar';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

function AdminRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== 'ADMIN') return <Navigate to="/" replace />;
  return <>{children}</>;
}

function AnalyticsRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== 'ADMIN' && user.role !== 'SPIRITUAL_LEADER') return <Navigate to="/" replace />;
  return <>{children}</>;
}

function EditRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  // MENTOR can access /register/:id (edit existing), but RegistrationPage redirects them away from /register (new)
  // DATA_ENTRY and SUB can access both
  if (user.role === 'SPIRITUAL_LEADER') return <Navigate to="/" replace />;
  return <>{children}</>;
}

function MentorRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== 'MENTOR' && user.role !== 'ADMIN') return <Navigate to="/" replace />;
  return <>{children}</>;
}

function SpiritualRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  const allowed = ['ADMIN', 'SPIRITUAL_LEADER', 'MENTOR'];
  if (!allowed.includes(user.role)) return <Navigate to="/" replace />;
  return <>{children}</>;
}

// Blocks DATA_ENTRY and SUB from viewing existing approved records
function ViewOnlyRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role === 'DATA_ENTRY' || user.role === 'SUB') return <Navigate to="/" replace />;
  return <>{children}</>;
}

function AppRoutes() {
  const { user } = useAuth();
  return (
    <div className="app-shell">
      {user && <Navbar />}
      {user && <TabBar />}
      <Routes>
        <Route path="/login" element={user ? <Navigate to="/" /> : <LoginPage />} />
        <Route path="/" element={<ProtectedRoute><HomePage /></ProtectedRoute>} />
        <Route path="/register" element={<EditRoute><RegistrationPage /></EditRoute>} />
        <Route path="/register/:id" element={<EditRoute><RegistrationPage /></EditRoute>} />
        <Route path="/existing" element={<ViewOnlyRoute><ExistingDataPage /></ViewOnlyRoute>} />
        <Route path="/kid/:id" element={<ViewOnlyRoute><KidProfilePage /></ViewOnlyRoute>} />
        <Route path="/analytics" element={<AnalyticsRoute><AnalyticsPage /></AnalyticsRoute>} />
        <Route path="/users" element={<AdminRoute><UsersPage /></AdminRoute>} />
        <Route path="/mentors-admin" element={<AdminRoute><MentorsAdminPage /></AdminRoute>} />
        <Route path="/mentor-dashboard" element={<MentorRoute><MentorDashboardPage /></MentorRoute>} />
        <Route path="/mentor-sessions" element={<MentorRoute><MentorSessionsPage /></MentorRoute>} />
        <Route path="/notes/:kidId" element={<ProtectedRoute><SessionNotesPage /></ProtectedRoute>} />
        <Route path="/spiritual" element={<SpiritualRoute><SpiritualLeaderPage /></SpiritualRoute>} />
        <Route path="/spiritual/session/:id" element={<SpiritualRoute><SpiritualSessionDetailPage /></SpiritualRoute>} />
        <Route path="/admin/edit-requests" element={<AdminRoute><AdminEditRequestsPage /></AdminRoute>} />
        <Route path="/admin/submissions" element={<AdminRoute><AdminSubmissionsPage /></AdminRoute>} />
        <Route path="/records" element={<SpiritualRoute><RecordsPage /></SpiritualRoute>} />
        <Route path="/attendance" element={<AnalyticsRoute><AttendancePage /></AnalyticsRoute>} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}
