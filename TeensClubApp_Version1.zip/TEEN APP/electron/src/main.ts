import { app, BrowserWindow, shell, dialog } from 'electron';
import path from 'path';
import { spawn, ChildProcess } from 'child_process';
import os from 'os';

let mainWindow: BrowserWindow | null = null;
let backendProcess: ChildProcess | null = null;

const PORT = 3001;
const isDev = process.env.NODE_ENV === 'development';

// ─── Find local network IP ─────────────────────────────────────────────────
function getLocalIP(): string {
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]!) {
      if (net.family === 'IPv4' && !net.internal) return net.address;
    }
  }
  return 'localhost';
}

// ─── Start the Express backend ─────────────────────────────────────────────
function startBackend(): void {
  const backendDir = isDev
    ? path.join(__dirname, '..', '..', 'backend')
    : path.join(process.resourcesPath, 'backend');

  const nodeExe = process.execPath.replace('electron.exe', 'node.exe');
  const serverScript = path.join(backendDir, 'dist', 'server.js');

  backendProcess = spawn(
    isDev ? 'node' : nodeExe,
    [serverScript],
    {
      cwd: backendDir,
      env: {
        ...process.env,
        PORT: String(PORT),
        HOST: '0.0.0.0',
        DB_DIR: path.join(app.getPath('userData'), 'teensclub-data'),
        NODE_ENV: 'production',
      },
      stdio: ['ignore', 'pipe', 'pipe'],
    }
  );

  backendProcess.stdout?.on('data', (d: Buffer) => console.log('[Backend]', d.toString().trim()));
  backendProcess.stderr?.on('data', (d: Buffer) => console.error('[Backend ERR]', d.toString().trim()));
  backendProcess.on('error', err => console.error('[Backend start error]', err));
}

// ─── Wait for backend to be ready ─────────────────────────────────────────
function waitForBackend(url: string, retries = 30): Promise<void> {
  return new Promise((resolve, reject) => {
    let tries = 0;
    const check = () => {
      const { net } = require('electron');
      const req = net.request(url);
      req.on('response', () => resolve());
      req.on('error', () => {
        if (++tries >= retries) reject(new Error('Backend did not start'));
        else setTimeout(check, 1000);
      });
      req.end();
    };
    setTimeout(check, 1000);
  });
}

// ─── Create main window ────────────────────────────────────────────────────
async function createWindow(): Promise<void> {
  mainWindow = new BrowserWindow({
    width: 1280, height: 820,
    minWidth: 900, minHeight: 600,
    title: "Teen's Club Registration",
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    },
    show: false,
  });

  mainWindow.setMenuBarVisibility(false);

  const localIP = getLocalIP();
  const url = `http://localhost:${PORT}`;

  mainWindow.once('ready-to-show', () => {
    mainWindow!.show();
    // Show LAN info to the server operator
    dialog.showMessageBox(mainWindow!, {
      type: 'info',
      title: "Teen's Club — Server Running",
      message: "✅ Teen's Club Registration is running!\n\n" +
        `📺 This machine:  http://localhost:${PORT}\n` +
        `🌐 Other PCs on LAN: http://${localIP}:${PORT}\n\n` +
        `Share the LAN address with other users on the same network.\n` +
        `They can open it in any web browser.`,
      buttons: ['Got it!'],
    });
  });

  mainWindow.webContents.setWindowOpenHandler(({ url: u }) => {
    shell.openExternal(u);
    return { action: 'deny' };
  });

  try {
    await waitForBackend(`http://localhost:${PORT}/api/health`);
    mainWindow.loadURL(url);
  } catch {
    mainWindow.loadURL(`data:text/html,<h2>Backend failed to start. Check logs.</h2>`);
  }

  mainWindow.on('closed', () => { mainWindow = null; });
}

// ─── App lifecycle ─────────────────────────────────────────────────────────
app.whenReady().then(async () => {
  startBackend();
  await createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (backendProcess) { backendProcess.kill(); backendProcess = null; }
  if (process.platform !== 'darwin') app.quit();
});

app.on('before-quit', () => {
  if (backendProcess) { backendProcess.kill(); backendProcess = null; }
});
