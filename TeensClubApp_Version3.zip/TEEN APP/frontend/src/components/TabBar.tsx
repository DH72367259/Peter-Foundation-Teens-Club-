import { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import {
  getPendingRequestCount,
  getPendingSubmissionsCount,
  getMyDeniedCount,
  getMyMentorEditCount,
  getAgeOutNotificationCount,
} from '../api';

interface Tab {
  path: string;
  label: string;
  icon: string;
  badge?: number;
  matchPrefixes?: string[];
}

export default function TabBar() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const isAdmin          = user?.role === 'ADMIN';
  const isDataEntry      = user?.role === 'DATA_ENTRY' || user?.role === 'SUB';
  const isMentor         = user?.role === 'MENTOR';
  const isSpiritualLeader = user?.role === 'SPIRITUAL_LEADER';

  const [pendingRequests,    setPendingRequests]    = useState(0);
  const [pendingSubmissions, setPendingSubmissions] = useState(0);
  const [deniedCount,        setDeniedCount]        = useState(0);
  const [mentorDeniedCount,  setMentorDeniedCount]  = useState(0);
  const [ageOutCount,        setAgeOutCount]        = useState(0);

  useEffect(() => {
    const poll = () => {
      if (isAdmin) {
        getPendingRequestCount().then((d: any)    => setPendingRequests(d.count    || 0)).catch(() => {});
        getPendingSubmissionsCount().then((d: any) => setPendingSubmissions(d.count || 0)).catch(() => {});
        getAgeOutNotificationCount().then((d: any) => setAgeOutCount(d.count || 0)).catch(() => {});
      }
      if (isDataEntry) {
        getMyDeniedCount().then((d: any)       => setDeniedCount(d.count       || 0)).catch(() => {});
      }
      if (isMentor) {
        getMyMentorEditCount().then((d: any)   => setMentorDeniedCount(d.count || 0)).catch(() => {});
        getAgeOutNotificationCount().then((d: any) => setAgeOutCount(d.count || 0)).catch(() => {});
      }
    };
    poll();
    const iv = setInterval(poll, 30000);
    window.addEventListener('tc-refresh-counts', poll);
    return () => {
      clearInterval(iv);
      window.removeEventListener('tc-refresh-counts', poll);
    };
  }, [isAdmin, isDataEntry, isMentor]);

  if (!user) return null;

  let tabs: Tab[] = [];

  if (isAdmin) {
    tabs = [
      { path: '/register',            icon: '📝', label: 'New Registration'  },
      { path: '/admin/submissions',   icon: '📋', label: 'Submissions',     badge: pendingSubmissions },
      { path: '/admin/edit-requests', icon: '📩', label: 'Edit Requests',   badge: pendingRequests    },
      { path: '/existing',            icon: '🔍', label: 'Existing Data',   matchPrefixes: ['/existing', '/kid/'] },
      { path: '/mentors-admin',       icon: '🧑‍🏫', label: 'Mentors'          },
      { path: '/spiritual',           icon: '✝️',  label: 'Spiritual'         },
      { path: '/records',             icon: '📊', label: 'Records'           },
      { path: '/analytics',           icon: '📈', label: 'Analytics'         },
      { path: '/attendance',          icon: '✅', label: 'Attendance'        },
      { path: '/age-out',             icon: '⏰', label: 'Age-Out',          badge: ageOutCount },
      { path: '/users',               icon: '👥', label: 'Users'             },
    ];
  } else if (isDataEntry) {
    tabs = [
      { path: '/register', icon: '📝', label: 'My Registrations', badge: deniedCount },
    ];
  } else if (isMentor) {
    tabs = [
      { path: '/mentor-dashboard',  icon: '👤', label: 'My Teens',     badge: mentorDeniedCount },
      { path: '/mentor-sessions',   icon: '📅', label: 'Sessions',     matchPrefixes: ['/mentor-sessions'] },
      { path: '/existing',          icon: '🔍', label: 'Existing Data', matchPrefixes: ['/existing', '/kid/'] },
      { path: '/spiritual',         icon: '✝️',  label: 'Spiritual'                                            },
      { path: '/records',           icon: '📊', label: 'Records'                                              },
      { path: '/mentor-ageout',     icon: '🔔', label: 'Age-Out Alerts',   badge: ageOutCount                },
    ];
  } else if (isSpiritualLeader) {
    tabs = [
      { path: '/existing',   icon: '🔍', label: 'Existing Data', matchPrefixes: ['/existing', '/kid/'] },
      { path: '/spiritual',  icon: '✝️',  label: 'Spiritual'                                             },
      { path: '/records',    icon: '📊', label: 'Records'                                               },
      { path: '/attendance', icon: '✅', label: 'Attendance'                                            },
      { path: '/analytics',  icon: '📈', label: 'Analytics'                                             },
    ];
  }

  if (tabs.length === 0) return null;

  const isActive = (tab: Tab) => {
    const prefixes = tab.matchPrefixes || [tab.path];
    return prefixes.some(p =>
      location.pathname === p ||
      location.pathname.startsWith(p + '/') ||
      location.pathname.startsWith(p)
    );
  };

  return (
    <div
      style={{
        background: '#1e293b',
        borderBottom: '2px solid #334155',
        display: 'flex',
        overflowX: 'auto',
        scrollbarWidth: 'none',
        WebkitOverflowScrolling: 'touch' as any,
        position: 'sticky',
        top: 56,
        zIndex: 99,
      }}
    >
      {tabs.map(tab => {
        const active = isActive(tab);
        const badgeNum = tab.badge ?? 0;
        return (
          <button
            key={tab.path}
            onClick={() => navigate(tab.path)}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 5,
              padding: '10px 14px',
              background: active ? 'rgba(96,165,250,0.12)' : 'transparent',
              color: active ? '#60a5fa' : 'rgba(255,255,255,0.6)',
              border: 'none',
              borderBottom: active ? '2px solid #60a5fa' : '2px solid transparent',
              marginBottom: -2,
              cursor: 'pointer',
              fontSize: 13,
              fontWeight: active ? 600 : 400,
              whiteSpace: 'nowrap',
              transition: 'color .15s, background .15s',
              flexShrink: 0,
            }}
          >
            <span>{tab.icon}</span>
            <span>{tab.label}</span>
            {badgeNum > 0 && (
              <span
                style={{
                  background: '#ef4444',
                  color: '#fff',
                  borderRadius: 10,
                  padding: '1px 6px',
                  fontSize: 11,
                  fontWeight: 700,
                  lineHeight: '16px',
                  minWidth: 19,
                  textAlign: 'center',
                }}
              >
                {badgeNum}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
