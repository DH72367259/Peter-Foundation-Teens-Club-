import axios from 'axios';

const BASE = import.meta.env.VITE_API_URL || '/api';

const api = axios.create({ baseURL: BASE });

api.interceptors.request.use(config => {
  const token = localStorage.getItem('tc_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  r => r,
  err => {
    const isLoginEndpoint = err.config?.url?.includes('/auth/login');
    if (err.response?.status === 401 && !isLoginEndpoint) {
      localStorage.removeItem('tc_token');
      localStorage.removeItem('tc_user');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

// ─── Auth ──────────────────────────────────────────────────────────────────────
export const login = (username: string, password: string) =>
  api.post('/auth/login', { username, password }).then(r => r.data);

export const getUsers = () => api.get('/auth/users').then(r => r.data);
export const getDeletedUsers = () => api.get('/auth/users/deleted').then(r => r.data);
export const createUser = (data: any) => api.post('/auth/users', data).then(r => r.data);
export const toggleUser = (id: string) => api.put(`/auth/users/${id}/toggle`).then(r => r.data);
export const deleteUser = (id: string) => api.delete(`/auth/users/${id}`).then(r => r.data);
export const restoreUser = (id: string) => api.put(`/auth/users/${id}/restore`).then(r => r.data);
export const resetPassword = (id: string, password: string) =>
  api.put(`/auth/users/${id}/password`, { password }).then(r => r.data);

// ─── Correction Reassign ───────────────────────────────────────────────────────
export const reassignCorrection = (kidId: string, new_user_id: string) =>
  api.post(`/kids/${kidId}/reassign-correction`, { new_user_id }).then(r => r.data);

// ─── Kids ──────────────────────────────────────────────────────────────────────
export const getKids = (page = 1) => api.get(`/kids?page=${page}`).then(r => r.data);
export const searchKids = (q: string) => api.get(`/kids/search?q=${encodeURIComponent(q)}`).then(r => r.data);
export const getKid = (id: string) => api.get(`/kids/${id}`).then(r => r.data);
export const createRegistration = (data: any) => api.post('/kids', data).then(r => r.data);
export const updateKid = (id: string, data: any) => api.put(`/kids/${id}`, data).then(r => r.data);
export const deleteKid = (id: string) => api.delete(`/kids/${id}`).then(r => r.data);
export const signKid = (id: string) => api.post(`/kids/${id}/sign`).then(r => r.data);
export const unlockKid = (id: string) => api.post(`/kids/${id}/unlock`).then(r => r.data);
export const uploadKidPhoto = (id: string, photo_data: string) => api.put(`/kids/${id}/photo`, { photo_data }).then(r => r.data);
export const removeKidPhoto = (id: string) => api.delete(`/kids/${id}/photo`).then(r => r.data);

// ─── Meta ──────────────────────────────────────────────────────────────────────
export const getHobbies = () => api.get('/kids/meta/hobbies').then(r => r.data);
export const getInterests = () => api.get('/kids/meta/interests').then(r => r.data);

// ─── Analytics ────────────────────────────────────────────────────────────────
export const getAnalyticsSummary = () => api.get('/analytics/summary').then(r => r.data);
export const getHobbyStats = () => api.get('/analytics/hobbies').then(r => r.data);
export const getInterestStats = () => api.get('/analytics/interests').then(r => r.data);
export const getAgeGroups = () => api.get('/analytics/age-groups').then(r => r.data);
export const getEducationLevels = () => api.get('/analytics/education-levels').then(r => r.data);
export const getRegistrationsPerMonth = () => api.get('/analytics/registrations-per-month').then(r => r.data);
export const getGenderStats = () => api.get('/analytics/gender').then(r => r.data);

// ─── Mentors ──────────────────────────────────────────────────────────────────
export const getMentors = () => api.get('/mentors').then(r => r.data);
export const getMentorList = () => api.get('/mentors/list').then(r => r.data);
export const getMyKids = () => api.get('/mentors/my-kids').then(r => r.data);
export const getMentorKids = (mentorId: string) => api.get(`/mentors/${mentorId}/kids`).then(r => r.data);
export const assignKidToMentor = (kid_id: string, mentor_id: string) =>
  api.post('/mentors/assign', { kid_id, mentor_id }).then(r => r.data);
export const removeKidFromMentor = (kid_id: string, mentor_id: string) =>
  api.delete('/mentors/assign', { data: { kid_id, mentor_id } }).then(r => r.data);
export const getSessionNotes = (kidId: string) => api.get(`/mentors/notes/${kidId}`).then(r => r.data);
export const addSessionNote = (data: any) => api.post('/mentors/notes', data).then(r => r.data);
export const deleteSessionNote = (noteId: string) => api.delete(`/mentors/notes/${noteId}`).then(r => r.data);
export const updateSessionNote = (noteId: string, data: any) => api.put(`/mentors/notes/${noteId}`, data).then(r => r.data);
export const signSessionNote = (noteId: string) => api.post(`/mentors/notes/${noteId}/sign`).then(r => r.data);
export const unlockSessionNote = (noteId: string) => api.post(`/mentors/notes/${noteId}/unlock`).then(r => r.data);

// ─── Spiritual ────────────────────────────────────────────────────────────────
export const getSpiritualSessions      = ()              => api.get('/spiritual/sessions').then(r => r.data);
export const createSpiritualSession    = (data: any)     => api.post('/spiritual/sessions', data).then(r => r.data);
export const getSpiritualSessionDetail = (id: string)    => api.get(`/spiritual/sessions/${id}`).then(r => r.data);
export const updateSpiritualSession    = (id: string, data: any) => api.put(`/spiritual/sessions/${id}`, data).then(r => r.data);
// saveSpiritualAttendance accepts:
//   GROUP:  { attendance: [{kid_id, is_present},...], mentor_attendance?: [{mentor_id, is_present},...] }
//   1:1:    { one_on_one_attended: boolean }
export const saveSpiritualAttendance   = (id: string, data: any) => api.put(`/spiritual/sessions/${id}/attendance`, data).then(r => r.data);
export const addSpiritualKidNote       = (sessionId: string, data: any) => api.post(`/spiritual/sessions/${sessionId}/kid-note`, data).then(r => r.data);
export const getSpiritualKidNotes      = (kidId: string) => api.get(`/spiritual/kid-notes/${kidId}`).then(r => r.data);
export const deleteSpiritualKidNote    = (noteId: string) => api.delete(`/spiritual/kid-notes/note/${noteId}`).then(r => r.data);
export const deleteSpiritualSession    = (id: string)    => api.delete(`/spiritual/sessions/${id}`).then(r => r.data);
export const getSpiritualKidsList      = ()              => api.get('/spiritual/kids').then(r => r.data);
export const getSpiritualMentors       = ()              => api.get('/spiritual/mentors').then(r => r.data);
// Sign / addon / unlock
export const signSpiritualSession      = (id: string)    => api.post(`/spiritual/sessions/${id}/sign`).then(r => r.data);
export const saveSpiritualAddon        = (id: string, addon_text: string) => api.put(`/spiritual/sessions/${id}/addon`, { addon_text }).then(r => r.data);
export const signSpiritualAddon        = (id: string)    => api.post(`/spiritual/sessions/${id}/addon-sign`).then(r => r.data);
export const unlockSpiritualSession    = (id: string)    => api.post(`/spiritual/sessions/${id}/unlock`).then(r => r.data);

// ─── Edit Requests ────────────────────────────────────────────────────────────
export const createEditRequest = (data: { entity_type: string; entity_id: string; entity_label?: string; reason: string }) =>
  api.post('/edit-requests', data).then(r => r.data);
export const getEditRequests = (status?: string) =>
  api.get('/edit-requests' + (status ? `?status=${status}` : '')).then(r => r.data);
export const getPendingRequestCount = () =>
  api.get('/edit-requests/pending-count').then(r => r.data);
export const approveEditRequest = (id: string, review_note?: string) =>
  api.put(`/edit-requests/${id}/approve`, { review_note }).then(r => r.data);
export const denyEditRequest = (id: string, review_note: string) =>
  api.put(`/edit-requests/${id}/deny`, { review_note }).then(r => r.data);

// ─── Registration Submission Workflow ──────────────────────────────────────────
export const getPendingSubmissionsCount = () =>
  api.get('/kids/pending-submissions/count').then(r => r.data);
export const getPendingSubmissions      = () =>
  api.get('/kids/pending-submissions').then(r => r.data);
export const getMyDeniedCount           = () =>
  api.get('/kids/my-denied-count').then(r => r.data);
export const submitKidForApproval       = (id: string) =>
  api.post(`/kids/${id}/submit`).then(r => r.data);
export const submitAllDrafts            = () =>
  api.post('/kids/submit-all').then(r => r.data);
export const approveKidSubmission       = (id: string) =>
  api.post(`/kids/${id}/approve-submission`).then(r => r.data);
export const approveBatchSubmissions    = (kid_ids: string[]) =>
  api.post('/kids/approve-batch', { kid_ids }).then(r => r.data);
export const denyKidSubmission          = (id: string, note: string) =>
  api.post(`/kids/${id}/deny-submission`, { note }).then(r => r.data);
export const requestChangesForKid       = (id: string, note: string) =>
  api.post(`/kids/${id}/request-changes`, { note }).then(r => r.data);

// ─── Mentor Edit Workflow ──────────────────────────────────────────────────────
export const getMyMentorEdits      = () => api.get('/kids/my-mentor-edits').then(r => r.data);
export const getMyMentorEditCount  = () => api.get('/kids/my-mentor-edits/count').then(r => r.data);
export const approveBatchEditRequests = (request_ids: string[]) =>
  api.put('/edit-requests/approve-batch', { request_ids }).then(r => r.data);

// ─── Notifications ─────────────────────────────────────────────────────────────
export const getNotifications     = () => api.get('/notifications').then(r => r.data);
export const markNotificationsRead = () => api.put('/notifications/mark-read').then(r => r.data);
export const markNotificationRead  = (id: string) => api.put(`/notifications/${id}/read`).then(r => r.data);
// ─── Backup ──────────────────────────────────────────────────────────
export const getBackupStatus = () => api.get('/auth/backup/status').then(r => r.data);
export const triggerBackup   = () => api.post('/auth/backup').then(r => r.data);
// ─── Kid Filtering ─────────────────────────────────────────────────────────────
export const filterKids = (params: {
  age?: number; age_min?: number; age_max?: number;
  gender?: string; education_level?: string; school?: string;
  interest_ids?: string; ambition?: string;
}) => api.get('/kids/filter', { params }).then(r => r.data);

export const getFilterMeta = () => api.get('/kids/filter-meta').then(r => r.data);

// ─── Mentor Reassign ───────────────────────────────────────────────────────────
export const getAllAssignedKids  = () => api.get('/mentors/all-assigned-kids').then(r => r.data);
export const reassignKidMentor   = (data: {
  kid_id: string; new_mentor_id: string; reason: string; transfer_notes: boolean;
}) => api.post('/mentors/reassign', data).then(r => r.data);

// ─── Spiritual Session RSVP ──────────────────────────────────────────────────
export const rsvpSpiritualSession  = (id: string, rsvp_status: 'ACCEPTED' | 'DECLINED') =>
  api.put(`/spiritual/sessions/${id}/rsvp`, { rsvp_status }).then(r => r.data);

// ─── Age-Out ──────────────────────────────────────────────────────────────────
export const getAgeOutNotifications      = ()            => api.get('/ageout/notifications').then(r => r.data);
export const getAgeOutNotificationCount  = ()            => api.get('/ageout/notifications/count').then(r => r.data);
export const markAgeOutNotificationRead  = (id: string) => api.put(`/ageout/notifications/${id}/read`).then(r => r.data);
export const markAllAgeOutNotificationsRead = ()         => api.put('/ageout/notifications/read-all').then(r => r.data);
export const getApproachingTeens         = ()            => api.get('/ageout/approaching').then(r => r.data);
export const getCompletedExtensions      = ()            => api.get('/ageout/extensions/completed').then(r => r.data);
export const getArchivedTeens            = ()            => api.get('/ageout/archived').then(r => r.data);
export const getAgeOutRequests           = ()            => api.get('/ageout/requests').then(r => r.data);
export const getMyAgeOutRequests         = ()            => api.get('/ageout/my-requests').then(r => r.data);
export const requestAgeOutExtension      = (kidId: string, requested_expiry_date: string) =>
  api.post(`/ageout/${kidId}/request-extension`, { requested_expiry_date }).then(r => r.data);
export const approveAgeOutExtension     = (requestId: string, approved_expiry_date: string, admin_note?: string) =>
  api.put(`/ageout/requests/${requestId}/approve`, { approved_expiry_date, admin_note }).then(r => r.data);
export const denyAgeOutExtension        = (requestId: string, admin_note?: string) =>
  api.put(`/ageout/requests/${requestId}/deny`, { admin_note }).then(r => r.data);
export const extendTeenStay            = (kidId: string, expiry_date: string, admin_note?: string) =>
  api.put(`/ageout/${kidId}/extend`, { expiry_date, admin_note }).then(r => r.data);
export const reactivateArchivedTeen     = (kidId: string, expiry_date: string, admin_note?: string) =>
  api.put(`/ageout/${kidId}/reactivate`, { expiry_date, admin_note }).then(r => r.data);
export const runAgeOutCheck             = ()            => api.post('/ageout/run-check').then(r => r.data);
export const getSpiritualMyInvites = () => api.get('/spiritual/my-invites').then(r => r.data);

// ─── Spiritual Session Cancel ─────────────────────────────────────────────────
export const cancelSpiritualSession = (id: string, data: { cancelled_reason: string; proposed_new_date?: string; proposed_new_topic?: string }) =>
  api.put(`/spiritual/sessions/${id}/cancel`, data).then(r => r.data);

// ─── Spiritual Upcoming Events ────────────────────────────────────────────────
export const getSpiritualUpcoming = (days = 14, type_filter = 'all') =>
  api.get('/spiritual/upcoming', { params: { days, type_filter } }).then(r => r.data);

// ─── Session Requests (Mentor → SL) ──────────────────────────────────────────
export const createSessionRequest = (data: { request_type: string; kid_ids?: string[]; message: string }) =>
  api.post('/spiritual/session-requests', data).then(r => r.data);
export const getSessionRequests   = () => api.get('/spiritual/session-requests').then(r => r.data);
export const getMySessionRequests = () => api.get('/spiritual/my-session-requests').then(r => r.data);
export const approveSessionRequest = (id: string, data: { session_date: string; topic: string }) =>
  api.put(`/spiritual/session-requests/${id}/approve`, data).then(r => r.data);
export const denySessionRequest = (id: string, data: { review_note?: string }) =>
  api.put(`/spiritual/session-requests/${id}/deny`, data).then(r => r.data);

// ─── Records / Data View ─────────────────────────────────────────────────────
export const getRecordsKidsList    = () => api.get('/records/kids-list').then(r => r.data);
export const getRecordsMentorsList = () => api.get('/records/mentors-list').then(r => r.data);
export const getKidRecord          = (kidId: string) => api.get(`/records/kid/${kidId}`).then(r => r.data);
export const getMentorRecord       = (mentorId: string) => api.get(`/records/mentor/${mentorId}`).then(r => r.data);
export const getGroupOverview      = () => api.get('/records/group-overview').then(r => r.data);
export const adminUpdateAttendance = (data: { session_id: string; entity_type: 'kid' | 'mentor'; entity_id: string; is_present: boolean }) =>
  api.put('/records/attendance', data).then(r => r.data);

export default api;
