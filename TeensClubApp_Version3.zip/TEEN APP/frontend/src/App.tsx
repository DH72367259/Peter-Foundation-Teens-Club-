import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import React from 'react';
import { AuthProvider, useAuth } from './AuthContext';

// ─── Global Error Boundary ────────────────────────────────────────────────────
class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { error: Error | null }
> {
  state = { error: null };
  static getDerivedStateFromError(e: Error) { return { error: e }; }
  componentDidCatch(e: Error, info: React.ErrorInfo) {
    console.error('[ErrorBoundary] Caught error:', e, info);
  }
  render() {
    if (this.state.error) {
      return (
        <div style={{
          minHeight: '100vh', display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center',
          background: '#0f172a', color: '#f1f5f9', fontFamily: 'sans-serif', padding: 32,
        }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>⚠️</div>
          <h2 style={{ fontSize: 22, marginBottom: 8 }}>Something went wrong</h2>
          <p style={{ color: '#94a3b8', marginBottom: 24, textAlign: 'center', maxWidth: 480 }}>
            An unexpected error occurred on this page. Click below to go back to the home screen.
          </p>
          <p style={{ color: '#ef4444', fontFamily: 'monospace', fontSize: 12, marginBottom: 24, maxWidth: 560, wordBreak: 'break-word', textAlign: 'center' }}>
            {(this.state.error as Error).message}
          </p>
          <button
            onClick={() => { this.setState({ error: null }); window.location.href = '/'; }}
            style={{ background: '#3b82f6', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 28px', fontSize: 15, cursor: 'pointer', fontWeight: 600 }}>
            ← Back to Home
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
import './styles.css';

import LoginPage from './pages/LoginPage';
import HomePage from './pages/HomePage';
import RegistrationPage from './pages/RegistrationPage';
import ExistingDataPage from './pages/ExistingDataPage';
import KidProfilePage from './pages/KidProfilePage';
import AnalyticsPage from './pages/AnalyticsPage';
import UsersPage from './pages/UsersPage';
import MentorsAdminPage from './pages/MentorsAdminPage';
import MentorDashboardPage from './pages/MentorDashboardPage';
import SessionNotesPage from './pages/SessionNotesPage';
import SpiritualLeaderPage from './pages/SpiritualLeaderPage';
import SpiritualSessionDetailPage from './pages/SpiritualSessionDetailPage';
import AdminEditRequestsPage from './pages/AdminEditRequestsPage';
import AdminSubmissionsPage from './pages/AdminSubmissionsPage';
import RecordsPage from './pages/RecordsPage';
import MentorSessionsPage from './pages/MentorSessionsPage';
import AttendancePage from './pages/AttendancePage';
import AgeOutAdminPage from './pages/AgeOutAdminPage';
import AgeOutMentorPage from './pages/AgeOutMentorPage';
import Navbar from './components/Navbar';
import TabBar from './components/TabBar';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

function AdminRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== 'ADMIN') return <Navigate to="/" replace />;
  return <>{children}</>;
}

function AnalyticsRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== 'ADMIN' && user.role !== 'SPIRITUAL_LEADER') return <Navigate to="/" replace />;
  return <>{children}</>;
}

function EditRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  // MENTOR can access /register/:id (edit existing), but RegistrationPage redirects them away from /register (new)
  // DATA_ENTRY and SUB can access both
  if (user.role === 'SPIRITUAL_LEADER') return <Navigate to="/" replace />;
  return <>{children}</>;
}

function MentorRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== 'MENTOR' && user.role !== 'ADMIN') return <Navigate to="/" replace />;
  return <>{children}</>;
}

function SpiritualRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  const allowed = ['ADMIN', 'SPIRITUAL_LEADER', 'MENTOR'];
  if (!allowed.includes(user.role)) return <Navigate to="/" replace />;
  return <>{children}</>;
}

// Blocks DATA_ENTRY and SUB from viewing existing approved records
function ViewOnlyRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role === 'DATA_ENTRY' || user.role === 'SUB') return <Navigate to="/" replace />;
  return <>{children}</>;
}

function AppRoutes() {
  const { user } = useAuth();
  return (
    <div className="app-shell">
      {user && <Navbar />}
      {user && <TabBar />}
      <Routes>
        <Route path="/login" element={user ? <Navigate to="/" /> : <LoginPage />} />
        <Route path="/" element={<ProtectedRoute><HomePage /></ProtectedRoute>} />
        <Route path="/register" element={<EditRoute><RegistrationPage /></EditRoute>} />
        <Route path="/register/:id" element={<EditRoute><RegistrationPage /></EditRoute>} />
        <Route path="/existing" element={<ViewOnlyRoute><ExistingDataPage /></ViewOnlyRoute>} />
        <Route path="/kid/:id" element={<ViewOnlyRoute><KidProfilePage /></ViewOnlyRoute>} />
        <Route path="/analytics" element={<AnalyticsRoute><AnalyticsPage /></AnalyticsRoute>} />
        <Route path="/users" element={<AdminRoute><UsersPage /></AdminRoute>} />
        <Route path="/mentors-admin" element={<AdminRoute><MentorsAdminPage /></AdminRoute>} />
        <Route path="/mentor-dashboard" element={<MentorRoute><MentorDashboardPage /></MentorRoute>} />
        <Route path="/mentor-sessions" element={<MentorRoute><MentorSessionsPage /></MentorRoute>} />
        <Route path="/notes/:kidId" element={<ProtectedRoute><SessionNotesPage /></ProtectedRoute>} />
        <Route path="/spiritual" element={<SpiritualRoute><SpiritualLeaderPage /></SpiritualRoute>} />
        <Route path="/spiritual/session/:id" element={<SpiritualRoute><SpiritualSessionDetailPage /></SpiritualRoute>} />
        <Route path="/admin/edit-requests" element={<AdminRoute><AdminEditRequestsPage /></AdminRoute>} />
        <Route path="/admin/submissions" element={<AdminRoute><AdminSubmissionsPage /></AdminRoute>} />
        <Route path="/records" element={<SpiritualRoute><RecordsPage /></SpiritualRoute>} />
        <Route path="/attendance" element={<AnalyticsRoute><AttendancePage /></AnalyticsRoute>} />
        <Route path="/age-out" element={<AdminRoute><AgeOutAdminPage /></AdminRoute>} />
        <Route path="/mentor-ageout" element={<MentorRoute><AgeOutMentorPage /></MentorRoute>} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <ErrorBoundary>
          <AppRoutes />
        </ErrorBoundary>
      </BrowserRouter>
    </AuthProvider>
  );
}
