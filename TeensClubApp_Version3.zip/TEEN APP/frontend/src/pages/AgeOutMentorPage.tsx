import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  getApproachingTeens,
  getMyAgeOutRequests,
  getAgeOutNotifications,
  requestAgeOutExtension,
  markAgeOutNotificationRead,
  markAllAgeOutNotificationsRead,
} from '../api';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function fmt(date: string | null | undefined): string {
  if (!date) return '—';
  const d = new Date(date + 'T00:00:00');
  return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function daysUntil(date: string): number {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(date + 'T00:00:00');
  return Math.round((target.getTime() - today.getTime()) / 86400000);
}

function maxExtDate(dob: string): string {
  const d = new Date(dob);
  d.setFullYear(d.getFullYear() + 22);
  d.setMonth(d.getMonth() + 3);
  return d.toISOString().slice(0, 10);
}

function openDatePicker(input: HTMLInputElement) {
  const pickerInput = input as HTMLInputElement & { showPicker?: () => void };
  pickerInput.showPicker?.();
}

function preventManualDateTyping(e: React.KeyboardEvent<HTMLInputElement>) {
  if (e.key === 'Tab') return;
  e.preventDefault();
}

function preventDatePaste(e: React.ClipboardEvent<HTMLInputElement>) {
  e.preventDefault();
}

function badge(text: string, color: string) {
  return (
    <span style={{
      background: color, color: '#fff', borderRadius: 8,
      padding: '2px 8px', fontSize: 11, fontWeight: 700, marginLeft: 6,
    }}>{text}</span>
  );
}

const card: React.CSSProperties = {
  background: '#1e293b', border: '1px solid #334155',
  borderRadius: 10, padding: '14px 18px', marginBottom: 12,
};

type ActiveTab = 'teens' | 'approved' | 'rejected' | 'notifications';

export default function AgeOutMentorPage() {
  const navigate = useNavigate();
  const [tab, setTab] = useState<ActiveTab>('teens');

  const [teens,   setTeens]   = useState<any[]>([]);
  const [myRequests, setMyRequests] = useState<any[]>([]);
  const [notifs,  setNotifs]  = useState<any[]>([]);
  const [loading, setLoading] = useState(true);  // start true
  const [refreshing, setRefreshing] = useState(false);
  const [error,   setError]   = useState('');

  // Request extension modal
  const [reqModal,  setReqModal]  = useState<{ kid: any } | null>(null);
  const [reqDate,   setReqDate]   = useState('');
  const [submitting, setSubmitting] = useState(false);

  const load = async (showSpinner = false) => {
    if (showSpinner) setLoading(true);
    else setRefreshing(true);
    setError('');
    try {
      const [t, r, n] = await Promise.all([getApproachingTeens(), getMyAgeOutRequests(), getAgeOutNotifications()]);
      setTeens(Array.isArray(t) ? t : []);
      setMyRequests(Array.isArray(r) ? r : []);
      setNotifs(Array.isArray(n) ? n : []);
    } catch (e: any) {
      setError(e?.response?.data?.error || 'Failed to load age-out data. Please refresh.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => { load(true); }, []);

  const handleRequestExtension = async () => {
    if (!reqModal || !reqDate) return;
    setSubmitting(true);
    try {
      await requestAgeOutExtension(reqModal.kid.kid_id, reqDate);
      setReqModal(null);
      setReqDate('');
      await load(false);
    } catch (e: any) {
      alert(e.response?.data?.error || 'Failed to submit extension request');
    } finally {
      setSubmitting(false);
    }
  };

  const unreadNotifs = notifs.filter(n => !n.is_read).length;
  const approvedRequests = myRequests.filter((r: any) => r.status === 'APPROVED');
  const rejectedRequests = myRequests.filter((r: any) => r.status === 'DENIED');
  const pendingByKid = new Map(
    myRequests
      .filter((r: any) => r.status === 'PENDING')
      .map((r: any) => [r.kid_id, r])
  );

  const tabs: { key: ActiveTab; label: string; icon: string; count?: number }[] = [
    { key: 'teens',         label: 'My Teens',      icon: '⚠️', count: teens.length },
    { key: 'approved',      label: 'Request Completed', icon: '✅', count: approvedRequests.length },
    { key: 'rejected',      label: 'Request Rejected', icon: '❌', count: rejectedRequests.length },
    { key: 'notifications', label: 'Notifications', icon: '🔔', count: unreadNotifs },
  ];

  return (
    <div style={{ padding: '20px 16px', maxWidth: 800, margin: '0 auto' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <h2 style={{ color: '#f1f5f9', fontWeight: 700, fontSize: 22, margin: 0 }}>🔔 Age-Out Alerts</h2>
        <button onClick={() => load(false)} disabled={refreshing}
          style={{ background: '#334155', color: '#94a3b8', border: 'none', borderRadius: 8, padding: '6px 12px', fontSize: 12, cursor: 'pointer' }}>
          {refreshing ? 'Refreshing…' : 'Refresh'}
        </button>
      </div>

      {error && <div style={{ background: '#7f1d1d', color: '#fca5a5', padding: '10px 14px', borderRadius: 8, marginBottom: 16 }}>{error}</div>}

      {/* Tab bar */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 20 }}>
        {tabs.map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            style={{
              padding: '8px 16px', borderRadius: 8, border: 'none', cursor: 'pointer', fontSize: 13, fontWeight: 600,
              background: tab === t.key ? '#3b82f6' : '#1e293b',
              color: tab === t.key ? '#fff' : '#94a3b8',
            }}>
            {t.icon} {t.label}
            {(t.count ?? 0) > 0 && (
              <span style={{ marginLeft: 6, background: '#ef4444', color: '#fff', borderRadius: 10, padding: '1px 6px', fontSize: 11 }}>{t.count}</span>
            )}
          </button>
        ))}
      </div>

      {loading && teens.length === 0 && myRequests.length === 0 && notifs.length === 0 && (
        <div style={{ color: '#94a3b8', textAlign: 'center', padding: 24 }}>Loading…</div>
      )}

      {/* ── My Teens Tab ──────────────────────────────────────────────────── */}
      {!loading && tab === 'teens' && (
        <div>
          <h3 style={{ color: '#94a3b8', fontWeight: 600, fontSize: 14, marginBottom: 12, letterSpacing: 1, textTransform: 'uppercase' }}>
            Teens Needing Attention
          </h3>
          {teens.length === 0 && (
            <p style={{ color: '#64748b', textAlign: 'center', padding: 24 }}>
              None of your teens are currently approaching age-out. All good!
            </p>
          )}
          {teens.map(teen => {
            const d2       = daysUntil(teen.birthday_22);
            const isArch   = teen.is_archived;
            const hasExt   = !!teen.extension_expires_at;
            const hasPend  = !!pendingByKid.get(teen.kid_id);
            const isPerm   = teen.is_permanently_archived;
            const daysToExtExpiry = hasExt ? daysUntil(teen.extension_expires_at) : null;
            const canReq = !isPerm && !hasPend && teen.extension_count < 2 && (
              isArch || !hasExt || (daysToExtExpiry !== null && daysToExtExpiry <= 7)
            );

            return (
              <div key={teen.kid_id} style={card}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 8 }}>
                  <div>
                    <span style={{ color: '#f1f5f9', fontWeight: 700, fontSize: 16 }}>
                      {teen.first_name} {teen.last_name}
                    </span>
                    {isPerm  && badge('PERMANENTLY ARCHIVED', '#7f1d1d')}
                    {isArch && !isPerm && badge('ARCHIVED', '#64748b')}
                    {hasExt && !isArch && badge('EXTENDED', '#10b981')}
                    {!isArch && !hasExt && d2 <= 7   && badge(`${d2}d left`, '#ef4444')}
                    {!isArch && !hasExt && d2 > 7 && d2 <= 14 && badge(`${d2}d left`, '#f97316')}
                    {!isArch && !hasExt && d2 > 14  && badge(`${d2}d left`, '#eab308')}
                  </div>
                  <div style={{ display: 'flex', gap: 6 }}>
                    {!isPerm && (
                      <button onClick={() => navigate(`/kid/${teen.kid_id}`)}
                        style={{ background: '#334155', color: '#94a3b8', border: 'none', borderRadius: 6, padding: '4px 10px', fontSize: 12, cursor: 'pointer' }}>
                        View Profile
                      </button>
                    )}
                    {canReq && (
                      <button
                        onClick={() => { setReqModal({ kid: teen }); setReqDate(''); }}
                        style={{ background: '#3b82f6', color: '#fff', border: 'none', borderRadius: 6, padding: '4px 10px', fontSize: 12, cursor: 'pointer', fontWeight: 600 }}>
                        Request Extension
                      </button>
                    )}
                  </div>
                </div>

                <div style={{ marginTop: 8, color: '#94a3b8', fontSize: 13, display: 'flex', gap: 20, flexWrap: 'wrap' }}>
                  <span>22nd birthday: {fmt(teen.birthday_22)}</span>
                  <span>Extensions used: {teen.extension_count}/2</span>
                  {hasExt && <span>Extension expires: {fmt(teen.extension_expires_at)}</span>}
                </div>

                {hasPend && (
                  <div style={{ marginTop: 8, background: '#0f172a', borderRadius: 6, padding: '6px 10px', fontSize: 12, color: '#fbbf24' }}>
                    ⏳ Extension request submitted until {fmt(pendingByKid.get(teen.kid_id)?.requested_expiry_date)} — awaiting admin approval.
                  </div>
                )}

                {!hasPend && hasExt && !isArch && daysToExtExpiry !== null && daysToExtExpiry > 7 && teen.extension_count < 2 && (
                  <div style={{ marginTop: 8, background: '#0f172a', borderRadius: 6, padding: '6px 10px', fontSize: 12, color: '#93c5fd' }}>
                    A new extension request can be submitted only within the last 7 days before expiry ({fmt(teen.extension_expires_at)}).
                  </div>
                )}

                {isArch && !isPerm && !hasPend && teen.extension_count < 2 && (
                  <div style={{ marginTop: 8, background: '#172554', borderRadius: 6, padding: '6px 10px', fontSize: 12, color: '#93c5fd' }}>
                    This teen has been archived. Request an extension so admin can review and reactivate them.
                  </div>
                )}

                {isPerm && (
                  <div style={{ marginTop: 8, background: '#450a0a', borderRadius: 6, padding: '6px 10px', fontSize: 12, color: '#fca5a5' }}>
                    This teen has used all 2 extensions and is permanently archived. No further extensions are possible.
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* ── Request Completed Tab ───────────────────────────────────────── */}
      {!loading && tab === 'approved' && (
        <div>
          <h3 style={{ color: '#94a3b8', fontWeight: 600, fontSize: 14, marginBottom: 12, letterSpacing: 1, textTransform: 'uppercase' }}>
            Request Completed
          </h3>
          {approvedRequests.length === 0 && (
            <p style={{ color: '#64748b', textAlign: 'center', padding: 24 }}>No approved extension requests yet.</p>
          )}
          {approvedRequests.map((req: any) => {
            const hasExt = !!req.extension_expires_at;
            const daysToExtExpiry = hasExt ? daysUntil(req.extension_expires_at) : null;
            const canReqAgain = !!hasExt && req.extension_count < 2 && daysToExtExpiry !== null && daysToExtExpiry <= 7 && !pendingByKid.get(req.kid_id);
            return (
              <div key={req.request_id} style={card}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 8 }}>
                  <div>
                    <span style={{ color: '#f1f5f9', fontWeight: 700, fontSize: 16 }}>
                      {req.first_name} {req.last_name}
                    </span>
                    {badge('EXTENDED', '#10b981')}
                  </div>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <button onClick={() => navigate(`/kid/${req.kid_id}`)}
                      style={{ background: '#334155', color: '#94a3b8', border: 'none', borderRadius: 6, padding: '4px 10px', fontSize: 12, cursor: 'pointer' }}>
                      View Profile
                    </button>
                    {canReqAgain && (
                      <button
                        onClick={() => {
                          setReqModal({ kid: { ...req, birthday_22: req.birthday_22 } });
                          setReqDate('');
                        }}
                        style={{ background: '#3b82f6', color: '#fff', border: 'none', borderRadius: 6, padding: '4px 10px', fontSize: 12, cursor: 'pointer', fontWeight: 600 }}>
                        Request Extension
                      </button>
                    )}
                  </div>
                </div>
                <div style={{ marginTop: 8, color: '#94a3b8', fontSize: 13, display: 'flex', gap: 20, flexWrap: 'wrap' }}>
                  <span>22nd birthday: {fmt(req.birthday_22)}</span>
                  <span>Approved until: {fmt(req.approved_expiry_date || req.extension_expires_at)}</span>
                  <span>Extensions used: {req.extension_count}/2</span>
                </div>
                {!canReqAgain && hasExt && req.extension_count < 2 && daysToExtExpiry !== null && daysToExtExpiry > 7 && (
                  <div style={{ marginTop: 8, background: '#0f172a', borderRadius: 6, padding: '6px 10px', fontSize: 12, color: '#93c5fd' }}>
                    Next request can be made in the last 7 days before expiry ({fmt(req.extension_expires_at)}).
                  </div>
                )}
                {req.extension_count >= 2 && (
                  <div style={{ marginTop: 8, background: '#450a0a', borderRadius: 6, padding: '6px 10px', fontSize: 12, color: '#fca5a5' }}>
                    Maximum 2 extensions used. No further extension requests are allowed.
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* ── Request Rejected Tab ────────────────────────────────────────── */}
      {!loading && tab === 'rejected' && (
        <div>
          <h3 style={{ color: '#94a3b8', fontWeight: 600, fontSize: 14, marginBottom: 12, letterSpacing: 1, textTransform: 'uppercase' }}>
            Request Rejected
          </h3>
          {rejectedRequests.length === 0 && (
            <p style={{ color: '#64748b', textAlign: 'center', padding: 24 }}>No rejected extension requests.</p>
          )}
          {rejectedRequests.map((req: any) => (
            <div key={req.request_id} style={{ ...card, borderColor: '#7f1d1d' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 8 }}>
                <div>
                  <span style={{ color: '#f1f5f9', fontWeight: 700, fontSize: 16 }}>
                    {req.first_name} {req.last_name}
                  </span>
                  {badge('REJECTED', '#ef4444')}
                </div>
                <button onClick={() => navigate(`/kid/${req.kid_id}`)}
                  style={{ background: '#334155', color: '#94a3b8', border: 'none', borderRadius: 6, padding: '4px 10px', fontSize: 12, cursor: 'pointer' }}>
                  View Profile
                </button>
              </div>
              <div style={{ marginTop: 8, color: '#94a3b8', fontSize: 13, display: 'flex', gap: 20, flexWrap: 'wrap' }}>
                <span>22nd birthday: {fmt(req.birthday_22)}</span>
                <span>Requested until: {fmt(req.requested_expiry_date)}</span>
              </div>
              {req.admin_note && (
                <div style={{ marginTop: 8, background: '#450a0a', borderRadius: 6, padding: '6px 10px', fontSize: 12, color: '#fca5a5' }}>
                  Rejected: {req.admin_note}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* ── Notifications Tab ─────────────────────────────────────────────── */}
      {!loading && tab === 'notifications' && (
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <h3 style={{ color: '#94a3b8', fontWeight: 600, fontSize: 14, marginBottom: 0, letterSpacing: 1, textTransform: 'uppercase' }}>
              Notifications
              {unreadNotifs > 0 && (
                <span style={{ marginLeft: 8, background: '#ef4444', color: '#fff', borderRadius: 10, padding: '2px 8px', fontSize: 12 }}>{unreadNotifs}</span>
              )}
            </h3>
            {unreadNotifs > 0 && (
              <button onClick={() => markAllAgeOutNotificationsRead().then(() => load(false))}
                style={{ background: '#334155', color: '#94a3b8', border: 'none', borderRadius: 6, padding: '4px 10px', fontSize: 12, cursor: 'pointer' }}>
                Mark All Read
              </button>
            )}
          </div>
          {notifs.length === 0 && (
            <p style={{ color: '#64748b', textAlign: 'center', padding: 24 }}>No notifications yet.</p>
          )}
          {notifs.map(n => (
            <div key={n.notification_id}
              onClick={() => { if (!n.is_read) markAgeOutNotificationRead(n.notification_id).then(() => load(false)); }}
              style={{
                ...card,
                opacity: n.is_read ? 0.55 : 1,
                borderColor: n.is_read ? '#334155' : '#3b82f6',
                cursor: n.is_read ? 'default' : 'pointer',
              }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
                <div style={{ color: '#f1f5f9', fontSize: 14 }}>{n.message}</div>
                {!n.is_read && <span style={{ color: '#3b82f6', fontSize: 11, whiteSpace: 'nowrap' }}>● Unread</span>}
              </div>
              <div style={{ marginTop: 6, color: '#64748b', fontSize: 12 }}>
                {n.notification_type?.replace(/_/g, ' ')} · {new Date(n.created_at).toLocaleString()}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── Request Extension Modal ───────────────────────────────────────── */}
      {reqModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
          <div style={{ background: '#1e293b', borderRadius: 12, padding: 28, width: 380, maxWidth: '93vw' }}>
            <h3 style={{ color: '#f1f5f9', marginTop: 0 }}>Request Extension</h3>
            <p style={{ color: '#94a3b8', fontSize: 13, marginTop: 0 }}>
              <strong style={{ color: '#f1f5f9' }}>{reqModal.kid.first_name} {reqModal.kid.last_name}</strong>
              <br />22nd birthday: {fmt(reqModal.kid.birthday_22)}
              <br />Max extension date: {fmt(maxExtDate(reqModal.kid.dob))} (3 months after 22nd birthday)
            </p>
            <label style={{ color: '#94a3b8', fontSize: 13, display: 'block', marginBottom: 6 }}>
              Requested Active Until
            </label>
            <input type="date"
              value={reqDate}
              min={new Date().toISOString().slice(0, 10)}
              max={maxExtDate(reqModal.kid.dob)}
              onChange={e => setReqDate(e.target.value)}
              onFocus={e => openDatePicker(e.currentTarget)}
              onClick={e => openDatePicker(e.currentTarget)}
              onKeyDown={preventManualDateTyping}
              onPaste={preventDatePaste}
              inputMode="none"
              style={{ width: '100%', background: '#0f172a', color: '#f1f5f9', border: '1px solid #334155', borderRadius: 6, padding: '8px 10px', fontSize: 14, boxSizing: 'border-box' }}
            />
            <p style={{ color: '#64748b', fontSize: 12, marginTop: 8 }}>
              Your request will be reviewed by an admin. Extensions used so far: {reqModal.kid.extension_count}/2.
            </p>
            <div style={{ display: 'flex', gap: 10, marginTop: 16 }}>
              <button onClick={handleRequestExtension} disabled={!reqDate || submitting}
                style={{ flex: 1, background: '#3b82f6', color: '#fff', border: 'none', borderRadius: 8, padding: '9px 0', fontWeight: 700, fontSize: 14, cursor: 'pointer' }}>
                {submitting ? 'Submitting…' : 'Submit Request'}
              </button>
              <button onClick={() => { setReqModal(null); setReqDate(''); }}
                style={{ flex: 1, background: '#334155', color: '#94a3b8', border: 'none', borderRadius: 8, padding: '9px 0', fontSize: 14, cursor: 'pointer' }}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
