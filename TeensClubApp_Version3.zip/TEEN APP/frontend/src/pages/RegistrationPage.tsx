import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createRegistration, updateKid, getKid, getHobbies, getInterests, getMentorList, submitKidForApproval, submitAllDrafts, getKids, uploadKidPhoto, removeKidPhoto } from '../api';
import { useAuth } from '../AuthContext';

const EDUCATION_LEVELS = ['Middle School (6–8)', 'High School (9–10)', 'Higher Secondary (11–12)', 'College / University', 'Other'];
const GRADE_OPTIONS = ['6th', '7th', '8th', '9th', '10th', '11th', '12th', '1st Year', '2nd Year', '3rd Year', '4th Year', 'Other'];
const RELATIONSHIPS = ['Father', 'Mother', 'Guardian', 'Stepfather', 'Stepmother'];
const CONTACT_PREFS = ['Call', 'WhatsApp', 'SMS', 'Email'];

interface Parent {
  full_name: string; relationship: string; phone: string; email: string;
  occupation: string; education: string; expectation_text: string;
  emergency_contact_name: string; emergency_contact_phone: string; preferred_contact: string;
  baptism_confirmed: boolean;
}

const emptyParent = (): Parent => ({
  full_name: '', relationship: 'Father', phone: '', email: '',
  occupation: '', education: '', expectation_text: '',
  emergency_contact_name: '', emergency_contact_phone: '', preferred_contact: 'WhatsApp',
  baptism_confirmed: false,
});

function CharCount({ value, max }: { value: string; max: number }) {
  const over = value.length > max;
  return <span className={`char-count ${over ? 'over' : ''}`}>{value.length}/{max}</span>;
}

export default function RegistrationPage() {
  const navigate = useNavigate();
  const { id: editId } = useParams<{ id: string }>();
  const isEdit = !!editId;
  const auth = useAuth();
  const canAssignMentor = auth?.user?.role === 'ADMIN' || auth?.user?.role === 'DATA_ENTRY' || auth?.user?.role === 'SUB';
  const isAdmin = auth?.user?.role === 'ADMIN';
  const isDataEntry = auth?.user?.role === 'DATA_ENTRY' || auth?.user?.role === 'SUB';
  const isMentor = auth?.user?.role === 'MENTOR';

  const [myDrafts, setMyDrafts]   = useState<any[]>([]);
  const [submitting, setSubmitting] = useState<string | null>(null);
  const [submitAllBusy, setSubmitAllBusy] = useState(false);
  // page-level tab for DATA_ENTRY: 'form' = New Registration, 'drafts' = My Drafts
  const [pageTab, setPageTab] = useState<'form' | 'drafts'>('form');

  const loadDrafts = () => {
    if (isDataEntry) getKids(1).then((d: any) => setMyDrafts(d.data || [])).catch(() => {});
  };

  const [activeTab, setActiveTab] = useState<'kid' | 'parent'>('kid');
  const [hobbiesMeta, setHobbiesMeta] = useState<{ hobby_id: number; name: string }[]>([]);
  const [interestsMeta, setInterestsMeta] = useState<{ interest_id: number; name: string }[]>([]);
  const [mentorsList, setMentorsList] = useState<{ user_id: string; full_name: string; username: string }[]>([]);
  const [selectedMentorId, setSelectedMentorId] = useState<string>('');

  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [isLocked, setIsLocked] = useState(false);
  const [submissionStatus, setSubmissionStatus] = useState<string>('DRAFT');
  const [submissionNote, setSubmissionNote]       = useState<string>('');
  const [ageInput, setAgeInput]                   = useState<string>('');
  const [dobError,  setDobError]                   = useState<string>('');

  // ── DOB calendar bounds (recomputed from today, not hardcoded) ───────────────
  // Age must be 15–21 years old as of today.
  const _today = new Date();
  _today.setHours(0, 0, 0, 0);
  // max DOB: youngest who is 15 → born exactly today - 15 years
  const _maxDob = new Date(_today.getFullYear() - 15, _today.getMonth(), _today.getDate());
  // min DOB: oldest who is still 21 → born 1 day AFTER "today - 22 years"
  const _minDob = new Date(_today.getFullYear() - 22, _today.getMonth(), _today.getDate());
  _minDob.setDate(_minDob.getDate() + 1);
  const DOB_MIN = _minDob.toISOString().slice(0, 10); // YYYY-MM-DD
  const DOB_MAX = _maxDob.toISOString().slice(0, 10); // YYYY-MM-DD

  // ── Kid Fields ──────────────────────────────────────────────────────────────
  const [kid, setKid] = useState({
    first_name: '', last_name: '', dob: '', gender: '',
    education_level: '', school_name: '', grade_year: '',
    phone: '', address: '',
    ambition_goal: '', additional_comments: '',
    baptism_confirmed: false, consent_participate: false,
  });
  const [selectedHobbies, setSelectedHobbies] = useState<number[]>([]);
  const [selectedInterests, setSelectedInterests] = useState<number[]>([]);

  // ── Parent Fields ────────────────────────────────────────────────────────────
  const [parents, setParents] = useState<Parent[]>([emptyParent()]);

  // ── Photo ────────────────────────────────────────────────────────────────────
  const [photoData, setPhotoData]         = useState<string>('');       // for new registrations
  const [existingPhoto, setExistingPhoto] = useState<string>('');       // loaded from DB on edit
  const [photoReplace, setPhotoReplace]   = useState<string>('');       // admin replace selection
  const [photoError, setPhotoError]       = useState<string>('');
  const [photoSaving, setPhotoSaving]     = useState(false);

  useEffect(() => {
    const loads: Promise<any>[] = [getHobbies(), getInterests()];
    if (canAssignMentor) loads.push(getMentorList());
    Promise.all(loads).then(([h, i, m]) => {
      setHobbiesMeta(h); setInterestsMeta(i);
      if (m) setMentorsList(m);
    });
    // MENTOR cannot create new registrations — redirect them to their dashboard
    if (!isEdit && isMentor) { navigate('/mentor-dashboard'); return; }
    // For DATA_ENTRY: load their own DRAFT+DENIED records
    if (!isEdit && isDataEntry) {
      loadDrafts();
      // Start on drafts tab if there are previous drafts (will fall back to form if empty after load)
    }
    if (isEdit && editId) {
      getKid(editId).then((data: any) => {        setKid({
          first_name: data.first_name, last_name: data.last_name, dob: data.dob,
          gender: data.gender || '', education_level: data.education_level || '',
          school_name: data.school_name || '', grade_year: data.grade_year || '',
          phone: data.phone_normalized || '', address: data.address || '',
          ambition_goal: data.ambition_goal || '', additional_comments: data.additional_comments || '',
          baptism_confirmed: !!data.baptism_confirmed, consent_participate: !!data.consent_participate,
        });
        setSelectedHobbies(data.hobbies.map((h: any) => h.hobby_id));
        setSelectedInterests(data.interests.map((i: any) => i.interest_id));
        if (data.mentor?.user_id) setSelectedMentorId(data.mentor.user_id);
        if (data.is_signed) setIsLocked(true);
        setSubmissionStatus(data.submission_status || 'DRAFT');
        setSubmissionNote(data.submission_note || '');
        if (data.photo_data) setExistingPhoto(data.photo_data);
        // Pre-fill age input from DOB
        if (data.dob) {
          const b = new Date(data.dob); const t = new Date();
          let a = t.getFullYear() - b.getFullYear();
          if (t.getMonth() - b.getMonth() < 0 || (t.getMonth() === b.getMonth() && t.getDate() < b.getDate())) a--;
          setAgeInput(String(a > 0 ? a : ''));
        }
        if (data.parents?.length) {
          setParents(data.parents.map((p: any) => ({
            full_name: p.full_name, relationship: p.relationship,
            phone: p.phone_normalized || '', email: p.email || '',
            occupation: p.occupation || '', education: p.education || '',
            expectation_text: p.expectation_text || '',
            emergency_contact_name: p.emergency_contact_name || '',
            emergency_contact_phone: p.emergency_contact_phone || '',
            preferred_contact: p.preferred_contact || 'WhatsApp',
            baptism_confirmed: !!p.baptism_confirmed,
          })));
        }
      });
    }
  }, [editId, isEdit]);

  const setKidField = (f: string, v: any) => setKid(k => ({ ...k, [f]: v }));

  const handlePhotoFile = (file: File | null, setter: (v: string) => void) => {
    setPhotoError('');
    if (!file) { setter(''); return; }
    if (!['image/jpeg', 'image/png'].includes(file.type)) {
      setPhotoError('Only JPG and PNG images are allowed.'); setter(''); return;
    }
    if (file.size > 200 * 1024) {
      setPhotoError(`Image too large (${(file.size / 1024).toFixed(0)} KB). Maximum allowed size is 200 KB.`); setter(''); return;
    }
    const reader = new FileReader();
    reader.onload = () => setter(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleSavePhotoReplace = async () => {
    if (!photoReplace || !editId) return;
    setPhotoSaving(true); setPhotoError('');
    try {
      await uploadKidPhoto(editId, photoReplace);
      setExistingPhoto(photoReplace); setPhotoReplace('');
    } catch (e: any) {
      setPhotoError(e.response?.data?.error || 'Photo upload failed');
    } finally { setPhotoSaving(false); }
  };

  const handleRemovePhoto = async () => {
    if (!editId || !window.confirm('Remove this photo? It will be permanently deleted from the database.')) return;
    setPhotoSaving(true); setPhotoError('');
    try {
      await removeKidPhoto(editId);
      setExistingPhoto(''); setPhotoReplace('');
    } catch (e: any) {
      setPhotoError(e.response?.data?.error || 'Photo removal failed');
    } finally { setPhotoSaving(false); }
  };

  // DOB → age (live), with 15–21 validation
  const handleDobChange = (val: string) => {
    setKidField('dob', val);
    setDobError('');
    if (val) {
      const b = new Date(val); const t = new Date();
      let a = t.getFullYear() - b.getFullYear();
      if (t.getMonth() - b.getMonth() < 0 || (t.getMonth() === b.getMonth() && t.getDate() < b.getDate())) a--;
      setAgeInput(a > 0 ? String(a) : '');
      if (a < 15) setDobError(`This teen is ${a} years old — minimum age is 15.`);
      else if (a > 21) setDobError(`This teen is ${a} years old — maximum age is 21.`);
    } else { setAgeInput(''); }
  };

  const handleSubmitForApproval = async () => {
    if (!editId) return;
    setError(''); setSuccess('');
    setSaving(true);
    try {
      await submitKidForApproval(editId);
      setSubmissionStatus('PENDING');
      setSuccess(isMentor ? 'Submitted for admin re-approval! Redirecting...' : 'Submitted for admin approval! Redirecting...');
      // Use replace:true so browser Back won't return to this form
      setTimeout(() => {
        if (isMentor) navigate('/mentor-dashboard', { replace: true });
        else navigate('/register', { replace: true });
      }, 1200);
    } catch (e: any) {
      setError(e.response?.data?.error || 'Submission failed');
    } finally { setSaving(false); }
  };

  const handleRowSubmit = async (kidId: string) => {
    setSubmitting(kidId);
    try {
      await submitKidForApproval(kidId);
      loadDrafts();
      window.dispatchEvent(new CustomEvent('tc-refresh-counts'));
    } catch (e: any) {
      alert(e.response?.data?.error || 'Submission failed');
    } finally { setSubmitting(null); }
  };

  const handleSubmitAll = async () => {
    const submittable = myDrafts.filter((k: any) => ['DRAFT', 'DENIED'].includes(k.submission_status));
    if (submittable.length === 0) { alert('No draft or denied records to submit.'); return; }
    if (!window.confirm(`Submit all ${submittable.length} record(s) for admin approval?`)) return;
    setSubmitAllBusy(true);
    try {
      const res = await submitAllDrafts();
      alert(res.message || 'All records submitted!');
      loadDrafts();
      window.dispatchEvent(new CustomEvent('tc-refresh-counts'));
    } catch (e: any) {
      alert(e.response?.data?.error || 'Submit all failed');
    } finally { setSubmitAllBusy(false); }
  };
  const toggleHobby = (id: number) =>
    setSelectedHobbies(h => h.includes(id) ? h.filter(x => x !== id) : [...h, id]);
  const toggleInterest = (id: number) =>
    setSelectedInterests(i => i.includes(id) ? i.filter(x => x !== id) : [...i, id]);
  const setParentField = (idx: number, f: string, v: any) =>
    setParents(ps => ps.map((p, i) => i === idx ? { ...p, [f]: v } : p));

  const handleSave = async () => {
    setError(''); setSuccess('');

    if (!kid.first_name.trim()) { setError('First name is required.'); setActiveTab('kid'); return; }
    // last_name is optional

    // Alpha-only validation
    const alphaOnly = /^[a-zA-Z ]+$/;
    if (!alphaOnly.test(kid.first_name.trim())) { setError('First name must contain letters and spaces only.'); setActiveTab('kid'); return; }
    if (kid.last_name.trim() && !alphaOnly.test(kid.last_name.trim())) { setError('Last name must contain letters and spaces only.'); setActiveTab('kid'); return; }
    if (!kid.dob)               { setError('Date of birth is required.'); setActiveTab('kid'); return; }
    if (!kid.gender)            { setError('Gender is required.'); setActiveTab('kid'); return; }
    if (!kid.education_level)   { setError('Education level is required.'); setActiveTab('kid'); return; }
    if (!kid.phone.trim())      { setError('Teen phone number is required.'); setActiveTab('kid'); return; }

    // Phone: exactly 10 digits
    const phoneDigits = kid.phone.replace(/\D/g, '');
    if (phoneDigits.length !== 10) {
      setError('Teen phone number must be exactly 10 digits (numbers only).');
      setActiveTab('kid'); return;
    }

    // DOB: age must be 15–21
    const birth = new Date(kid.dob);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
    if (age < 15) { setError(`Teen must be at least 15 years old (currently ${age}). Date of birth: ${kid.dob}.`); setActiveTab('kid'); return; }
    if (age > 21) { setError(`Teen must not be older than 21 years (currently ${age}). Only teens aged 15–21 can be registered.`); setActiveTab('kid'); return; }

    // Parent name alpha + phone validation
    for (const p of parents) {
      if (!p.full_name.trim()) continue;
      const alphaOnlyP = /^[a-zA-Z ]+$/;
      if (!alphaOnlyP.test(p.full_name.trim())) {
        setError(`Parent "${p.full_name}": Full name must contain letters and spaces only.`);
        setActiveTab('parent'); return;
      }
      if (p.phone) {
        const pDigits = p.phone.replace(/\D/g, '');
        if (pDigits.length !== 10) {
          setError(`Parent "${p.full_name}": phone must be exactly 10 digits.`);
          setActiveTab('parent'); return;
        }
      }
      if (p.emergency_contact_phone) {
        const ecDigits = p.emergency_contact_phone.replace(/\D/g, '');
        if (ecDigits.length !== 10) {
          setError(`Parent "${p.full_name}": emergency contact phone must be exactly 10 digits.`);
          setActiveTab('parent'); return;
        }
      }
    }

    setSaving(true);
    try {
      if (isEdit) {
        await updateKid(editId!, { kid, hobby_ids: selectedHobbies, interest_ids: selectedInterests, mentor_id: selectedMentorId || null });
        if (isAdmin) {
          setSuccess('Record updated, approved and signed successfully!');
          setSubmissionStatus('APPROVED'); setIsLocked(true);
        } else {
          setSuccess('Record updated successfully!');
          if (submissionStatus === 'DENIED') setSubmissionStatus('DRAFT');
        }
      } else {
        const res = await createRegistration({ kid, parents, hobby_ids: selectedHobbies, interest_ids: selectedInterests, mentor_id: selectedMentorId || null, photo_data: photoData || null });
        if (isAdmin) {
          setSuccess(`Registration approved and signed (Reg ID: ${res.registration_id}). Redirecting to profile...`);
          setTimeout(() => navigate(`/kid/${res.kid_id}`, { replace: true }), 1200);
        } else {
          setSuccess(`Saved as DRAFT (Reg ID: ${res.registration_id}). Submit it for approval from the Drafts tab below.`);
          // Reset form
          setKid({ first_name: '', last_name: '', dob: '', gender: '', education_level: '', school_name: '', grade_year: '', phone: '', address: '', ambition_goal: '', additional_comments: '', baptism_confirmed: false, consent_participate: false });
          setSelectedHobbies([]); setSelectedInterests([]); setSelectedMentorId(''); setParents([emptyParent()]); setAgeInput(''); setActiveTab('kid');
          loadDrafts();
          setTimeout(() => setPageTab('drafts'), 800);
        }
        if (isMentor) setTimeout(() => navigate('/mentor-dashboard', { replace: true }), 1200);
      }
    } catch (e: any) {
      setError(e.response?.data?.error || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const draftCount = myDrafts.filter((k: any) => k.submission_status === 'DRAFT').length;
  const deniedCount = myDrafts.filter((k: any) => k.submission_status === 'DENIED').length;
  const hasDrafts = myDrafts.length > 0;

  return (
    <main className="page">
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 16 }}>
        <button className="btn btn-outline btn-sm" onClick={() => navigate(-1)}>← Back</button>
        <h2 style={{ fontSize: 22, fontWeight: 700 }}>
          {isEdit ? 'Edit Registration' : isDataEntry ? 'Registrations' : 'New Registration'}
        </h2>
        {isEdit && submissionStatus && (
          <span style={{
            marginLeft: 8, padding: '2px 12px', borderRadius: 12, fontWeight: 700, fontSize: 13,
            background: submissionStatus === 'APPROVED' ? '#d4edda' : submissionStatus === 'PENDING' ? '#fff3cd' : submissionStatus === 'DENIED' ? '#f8d7da' : '#e2e3e5',
            color: submissionStatus === 'APPROVED' ? '#155724' : submissionStatus === 'PENDING' ? '#856404' : submissionStatus === 'DENIED' ? '#721c24' : '#383d41',
            border: `1px solid ${submissionStatus === 'APPROVED' ? '#c3e6cb' : submissionStatus === 'PENDING' ? '#ffeeba' : submissionStatus === 'DENIED' ? '#f5c6cb' : '#d6d8db'}`
          }}>{submissionStatus}</span>
        )}
      </div>

      {success && <div className="alert alert-success">{success}</div>}
      {error && <div className="alert alert-error">{error}</div>}

      {/* DATA_ENTRY: page-level tabs — New Registration | My Drafts */}
      {!isEdit && isDataEntry && (
        <div style={{ display: 'flex', gap: 0, marginBottom: 20, borderBottom: '2px solid #dee2e6' }}>
          <button
            onClick={() => setPageTab('form')}
            style={{
              padding: '10px 22px', fontWeight: 600, fontSize: 14, border: 'none', cursor: 'pointer',
              borderBottom: pageTab === 'form' ? '3px solid #0d6efd' : '3px solid transparent',
              background: 'none', color: pageTab === 'form' ? '#0d6efd' : '#495057',
              marginBottom: -2,
            }}
          >➕ New Registration</button>
          <button
            onClick={() => hasDrafts && setPageTab('drafts')}
            disabled={!hasDrafts}
            style={{
              padding: '10px 22px', fontWeight: 600, fontSize: 14, border: 'none',
              cursor: hasDrafts ? 'pointer' : 'not-allowed',
              borderBottom: pageTab === 'drafts' ? '3px solid #0d6efd' : '3px solid transparent',
              background: 'none',
              color: !hasDrafts ? '#adb5bd' : pageTab === 'drafts' ? '#0d6efd' : '#495057',
              marginBottom: -2,
            }}
          >
            📋 My Registrations{hasDrafts ? ` (${myDrafts.length})` : ''}
            {deniedCount > 0 && <span style={{ marginLeft: 6, background: '#dc3545', color: '#fff', borderRadius: 10, padding: '1px 7px', fontSize: 11 }}>{deniedCount} denied</span>}
          </button>
        </div>
      )}

      {/* DATA_ENTRY: Drafts tab content */}
      {!isEdit && isDataEntry && pageTab === 'drafts' && (
        <div className="card" style={{ marginBottom: 24 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <div className="card-title" style={{ marginBottom: 0 }}>📋 My Registrations ({myDrafts.length})</div>
            <div style={{ display: 'flex', gap: 8 }}>
              {myDrafts.some((k: any) => ['DRAFT', 'DENIED'].includes(k.submission_status)) && (
                <button className="btn btn-primary btn-sm" onClick={handleSubmitAll} disabled={submitAllBusy} style={{ background: '#0d6efd' }}>
                  {submitAllBusy ? 'Submitting…' : `📤 Submit All (${myDrafts.filter((k: any) => ['DRAFT','DENIED'].includes(k.submission_status)).length})`}
                </button>
              )}
              <button className="btn btn-outline btn-sm" onClick={loadDrafts}>🔄 Refresh</button>
            </div>
          </div>

          {myDrafts.length === 0 ? (
            <p style={{ color: 'var(--muted)', textAlign: 'center', padding: '32px 0' }}>No saved registrations. Use the New Registration tab to create one.</p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {myDrafts.map((k: any) => (
                <div key={k.kid_id} style={{
                  padding: '14px 16px', borderRadius: 10,
                  border: k.submission_status === 'DENIED' ? '1.5px solid #f5c6cb' : '1.5px solid #dee2e6',
                  background: k.submission_status === 'DENIED' ? '#fff8f8' : '#fafbfc',
                  boxShadow: '0 1px 3px rgba(0,0,0,.04)'
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
                    <div>
                      <span style={{ fontWeight: 700, fontSize: 15 }}>{k.first_name} {k.last_name}</span>
                      <span style={{ marginLeft: 8, fontFamily: 'monospace', fontSize: 12, color: 'var(--muted)' }}>{k.registration_id}</span>
                      <span style={{
                        marginLeft: 8, padding: '2px 10px', borderRadius: 10, fontWeight: 700, fontSize: 11,
                        background: k.submission_status === 'DENIED' ? '#f8d7da' : '#e2e3e5',
                        color: k.submission_status === 'DENIED' ? '#721c24' : '#383d41'
                      }}>{k.submission_status}</span>
                      {k.age_snapshot && <span style={{ marginLeft: 8, color: 'var(--muted)', fontSize: 13 }}>Age {k.age_snapshot}</span>}
                    </div>
                    <div style={{ display: 'flex', gap: 6 }}>
                      <button className="btn btn-outline btn-sm" onClick={() => navigate(`/register/${k.kid_id}`)}>
                        {k.submission_status === 'DENIED' ? '✏️ Edit & Fix' : '✏️ Edit'}
                      </button>
                      {(k.submission_status === 'DRAFT' || k.submission_status === 'DENIED') && (
                        <button className="btn btn-primary btn-sm" onClick={() => handleRowSubmit(k.kid_id)}
                          disabled={submitting === k.kid_id} style={{ background: '#0d6efd' }}>
                          {submitting === k.kid_id ? '…' : '📤 Submit'}
                        </button>
                      )}
                    </div>
                  </div>
                  {k.submission_status === 'DENIED' && k.submission_note && (
                    <div style={{ marginTop: 10, padding: '8px 12px', background: '#f8d7da', borderRadius: 6, fontSize: 13, borderLeft: '3px solid #dc3545' }}>
                      <strong>⚠️ Admin feedback:</strong> {k.submission_note}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Hide form when DATA_ENTRY is on the drafts tab */}
      {(!isDataEntry || isEdit || pageTab === 'form') && (<>
        {isEdit && submissionStatus === 'DENIED' && submissionNote && (
        <div className="alert" style={{ background: '#f8d7da', border: '1px solid #f5c6cb', color: '#721c24', marginBottom: 16 }}>
          <strong>❌ Registration Denied:</strong> {submissionNote}
          <br /><small>Please correct the issues above and click <strong>Save Changes</strong>, then resubmit.</small>
        </div>
      )}

      {/* Pending info banner */}
      {isEdit && submissionStatus === 'PENDING' && (
        <div className="alert" style={{ background: '#fff3cd', border: '1px solid #ffeeba', color: '#856404', marginBottom: 16 }}>
          ⏳ <strong>Submitted for Approval</strong> — This registration is waiting for admin review. Editing is disabled until a decision is made.
        </div>
      )}

      {isEdit && isLocked && !isAdmin && (
        <div className="alert" style={{ background: '#fff7ed', border: '1px solid #f97316', color: '#c2410c', marginBottom: 16 }}>
          🔒 This registration is <strong>signed and locked</strong>. Go to the profile page to request an edit.
        </div>
      )}

      <div className="tabs">
        <button className={`tab-btn ${activeTab === 'kid' ? 'active' : ''}`} onClick={() => setActiveTab('kid')}>
          👦 Kid / Teen Details
        </button>
        <button className={`tab-btn ${activeTab === 'parent' ? 'active' : ''}`} onClick={() => setActiveTab('parent')}>
          👨‍👩‍👦 Parent / Guardian Details
        </button>
      </div>

      {/* ── Tab 1: Kid ──────────────────────────────────────────────────── */}
      {activeTab === 'kid' && (
        <div className="card">
          <div className="card-title">Teen's Personal Information</div>

          <div className="form-grid">
            <div className="field">
              <label className="required">First Name</label>
              <input value={kid.first_name} onChange={e => setKidField('first_name', e.target.value.replace(/[^a-zA-Z\s]/g, ''))} placeholder="First name" maxLength={60} />
            </div>
            <div className="field">
              <label>Last Name <span style={{ color: 'var(--muted)', fontWeight: 400, fontSize: 12 }}>(optional)</span></label>
              <input value={kid.last_name} onChange={e => setKidField('last_name', e.target.value.replace(/[^a-zA-Z\s]/g, ''))} placeholder="Last name" maxLength={60} />
            </div>
            <div className="field">
              <label className="required">Date of Birth</label>
              <input
                type="date"
                value={kid.dob}
                min={DOB_MIN}
                max={DOB_MAX}
                onChange={e => handleDobChange(e.target.value)}
              />
              {dobError && <span style={{ color: '#ef4444', fontSize: 12, marginTop: 4, display: 'block' }}>{dobError}</span>}
            </div>
            <div className="field">
              <label>Age <span style={{ color: 'var(--muted)', fontWeight: 400, fontSize: 12 }}>(auto-calculated from DOB)</span></label>
              <input
                type="number" min={15} max={21}
                value={ageInput}
                readOnly
                style={{
                  background: '#fff1f2',
                  color: '#b91c1c',
                  border: '1px solid #fca5a5',
                  fontWeight: 700,
                  opacity: 1,
                  cursor: 'not-allowed'
                }}
                placeholder="Calculated from DOB"
              />
            </div>
            <div className="field">
              <label className="required">Gender</label>
              <select value={kid.gender} onChange={e => setKidField('gender', e.target.value)}>
                <option value="">— Select —</option>
                <option>Male</option><option>Female</option><option>Prefer not to say</option>
              </select>
            </div>
            <div className="field">
              <label className="required">Education Level</label>
              <select value={kid.education_level} onChange={e => setKidField('education_level', e.target.value)}>
                <option value="">— Select —</option>
                {EDUCATION_LEVELS.map(l => <option key={l}>{l}</option>)}
              </select>
            </div>
            <div className="field">
              <label>Class / Grade / Year</label>
              <select value={kid.grade_year} onChange={e => setKidField('grade_year', e.target.value)}>
                <option value="">— Select —</option>
                {GRADE_OPTIONS.map(g => <option key={g}>{g}</option>)}
              </select>
            </div>
            <div className="field form-full">
              <label>School / College Name</label>
              <input value={kid.school_name} onChange={e => setKidField('school_name', e.target.value)} placeholder="Name of school or college" maxLength={100} />
            </div>
            <div className="field">
              <label className="required">Contact Phone (Teen's or Parent's)</label>
              <input
                value={kid.phone}
                onChange={e => setKidField('phone', e.target.value.replace(/\D/g, '').slice(0, 10))}
                placeholder="10-digit phone number"
                maxLength={10}
                inputMode="numeric"
                pattern="[0-9]*"
              />
            </div>
            <div className="field">
              <label>Address / Area <span style={{ color: 'var(--muted)', fontWeight: 400 }}>(max 250 chars)</span></label>
              <input value={kid.address} onChange={e => setKidField('address', e.target.value.slice(0, 250))} placeholder="Area or full address" maxLength={250} />
            </div>
          </div>

          <hr style={{ margin: '24px 0', border: 'none', borderTop: '1px solid var(--border)' }} />

          {/* Hobbies */}
          <div style={{ marginBottom: 20 }}>
            <div className="card-title" style={{ marginBottom: 10 }}>Hobbies (select all that apply)</div>
            <div className="checkbox-grid">
              {hobbiesMeta.map(h => (
                <label key={h.hobby_id} className="checkbox-item">
                  <input type="checkbox" checked={selectedHobbies.includes(h.hobby_id)}
                    onChange={() => toggleHobby(h.hobby_id)} />
                  <label>{h.name}</label>
                </label>
              ))}
            </div>
          </div>

          {/* Interests */}
          <div style={{ marginBottom: 20 }}>
            <div className="card-title" style={{ marginBottom: 10 }}>Interests / Areas of Interest</div>
            <div className="checkbox-grid">
              {interestsMeta.map(i => (
                <label key={i.interest_id} className="checkbox-item">
                  <input type="checkbox" checked={selectedInterests.includes(i.interest_id)}
                    onChange={() => toggleInterest(i.interest_id)} />
                  <label>{i.name}</label>
                </label>
              ))}
            </div>
          </div>

          <hr style={{ margin: '24px 0', border: 'none', borderTop: '1px solid var(--border)' }} />

          {/* Text areas */}
          <div className="form-grid">
            <div className="field form-full">
              <label>Ambition / Goal in Life <span style={{ color: 'var(--muted)', fontWeight: 400 }}>(max 250 chars)</span></label>
              <textarea rows={3} value={kid.ambition_goal}
                onChange={e => setKidField('ambition_goal', e.target.value.slice(0, 250))}
                placeholder="What does the teen want to become / achieve?" />
              <CharCount value={kid.ambition_goal} max={250} />
            </div>
            <div className="field form-full">
              <label>Additional Comments <span style={{ color: 'var(--muted)', fontWeight: 400 }}>(max 250 chars)</span></label>
              <textarea rows={3} value={kid.additional_comments}
                onChange={e => setKidField('additional_comments', e.target.value.slice(0, 250))}
                placeholder="Any other notes about the teen..." />
              <CharCount value={kid.additional_comments} max={250} />
            </div>
          </div>

          <hr style={{ margin: '24px 0', border: 'none', borderTop: '1px solid var(--border)' }} />

          {/* Church & Consent */}
          <div className="card-title" style={{ marginBottom: 10 }}>Church & Consent</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {[
              { field: 'baptism_confirmed', label: '✝️  Baptism / Confirmation completed' },
              { field: 'consent_participate', label: '✅  Parent consent to participate in club activities' },
            ].map(({ field, label }) => (
              <label key={field} className="checkbox-item" style={{ maxWidth: 420 }}>
                <input type="checkbox"
                  checked={kid[field as keyof typeof kid] as boolean}
                  onChange={e => setKidField(field, e.target.checked)} />
                <label>{label}</label>
              </label>
            ))}
          </div>

          {/* Mentor Assignment */}
          {canAssignMentor && mentorsList.length > 0 && (            <>
              <hr style={{ margin: '24px 0', border: 'none', borderTop: '1px solid var(--border)' }} />
              <div className="card-title" style={{ marginBottom: 10 }}>👤 Assign Mentor <span style={{ color: 'var(--muted)', fontWeight: 400, fontSize: 13 }}>(optional)</span></div>
              <div className="form-grid">
                <div className="field">
                  <label>Mentor</label>
                  <select value={selectedMentorId} onChange={e => setSelectedMentorId(e.target.value)}>
                    <option value="">— No mentor assigned —</option>
                    {mentorsList.map(m => (
                      <option key={m.user_id} value={m.user_id}>{m.full_name} ({m.username})</option>
                    ))}
                  </select>
                </div>
              </div>
            </>
          )}

          {/* ── Photo Upload ──────────────────────────────────────────────── */}
          <hr style={{ margin: '24px 0', border: 'none', borderTop: '1px solid var(--border)' }} />
          <div className="card-title" style={{ marginBottom: 10 }}>📷 Teen Photo <span style={{ color: 'var(--muted)', fontWeight: 400, fontSize: 13 }}>(optional · JPG or PNG · max 200 KB)</span></div>
          {photoError && <div className="alert alert-error" style={{ marginBottom: 8 }}>{photoError}</div>}

          {/* EDIT mode: existing photo from DB */}
          {isEdit && existingPhoto ? (
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: 20, flexWrap: 'wrap' }}>
              <img src={existingPhoto} alt="Current photo"
                style={{ width: 120, height: 120, objectFit: 'cover', borderRadius: 10, border: '2px solid var(--border)' }} />
              <div>
                {isAdmin ? (
                  <>
                    <p style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 8 }}>As admin you can replace or remove this photo.</p>
                    <input type="file" accept="image/jpeg,image/png"
                      onChange={e => handlePhotoFile(e.target.files?.[0] ?? null, setPhotoReplace)}
                      style={{ fontSize: 13 }} />
                    {photoReplace && (
                      <div style={{ marginTop: 10, display: 'flex', alignItems: 'center', gap: 12 }}>
                        <img src={photoReplace} alt="New photo preview"
                          style={{ width: 80, height: 80, objectFit: 'cover', borderRadius: 8, border: '2px solid #0d6efd' }} />
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                          <button className="btn btn-primary btn-sm" onClick={handleSavePhotoReplace} disabled={photoSaving}>
                            {photoSaving ? 'Saving…' : '💾 Save New Photo'}
                          </button>
                          <button className="btn btn-outline btn-sm" onClick={() => { setPhotoReplace(''); setPhotoError(''); }}>Cancel</button>
                        </div>
                      </div>
                    )}
                    <button className="btn btn-danger btn-sm" style={{ marginTop: 10 }} onClick={handleRemovePhoto} disabled={photoSaving}>
                      🗑 Remove Photo
                    </button>
                  </>
                ) : (
                  <p style={{ fontSize: 13, color: 'var(--muted)', marginTop: 4 }}>
                    🔒 A photo is already on file. Only the admin can replace it.
                  </p>
                )}
              </div>
            </div>
          ) : isEdit && !existingPhoto ? (
            /* Edit mode — no photo yet: anyone who can edit can upload */
            <div>
              <p style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 8 }}>No photo uploaded yet. You can add one below.</p>
              <input type="file" accept="image/jpeg,image/png"
                onChange={e => handlePhotoFile(e.target.files?.[0] ?? null, setPhotoReplace)}
                style={{ fontSize: 13 }} />
              {photoReplace && (
                <div style={{ marginTop: 10, display: 'flex', alignItems: 'center', gap: 12 }}>
                  <img src={photoReplace} alt="Preview"
                    style={{ width: 80, height: 80, objectFit: 'cover', borderRadius: 8, border: '2px solid #0d6efd' }} />
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                    <button className="btn btn-primary btn-sm" onClick={handleSavePhotoReplace} disabled={photoSaving}>
                      {photoSaving ? 'Saving…' : '💾 Save Photo'}
                    </button>
                    <button className="btn btn-outline btn-sm" onClick={() => { setPhotoReplace(''); setPhotoError(''); }}>Cancel</button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            /* New registration mode */
            <div>
              <p style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 8 }}>You can optionally add a photo now. It will be saved with the registration.</p>
              <input type="file" accept="image/jpeg,image/png"
                onChange={e => handlePhotoFile(e.target.files?.[0] ?? null, setPhotoData)}
                style={{ fontSize: 13 }} />
              {photoData && (
                <div style={{ marginTop: 10, display: 'flex', alignItems: 'center', gap: 12 }}>
                  <img src={photoData} alt="Preview"
                    style={{ width: 80, height: 80, objectFit: 'cover', borderRadius: 8, border: '2px solid #0d6efd' }} />
                  <button className="btn btn-outline btn-sm" onClick={() => { setPhotoData(''); setPhotoError(''); }}>✕ Remove</button>
                </div>
              )}
            </div>
          )}

          <div className="btn-row">
            <button className="btn btn-primary" onClick={() => setActiveTab('parent')}>
              Next: Parent Details →
            </button>
          </div>
        </div>
      )}

      {/* ── Tab 2: Parents ──────────────────────────────────────────────── */}
      {activeTab === 'parent' && (
        <div>
          {parents.map((p, idx) => (
            <div key={idx} className="card" style={{ marginBottom: 16 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
                <div className="card-title" style={{ marginBottom: 0 }}>
                  {idx === 0 ? 'Primary Guardian / Parent' : 'Second Parent / Guardian'} (#{idx + 1})
                </div>
                {!isEdit && idx === 1 && (
                  <button className="btn btn-outline btn-sm" onClick={() => setParents([parents[0]])}>
                    Remove
                  </button>
                )}
              </div>

              <div className="form-grid">
                <div className="field">
                  <label className="required">Full Name</label>
                  <input value={p.full_name} onChange={e => setParentField(idx, 'full_name', e.target.value.replace(/[^a-zA-Z\s]/g, ''))}
                    placeholder="Parent / guardian full name" maxLength={80} />
                </div>
                <div className="field">
                  <label>Relationship</label>
                  <select value={p.relationship} onChange={e => setParentField(idx, 'relationship', e.target.value)}>
                    {RELATIONSHIPS.map(r => <option key={r}>{r}</option>)}
                  </select>
                </div>
                <div className="field">
                  <label>Phone Number</label>
                  <input
                    value={p.phone}
                    onChange={e => setParentField(idx, 'phone', e.target.value.replace(/\D/g, '').slice(0, 10))}
                    placeholder="10-digit phone number"
                    maxLength={10}
                    inputMode="numeric"
                    pattern="[0-9]*"
                  />
                </div>
                <div className="field">
                  <label>Email (optional)</label>
                  <input type="email" value={p.email} onChange={e => setParentField(idx, 'email', e.target.value)}
                    placeholder="email@example.com" />
                </div>
                <div className="field">
                  <label>Occupation</label>
                  <input value={p.occupation} onChange={e => setParentField(idx, 'occupation', e.target.value)}
                    placeholder="e.g. Engineer, Teacher, Business" maxLength={80} />
                </div>
                <div className="field">
                  <label>Education</label>
                  <input value={p.education} onChange={e => setParentField(idx, 'education', e.target.value)}
                    placeholder="e.g. B.Tech, Masters, Diploma" maxLength={80} />
                </div>
                <div className="field">
                  <label>Preferred Contact Method</label>
                  <select value={p.preferred_contact} onChange={e => setParentField(idx, 'preferred_contact', e.target.value)}>
                    {CONTACT_PREFS.map(c => <option key={c}>{c}</option>)}
                  </select>
                </div>
                <div className="field">
                  <label>Emergency Contact Name</label>
                  <input value={p.emergency_contact_name}
                    onChange={e => setParentField(idx, 'emergency_contact_name', e.target.value)}
                    placeholder="Emergency contact full name" maxLength={80} />
                </div>
                <div className="field">
                  <label>Emergency Contact Phone</label>
                  <input
                    value={p.emergency_contact_phone}
                    onChange={e => setParentField(idx, 'emergency_contact_phone', e.target.value.replace(/\D/g, '').slice(0, 10))}
                    placeholder="10-digit phone number"
                    maxLength={10}
                    inputMode="numeric"
                    pattern="[0-9]*"
                  />
                </div>
                <div className="field form-full">
                  <label>What do you want your child to become? <span style={{ color: 'var(--muted)', fontWeight: 400 }}>(max 250 chars)</span></label>
                  <textarea rows={3} value={p.expectation_text}
                    onChange={e => setParentField(idx, 'expectation_text', e.target.value.slice(0, 250))}
                    placeholder="Describe your aspirations for your child..." />
                  <CharCount value={p.expectation_text} max={250} />
                </div>
              </div>

              {/* Per-parent baptism confirmation */}
              <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid var(--border)' }}>
                <label className="checkbox-item" style={{ maxWidth: 420 }}>
                  <input
                    type="checkbox"
                    checked={p.baptism_confirmed}
                    onChange={e => setParentField(idx, 'baptism_confirmed', e.target.checked)}
                  />
                  <label>✝️ {p.full_name || 'This parent'} — Baptism / Confirmation completed</label>
                </label>
              </div>
            </div>
          ))}

          {!isEdit && parents.length < 2 && (
            <button className="btn btn-outline" style={{ marginBottom: 16 }}
              onClick={() => setParents([...parents, emptyParent()])}>
              + Add Second Parent / Guardian
            </button>
          )}

          <div className="btn-row">
            <button className="btn btn-outline" onClick={() => setActiveTab('kid')}>← Back</button>
            {(isAdmin || isMentor || !isEdit || submissionStatus === 'DRAFT' || submissionStatus === 'DENIED') && (
              <button className="btn btn-primary" onClick={handleSave} disabled={saving || (isEdit && isLocked && !isAdmin && !isMentor)}>
                {saving ? 'Saving...' : isEdit ? '💾 Save Changes' : '✅ Complete Registration'}
              </button>
            )}
            {isEdit && (isMentor || (!isAdmin && (submissionStatus === 'DRAFT' || submissionStatus === 'DENIED'))) && (
              <button
                className="btn btn-primary"
                onClick={handleSubmitForApproval}
                disabled={saving}
                style={{ background: '#0d6efd', marginLeft: 8 }}
              >
                {saving ? 'Submitting…' : isMentor ? '📤 Submit Edit for Re-Approval' : '📤 Submit for Approval'}
              </button>
            )}
          </div>
        </div>
      )}
      </>)}
    </main>
  );
}
