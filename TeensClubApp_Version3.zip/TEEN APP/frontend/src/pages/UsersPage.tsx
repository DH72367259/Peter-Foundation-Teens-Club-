import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getUsers, getDeletedUsers, createUser, toggleUser, deleteUser, restoreUser, resetPassword } from '../api';
import { useAuth } from '../AuthContext';

type Tab = 'active' | 'deleted';

export default function UsersPage() {
  const navigate = useNavigate();
  const { user: currentUser } = useAuth();
  const [tab, setTab] = useState<Tab>('active');
  const [users, setUsers] = useState<any[]>([]);
  const [deletedUsers, setDeletedUsers] = useState<any[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ username: '', password: '', full_name: '', role: 'DATA_ENTRY' });
  const [resetPwd, setResetPwd] = useState<{ id: string; name: string } | null>(null);
  const [newPwd, setNewPwd] = useState('');
  const [confirmDelete, setConfirmDelete] = useState<{ id: string; name: string } | null>(null);
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');

  const load = () => Promise.all([
    getUsers().then(setUsers),
    getDeletedUsers().then(setDeletedUsers),
  ]);

  useEffect(() => { load(); }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault(); setMsg(''); setError('');
    try {
      await createUser(form);
      setMsg(`User "${form.username}" created successfully!`);
      setForm({ username: '', password: '', full_name: '', role: 'DATA_ENTRY' });
      setShowForm(false);
      load();
    } catch (e: any) { setError(e.response?.data?.error || 'Error creating user'); }
  };

  const handleToggle = async (id: string) => {
    setMsg(''); setError('');
    try { await toggleUser(id); load(); }
    catch (e: any) { setError(e.response?.data?.error || 'Failed to toggle user'); }
  };

  const handleDelete = async () => {
    if (!confirmDelete) return;
    setMsg(''); setError('');
    try {
      await deleteUser(confirmDelete.id);
      setMsg(`"${confirmDelete.name}" moved to deleted archive.`);
      setConfirmDelete(null);
      load();
    } catch (e: any) { setError(e.response?.data?.error || 'Failed to delete user'); setConfirmDelete(null); }
  };

  const handleRestore = async (id: string, name: string) => {
    setMsg(''); setError('');
    try {
      await restoreUser(id);
      setMsg(`"${name}" restored and reactivated.`);
      load();
    } catch (e: any) { setError(e.response?.data?.error || 'Failed to restore user'); }
  };

  const handleResetPwd = async () => {
    if (!resetPwd || !newPwd.trim()) return;
    try { await resetPassword(resetPwd.id, newPwd); setMsg(`Password reset for ${resetPwd.name}`); }
    catch (e: any) { setError(e.response?.data?.error || 'Failed to reset password'); }
    setResetPwd(null); setNewPwd('');
  };

  const roleBadgeClass = (role: string) =>
    role === 'ADMIN' ? 'badge-admin' : role === 'MENTOR' ? 'badge-mentor' : role === 'SPIRITUAL_LEADER' ? 'badge-sl' : 'badge-sub';

  return (
    <main className="page">
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 20 }}>
        <button className="btn btn-outline btn-sm" onClick={() => navigate('/')}>← Home</button>
        <h2 style={{ fontSize: 22, fontWeight: 700 }}>👥 User Management</h2>
        <div style={{ flex: 1 }} />
        {tab === 'active' && (
          <button className="btn btn-primary btn-sm" onClick={() => { setShowForm(!showForm); setError(''); setMsg(''); }}>
            {showForm ? 'Cancel' : '+ New User'}
          </button>
        )}
      </div>

      {msg && <div className="alert alert-success" style={{ marginBottom: 12 }}>{msg}</div>}
      {error && <div className="alert alert-error" style={{ marginBottom: 12 }}>{error}</div>}

      {/* Tab bar */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 20, borderBottom: '2px solid #334155' }}>
        {([['active', '✅ Active Users'], ['deleted', '🗑 Deleted Users']] as [Tab, string][]).map(([key, label]) => (
          <button key={key} onClick={() => { setTab(key); setMsg(''); setError(''); }}
            style={{
              padding: '8px 18px', border: 'none', cursor: 'pointer', fontSize: 13, fontWeight: 600,
              background: tab === key ? '#3b82f6' : 'transparent',
              color: tab === key ? '#fff' : '#94a3b8',
              borderRadius: '8px 8px 0 0', marginBottom: -2,
              borderBottom: tab === key ? '2px solid #3b82f6' : '2px solid transparent',
            }}>
            {label}
            {key === 'deleted' && deletedUsers.length > 0 && (
              <span style={{ marginLeft: 6, background: '#64748b', color: '#fff', borderRadius: 10, padding: '1px 6px', fontSize: 11 }}>{deletedUsers.length}</span>
            )}
          </button>
        ))}
      </div>

      {/* ── Active Users Tab ──────────────────────────────────────────────────── */}
      {tab === 'active' && (
        <>
          {/* Create User Form */}
          {showForm && (
            <div className="card" style={{ marginBottom: 20 }}>
              <div className="card-title">Create New User</div>
              <form onSubmit={handleCreate}>
                <div className="form-grid">
                  <div className="field">
                    <label className="required">Full Name</label>
                    <input value={form.full_name} onChange={e => setForm(f => ({ ...f, full_name: e.target.value }))}
                      placeholder="Full name" required maxLength={80} />
                  </div>
                  <div className="field">
                    <label className="required">Username</label>
                    <input value={form.username} onChange={e => setForm(f => ({ ...f, username: e.target.value.toLowerCase().trim() }))}
                      placeholder="username (no spaces)" required maxLength={40} />
                  </div>
                  <div className="field">
                    <label className="required">Password</label>
                    <input type="password" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                      placeholder="Min 8 characters" required minLength={6} />
                  </div>
                  <div className="field">
                    <label>Role</label>
                    <select value={form.role} onChange={e => setForm(f => ({ ...f, role: e.target.value }))}>
                      <option value="DATA_ENTRY">Data Entry (add/edit registrations, no analytics)</option>
                      <option value="MENTOR">Mentor (view assigned teens + session notes)</option>
                      <option value="ADMIN">Admin (full access)</option>
                      <option value="SPIRITUAL_LEADER">Spiritual Leader (sessions, attendance, notes)</option>
                    </select>
                  </div>
                </div>
                <div className="btn-row">
                  <button type="submit" className="btn btn-success">✅ Create User</button>
                </div>
              </form>
            </div>
          )}

          <div className="card">
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Full Name</th>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((u: any) => {
                    const isSelf = u.user_id === currentUser?.user_id;
                    return (
                      <tr key={u.user_id}>
                        <td><strong>{u.full_name}</strong></td>
                        <td><code>{u.username}</code></td>
                        <td><span className={`badge ${roleBadgeClass(u.role)}`}>{u.role}</span></td>
                        <td>
                          <span style={{ color: u.is_active ? 'var(--success)' : 'var(--danger)', fontWeight: 500 }}>
                            {u.is_active ? '✅ Active' : '❌ Inactive'}
                          </span>
                        </td>
                        <td style={{ color: 'var(--muted)', fontSize: 12 }}>{u.created_at?.slice(0, 10)}</td>
                        <td>
                          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                            <button
                              className="btn btn-outline btn-sm"
                              onClick={() => handleToggle(u.user_id)}
                              disabled={isSelf}
                              title={isSelf ? 'You cannot deactivate your own account' : ''}
                              style={isSelf ? { opacity: 0.4, cursor: 'not-allowed' } : {}}>
                              {u.is_active ? 'Deactivate' : 'Activate'}
                            </button>
                            <button className="btn btn-outline btn-sm"
                              onClick={() => { setResetPwd({ id: u.user_id, name: u.full_name }); setNewPwd(''); }}>
                              Reset Pwd
                            </button>
                            {/* Delete only allowed for inactive non-self users */}
                            {!u.is_active && !isSelf && (
                              <button
                                className="btn btn-sm"
                                style={{ background: '#991b1b', color: '#fff', border: 'none' }}
                                onClick={() => setConfirmDelete({ id: u.user_id, name: u.full_name })}>
                                Delete
                              </button>
                            )}
                            {u.is_active && !isSelf && (
                              <span style={{ color: '#64748b', fontSize: 11, alignSelf: 'center' }}>
                                (deactivate first to delete)
                              </span>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <p style={{ color: '#64748b', fontSize: 12, marginTop: 10, padding: '0 4px' }}>
              ℹ️ Deactivated users cannot log in. Their data (registrations, notes, sessions) is fully preserved. Mentors' assigned teens remain available for reassignment in the Mentors tab.
            </p>
          </div>
        </>
      )}

      {/* ── Deleted Users Tab ─────────────────────────────────────────────────── */}
      {tab === 'deleted' && (
        <div className="card">
          {deletedUsers.length === 0 ? (
            <p style={{ color: '#64748b', textAlign: 'center', padding: 24 }}>No deleted users. All users are in the active list.</p>
          ) : (
            <>
              <p style={{ color: '#94a3b8', fontSize: 13, marginBottom: 12 }}>
                These users have been deleted but all their data (registrations, notes, session records) is still fully preserved in the database. Restoring a user reactivates their account so they can log in again with the same role and credentials.
              </p>
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>Full Name</th>
                      <th>Username</th>
                      <th>Role</th>
                      <th>Deleted On</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {deletedUsers.map((u: any) => (
                      <tr key={u.user_id}>
                        <td><strong style={{ color: '#94a3b8' }}>{u.full_name}</strong></td>
                        <td><code style={{ color: '#64748b' }}>{u.username}</code></td>
                        <td><span className={`badge ${roleBadgeClass(u.role)}`} style={{ opacity: 0.6 }}>{u.role}</span></td>
                        <td style={{ color: 'var(--muted)', fontSize: 12 }}>{u.deleted_at?.slice(0, 10) || '—'}</td>
                        <td>
                          <button
                            className="btn btn-sm"
                            style={{ background: '#10b981', color: '#fff', border: 'none', fontWeight: 600 }}
                            onClick={() => handleRestore(u.user_id, u.full_name)}>
                            ↩ Restore & Reactivate
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      )}

      {/* ── Reset Password Modal ──────────────────────────────────────────────── */}
      {resetPwd && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 999 }}>
          <div className="card" style={{ width: 360 }}>
            <div className="card-title">Reset Password for {resetPwd.name}</div>
            <div className="field" style={{ marginBottom: 16 }}>
              <label>New Password</label>
              <input type="password" value={newPwd} onChange={e => setNewPwd(e.target.value)}
                placeholder="Enter new password" autoFocus />
            </div>
            <div className="btn-row">
              <button className="btn btn-outline btn-sm" onClick={() => setResetPwd(null)}>Cancel</button>
              <button className="btn btn-primary btn-sm" onClick={handleResetPwd}>Set Password</button>
            </div>
          </div>
        </div>
      )}

      {/* ── Confirm Delete Modal ──────────────────────────────────────────────── */}
      {confirmDelete && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 999 }}>
          <div className="card" style={{ width: 420 }}>
            <div className="card-title" style={{ color: '#ef4444' }}>⚠️ Delete User</div>
            <p style={{ color: '#f1f5f9', marginBottom: 8 }}>
              You are about to delete <strong>{confirmDelete.name}</strong>.
            </p>
            <p style={{ color: '#94a3b8', fontSize: 13, marginBottom: 16 }}>
              Their account will be removed from the active user list, but <strong>all their data is preserved</strong> — registrations, session notes, and records remain intact. You can restore them at any time from the <em>Deleted Users</em> tab.
            </p>
            <div className="btn-row">
              <button className="btn btn-outline btn-sm" onClick={() => setConfirmDelete(null)}>Cancel</button>
              <button className="btn btn-sm" style={{ background: '#991b1b', color: '#fff', border: 'none', fontWeight: 700 }} onClick={handleDelete}>
                Yes, Delete User
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
