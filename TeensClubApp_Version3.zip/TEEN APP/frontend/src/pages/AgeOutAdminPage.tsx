import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  getApproachingTeens,
  getCompletedExtensions,
  getArchivedTeens,
  getAgeOutRequests,
  getAgeOutNotifications,
  approveAgeOutExtension,
  denyAgeOutExtension,
  extendTeenStay,
  reactivateArchivedTeen,
  markAgeOutNotificationRead,
  markAllAgeOutNotificationsRead,
  runAgeOutCheck,
} from '../api';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function fmt(date: string | null | undefined): string {
  if (!date) return '—';
  const d = new Date(date + 'T00:00:00');
  return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function daysUntil(date: string): number {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(date + 'T00:00:00');
  return Math.round((target.getTime() - today.getTime()) / 86400000);
}

function maxExtDate(dob: string): string {
  const d = new Date(dob);
  d.setFullYear(d.getFullYear() + 22);
  d.setMonth(d.getMonth() + 3);
  return d.toISOString().slice(0, 10);
}

function openDatePicker(input: HTMLInputElement) {
  const pickerInput = input as HTMLInputElement & { showPicker?: () => void };
  pickerInput.showPicker?.();
}

function preventManualDateTyping(e: React.KeyboardEvent<HTMLInputElement>) {
  if (e.key === 'Tab') return;
  e.preventDefault();
}

function preventDatePaste(e: React.ClipboardEvent<HTMLInputElement>) {
  e.preventDefault();
}

function badge(text: string, color: string) {
  return (
    <span style={{
      background: color, color: '#fff', borderRadius: 8,
      padding: '2px 8px', fontSize: 11, fontWeight: 700, marginLeft: 6,
    }}>{text}</span>
  );
}

const card: React.CSSProperties = {
  background: '#1e293b', border: '1px solid #334155',
  borderRadius: 10, padding: '14px 18px', marginBottom: 12,
};

const sectionHeader = (title: string, count: number) => (
  <h3 style={{ color: '#94a3b8', fontWeight: 600, fontSize: 14, marginBottom: 12, letterSpacing: 1, textTransform: 'uppercase' }}>
    {title}
    {count > 0 && <span style={{ marginLeft: 8, background: '#ef4444', color: '#fff', borderRadius: 10, padding: '2px 8px', fontSize: 12 }}>{count}</span>}
  </h3>
);

// ─── Tab type ─────────────────────────────────────────────────────────────────
type ActiveTab = 'approaching' | 'completed' | 'requests' | 'rejected' | 'archived' | 'notifications';

// ─── Main Component ───────────────────────────────────────────────────────────
export default function AgeOutAdminPage() {
  const navigate = useNavigate();
  const [tab, setTab] = useState<ActiveTab>('approaching');

  const [approaching, setApproaching]   = useState<any[]>([]);
  const [completed, setCompleted]       = useState<any[]>([]);
  const [requests,    setRequests]       = useState<any[]>([]);
  const [archived,    setArchived]       = useState<any[]>([]);
  const [notifs,      setNotifs]         = useState<any[]>([]);
  const [loading,     setLoading]        = useState(true);  // start true — show spinner before first fetch
  const [refreshing,  setRefreshing]     = useState(false);
  const [error,       setError]          = useState('');

  // Approve modal state
  const [approveModal, setApproveModal] = useState<{ requestId: string; maxDate: string } | null>(null);
  const [approveDate,  setApproveDate]  = useState('');
  const [approveNote,  setApproveNote]  = useState('');

  // Deny modal state
  const [denyModal, setDenyModal] = useState<{ requestId: string } | null>(null);
  const [denyNote,  setDenyNote]  = useState('');

  // Direct extend modal state
  const [extendModal, setExtendModal] = useState<{ kidId: string; maxDate: string; isArchived: boolean } | null>(null);
  const [extendDate,  setExtendDate]  = useState('');
  const [extendNote,  setExtendNote]  = useState('');

  // Reactivate modal state
  const [reactModal,  setReactModal]  = useState<{ kidId: string; maxDate: string } | null>(null);
  const [reactDate,   setReactDate]   = useState('');
  const [reactNote,   setReactNote]   = useState('');

  const [submitting, setSubmitting] = useState(false);

  const load = async (showSpinner = false) => {
    if (showSpinner) setLoading(true);
    else setRefreshing(true);
    setError('');
    try {
      const [a, c, r, ar, n] = await Promise.all([
        getApproachingTeens(),
        getCompletedExtensions(),
        getAgeOutRequests(),
        getArchivedTeens(),
        getAgeOutNotifications(),
      ]);
      setApproaching(Array.isArray(a) ? a : []);
      setCompleted(Array.isArray(c) ? c : []);
      setRequests(Array.isArray(r) ? r : []);
      setArchived(Array.isArray(ar) ? ar : []);
      setNotifs(Array.isArray(n) ? n : []);
    } catch (e: any) {
      setError(e?.response?.data?.error || 'Failed to load age-out data. Please refresh.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => { load(true); }, []);

  // ── Approve ────────────────────────────────────────────────────────────────
  const handleApprove = async () => {
    if (!approveModal || !approveDate) return;
    setSubmitting(true);
    try {
      await approveAgeOutExtension(approveModal.requestId, approveDate, approveNote || undefined);
      setApproveModal(null); setApproveDate(''); setApproveNote('');
      window.dispatchEvent(new Event('tc-refresh-counts'));
      await load(false);
    } catch (e: any) {
      alert(e.response?.data?.error || 'Failed to approve extension');
    } finally { setSubmitting(false); }
  };

  // ── Deny ───────────────────────────────────────────────────────────────────
  const handleDeny = async () => {
    if (!denyModal) return;
    setSubmitting(true);
    try {
      await denyAgeOutExtension(denyModal.requestId, denyNote || undefined);
      setDenyModal(null); setDenyNote('');
      window.dispatchEvent(new Event('tc-refresh-counts'));
      await load(false);
    } catch (e: any) {
      alert(e.response?.data?.error || 'Failed to deny extension');
    } finally { setSubmitting(false); }
  };

  // ── Direct Extend ─────────────────────────────────────────────────────────
  const handleDirectExtend = async () => {
    if (!extendModal || !extendDate) return;
    setSubmitting(true);
    try {
      await extendTeenStay(extendModal.kidId, extendDate, extendNote || undefined);
      setExtendModal(null); setExtendDate(''); setExtendNote('');
      window.dispatchEvent(new Event('tc-refresh-counts'));
      await load(false);
    } catch (e: any) {
      alert(e.response?.data?.error || 'Failed to extend teen stay');
    } finally { setSubmitting(false); }
  };

  // ── Reactivate ─────────────────────────────────────────────────────────────
  const handleReactivate = async () => {
    if (!reactModal || !reactDate) return;
    setSubmitting(true);
    try {
      await reactivateArchivedTeen(reactModal.kidId, reactDate, reactNote || undefined);
      setReactModal(null); setReactDate(''); setReactNote('');
      window.dispatchEvent(new Event('tc-refresh-counts'));
      await load(false);
    } catch (e: any) {
      alert(e.response?.data?.error || 'Failed to reactivate teen');
    } finally { setSubmitting(false); }
  };

  // ── Counts for tab badges ──────────────────────────────────────────────────
  const pendingRequests  = requests.filter(r => r.status === 'PENDING').length;
  const rejectedCount    = requests.filter(r => r.status === 'DENIED').length;
  const unreadNotifs     = notifs.filter(n => !n.is_read).length;

  // ── Tab bar ────────────────────────────────────────────────────────────────
  const tabs: { key: ActiveTab; label: string; icon: string; count?: number }[] = [
    { key: 'approaching',   label: 'Approaching 22', icon: '⚠️', count: approaching.length },
    { key: 'completed',     label: 'Completed Extensions', icon: '✅', count: completed.length },
    { key: 'requests',      label: 'Extension Requests', icon: '📋', count: pendingRequests },
    { key: 'rejected',      label: 'Rejected Requests', icon: '❌', count: rejectedCount },
    { key: 'archived',      label: 'Archived Teens', icon: '📦', count: archived.length },
    { key: 'notifications', label: 'Notifications', icon: '🔔', count: unreadNotifs },
  ];

  return (
    <div style={{ padding: '20px 16px', maxWidth: 900, margin: '0 auto' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <h2 style={{ color: '#f1f5f9', fontWeight: 700, fontSize: 22, margin: 0 }}>⏰ Age-Out Management</h2>
        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={() => { runAgeOutCheck().then(() => load(false)).catch(() => {}); }} disabled={refreshing}
            style={{ background: '#334155', color: '#94a3b8', border: 'none', borderRadius: 8, padding: '6px 12px', fontSize: 12, cursor: 'pointer' }}>
            Run Check Now
          </button>
          <button onClick={() => load(false)} disabled={refreshing}
            style={{ background: '#334155', color: '#94a3b8', border: 'none', borderRadius: 8, padding: '6px 12px', fontSize: 12, cursor: 'pointer' }}>
            {refreshing ? 'Refreshing…' : 'Refresh'}
          </button>
        </div>
      </div>

      {error && <div style={{ background: '#7f1d1d', color: '#fca5a5', padding: '10px 14px', borderRadius: 8, marginBottom: 16 }}>{error}</div>}

      {/* Tab bar */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 20, flexWrap: 'wrap' }}>
        {tabs.map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            style={{
              padding: '8px 16px', borderRadius: 8, border: 'none', cursor: 'pointer', fontSize: 13, fontWeight: 600,
              background: tab === t.key ? '#3b82f6' : '#1e293b',
              color: tab === t.key ? '#fff' : '#94a3b8',
            }}>
            {t.icon} {t.label}
            {(t.count ?? 0) > 0 && (
              <span style={{ marginLeft: 6, background: '#ef4444', color: '#fff', borderRadius: 10, padding: '1px 6px', fontSize: 11 }}>{t.count}</span>
            )}
          </button>
        ))}
      </div>

      {loading && approaching.length === 0 && completed.length === 0 && requests.length === 0 && archived.length === 0 && notifs.length === 0 && (
        <div style={{ color: '#94a3b8', textAlign: 'center', padding: 24 }}>Loading…</div>
      )}

      {/* ── Approaching 22 Tab ────────────────────────────────────────────── */}
      {!loading && tab === 'approaching' && (
        <div>
          {sectionHeader('Teens Approaching or Needing Attention', approaching.length)}
          {approaching.length === 0 && (
            <p style={{ color: '#64748b', textAlign: 'center', padding: 24 }}>No teens currently approaching 22. Great!</p>
          )}
          {approaching.map(teen => {
            const d2 = daysUntil(teen.birthday_22);
            const isArchived = teen.is_archived;
            const hasExt = !!teen.extension_expires_at;
            const hasPending = !!teen.pending_request;
            const daysToExtExpiry = hasExt ? daysUntil(teen.extension_expires_at) : null;
            const canExtend = !teen.is_permanently_archived && teen.extension_count < 2 && (
              !hasExt || isArchived || hasPending || (daysToExtExpiry !== null && daysToExtExpiry <= 7)
            );
            return (
              <div key={teen.kid_id} style={card}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 8 }}>
                  <div>
                    <span style={{ color: '#f1f5f9', fontWeight: 700, fontSize: 16 }}>
                      {teen.first_name} {teen.last_name}
                    </span>
                    {isArchived && badge('ARCHIVED', '#64748b')}
                    {hasExt && !isArchived && badge('EXTENDED', '#10b981')}
                    {!isArchived && !hasExt && d2 <= 7  && badge(`${d2}d left`, '#ef4444')}
                    {!isArchived && !hasExt && d2 > 7 && d2 <= 14 && badge(`${d2}d left`, '#f97316')}
                    {!isArchived && !hasExt && d2 > 14  && badge(`${d2}d left`, '#eab308')}
                  </div>
                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                    <button onClick={() => navigate(`/kid/${teen.kid_id}`)}
                      style={{ background: '#334155', color: '#94a3b8', border: 'none', borderRadius: 6, padding: '4px 10px', fontSize: 12, cursor: 'pointer' }}>
                      View Profile
                    </button>
                    {canExtend && (
                      <button
                        onClick={() => {
                          setExtendModal({ kidId: teen.kid_id, maxDate: maxExtDate(teen.dob), isArchived });
                          setExtendDate(teen.pending_request?.requested_expiry_date || teen.extension_expires_at || '');
                          setExtendNote('');
                        }}
                        style={{ background: '#10b981', color: '#fff', border: 'none', borderRadius: 6, padding: '4px 10px', fontSize: 12, cursor: 'pointer', fontWeight: 600 }}>
                        Extend Stay
                      </button>
                    )}
                  </div>
                </div>
                <div style={{ marginTop: 8, color: '#94a3b8', fontSize: 13, display: 'flex', gap: 20, flexWrap: 'wrap' }}>
                  <span>DOB: {fmt(teen.dob)}</span>
                  <span>22nd birthday: {fmt(teen.birthday_22)}</span>
                  {teen.mentor_name && <span>Mentor: {teen.mentor_name}</span>}
                  <span>Extensions used: {teen.extension_count}/2</span>
                  {hasExt && <span>Extension expires: {fmt(teen.extension_expires_at)}</span>}
                </div>
                {teen.pending_request && (
                  <div style={{ marginTop: 8, background: '#0f172a', borderRadius: 6, padding: '6px 10px', fontSize: 12, color: '#fbbf24' }}>
                    ⏳ Pending extension request to {fmt(teen.pending_request.requested_expiry_date)}
                  </div>
                )}

                {!canExtend && hasExt && !hasPending && !isArchived && daysToExtExpiry !== null && daysToExtExpiry > 7 && teen.extension_count < 2 && (
                  <div style={{ marginTop: 8, background: '#0f172a', borderRadius: 6, padding: '6px 10px', fontSize: 12, color: '#93c5fd' }}>
                    Direct admin extension is enabled only in the last 7 days before expiry ({fmt(teen.extension_expires_at)}) unless a mentor request is pending.
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* ── Completed Extensions Tab ─────────────────────────────────────── */}
      {!loading && tab === 'completed' && (
        <div>
          {sectionHeader('Completed Extensions', completed.length)}
          {completed.length === 0 && (
            <p style={{ color: '#64748b', textAlign: 'center', padding: 24 }}>No active extension records.</p>
          )}
          {completed.map(teen => {
            const daysToExtExpiry = teen.extension_expires_at ? daysUntil(teen.extension_expires_at) : null;
            const canExtend = teen.extension_count < 2 && daysToExtExpiry !== null && daysToExtExpiry <= 7;
            return (
              <div key={teen.kid_id} style={card}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 8 }}>
                  <div>
                    <span style={{ color: '#f1f5f9', fontWeight: 700, fontSize: 16 }}>
                      {teen.first_name} {teen.last_name}
                    </span>
                    {badge('EXTENDED', '#10b981')}
                  </div>
                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                    <button onClick={() => navigate(`/kid/${teen.kid_id}`)}
                      style={{ background: '#334155', color: '#94a3b8', border: 'none', borderRadius: 6, padding: '4px 10px', fontSize: 12, cursor: 'pointer' }}>
                      View Profile
                    </button>
                    {canExtend && (
                      <button
                        onClick={() => {
                          setExtendModal({ kidId: teen.kid_id, maxDate: maxExtDate(teen.dob), isArchived: false });
                          setExtendDate(teen.extension_expires_at || '');
                          setExtendNote('');
                        }}
                        style={{ background: '#10b981', color: '#fff', border: 'none', borderRadius: 6, padding: '4px 10px', fontSize: 12, cursor: 'pointer', fontWeight: 600 }}>
                        Extend Stay
                      </button>
                    )}
                  </div>
                </div>
                <div style={{ marginTop: 8, color: '#94a3b8', fontSize: 13, display: 'flex', gap: 20, flexWrap: 'wrap' }}>
                  <span>DOB: {fmt(teen.dob)}</span>
                  <span>22nd birthday: {fmt(teen.birthday_22)}</span>
                  <span>Extension expires: {fmt(teen.extension_expires_at)}</span>
                  <span>Extensions used: {teen.extension_count}/2</span>
                  {teen.mentor_name && <span>Mentor: {teen.mentor_name}</span>}
                </div>
                {!canExtend && teen.extension_count < 2 && daysToExtExpiry !== null && daysToExtExpiry > 7 && (
                  <div style={{ marginTop: 8, background: '#0f172a', borderRadius: 6, padding: '6px 10px', fontSize: 12, color: '#93c5fd' }}>
                    Another extension can be applied only in the last 7 days before expiry.
                  </div>
                )}
                {teen.extension_count >= 2 && (
                  <div style={{ marginTop: 8, background: '#450a0a', borderRadius: 6, padding: '6px 10px', fontSize: 12, color: '#fca5a5' }}>
                    Maximum 2 extensions used. No further extension is allowed.
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* ── Extension Requests Tab ────────────────────────────────────────── */}
      {!loading && tab === 'requests' && (
        <div>
          {sectionHeader('Extension Requests', pendingRequests)}
          {requests.filter(r => r.status === 'PENDING').length === 0 && (
            <p style={{ color: '#64748b', textAlign: 'center', padding: 24 }}>No extension requests yet.</p>
          )}
          {requests.filter(r => r.status === 'PENDING').map(req => (
            <div key={req.request_id} style={{ ...card, borderColor: req.status === 'PENDING' ? '#fbbf24' : '#334155' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 8 }}>
                <div>
                  <span style={{ color: '#f1f5f9', fontWeight: 700, fontSize: 15 }}>
                    {req.first_name} {req.last_name}
                  </span>
                  {req.status === 'PENDING'  && badge('PENDING',  '#fbbf24')}
                  {req.status === 'APPROVED' && badge('APPROVED', '#10b981')}
                  {req.status === 'DENIED'   && badge('DENIED',   '#ef4444')}
                </div>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  <button onClick={() => navigate(`/kid/${req.kid_id}`)}
                    style={{ background: '#334155', color: '#94a3b8', border: 'none', borderRadius: 6, padding: '5px 12px', fontSize: 12, cursor: 'pointer' }}>
                    View Profile
                  </button>
                  {req.status === 'PENDING' && (
                    <>
                      <button
                        onClick={() => { setApproveModal({ requestId: req.request_id, maxDate: maxExtDate(req.dob) }); setApproveDate(req.requested_expiry_date); }}
                        style={{ background: '#10b981', color: '#fff', border: 'none', borderRadius: 6, padding: '5px 12px', fontSize: 12, cursor: 'pointer', fontWeight: 600 }}>
                        ✓ Approve
                      </button>
                      <button
                        onClick={() => setDenyModal({ requestId: req.request_id })}
                        style={{ background: '#ef4444', color: '#fff', border: 'none', borderRadius: 6, padding: '5px 12px', fontSize: 12, cursor: 'pointer', fontWeight: 600 }}>
                        ✕ Deny
                      </button>
                    </>
                  )}
                </div>
              </div>
              <div style={{ marginTop: 8, color: '#94a3b8', fontSize: 13, display: 'flex', gap: 20, flexWrap: 'wrap' }}>
                <span>22nd birthday: {fmt(req.birthday_22)}</span>
                <span>Requested until: <strong style={{ color: '#f1f5f9' }}>{fmt(req.requested_expiry_date)}</strong></span>
                <span>Requested by: {req.requested_by_name}</span>
                <span>Max allowed: {fmt(maxExtDate(req.dob))}</span>
              </div>
              {req.approved_expiry_date && (
                <div style={{ marginTop: 6, color: '#10b981', fontSize: 12 }}>
                  Approved until {fmt(req.approved_expiry_date)}{req.admin_note ? ` — "${req.admin_note}"` : ''}
                </div>
              )}
              {req.status === 'DENIED' && req.admin_note && (
                <div style={{ marginTop: 6, color: '#ef4444', fontSize: 12 }}>Denied — "{req.admin_note}"</div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* ── Rejected Requests Tab ─────────────────────────────────────────── */}
      {!loading && tab === 'rejected' && (
        <div>
          {sectionHeader('Rejected Requests', rejectedCount)}
          {requests.filter(r => r.status === 'DENIED').length === 0 && (
            <p style={{ color: '#64748b', textAlign: 'center', padding: 24 }}>No rejected requests.</p>
          )}
          {requests.filter(r => r.status === 'DENIED').map(req => (
            <div key={req.request_id} style={{ ...card, borderColor: '#7f1d1d' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 8 }}>
                <div>
                  <span style={{ color: '#f1f5f9', fontWeight: 700, fontSize: 15 }}>
                    {req.first_name} {req.last_name}
                  </span>
                  {badge('DENIED', '#ef4444')}
                </div>
                <button onClick={() => navigate(`/kid/${req.kid_id}`)}
                  style={{ background: '#334155', color: '#94a3b8', border: 'none', borderRadius: 6, padding: '5px 12px', fontSize: 12, cursor: 'pointer' }}>
                  View Profile
                </button>
              </div>
              <div style={{ marginTop: 8, color: '#94a3b8', fontSize: 13, display: 'flex', gap: 20, flexWrap: 'wrap' }}>
                <span>22nd birthday: {fmt(req.birthday_22)}</span>
                <span>Requested until: {fmt(req.requested_expiry_date)}</span>
                <span>Requested by: {req.requested_by_name}</span>
              </div>
              {req.admin_note && (
                <div style={{ marginTop: 6, color: '#ef4444', fontSize: 12 }}>Denied — "{req.admin_note}"</div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* ── Archived Teens Tab ────────────────────────────────────────────── */}
      {!loading && tab === 'archived' && (
        <div>
          {sectionHeader('Archived Teens', archived.length)}
          {archived.length === 0 && (
            <p style={{ color: '#64748b', textAlign: 'center', padding: 24 }}>No archived teens.</p>
          )}
          {archived.map(teen => (
            <div key={teen.kid_id} style={card}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 8 }}>
                <div>
                  <span style={{ color: '#f1f5f9', fontWeight: 700, fontSize: 15 }}>
                    {teen.first_name} {teen.last_name}
                  </span>
                  {teen.is_permanently_archived
                    ? badge('PERMANENTLY ARCHIVED', '#7f1d1d')
                    : badge('ARCHIVED', '#64748b')}
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button onClick={() => navigate(`/kid/${teen.kid_id}`)}
                    style={{ background: '#334155', color: '#94a3b8', border: 'none', borderRadius: 6, padding: '4px 10px', fontSize: 12, cursor: 'pointer' }}>
                    View
                  </button>
                  {!teen.is_permanently_archived && teen.extension_count < 2 && (
                    <button
                      onClick={() => { setReactModal({ kidId: teen.kid_id, maxDate: maxExtDate(teen.dob) }); setReactDate(''); }}
                      style={{ background: '#10b981', color: '#fff', border: 'none', borderRadius: 6, padding: '4px 10px', fontSize: 12, cursor: 'pointer', fontWeight: 600 }}>
                      Reactivate
                    </button>
                  )}
                </div>
              </div>
              <div style={{ marginTop: 8, color: '#94a3b8', fontSize: 13, display: 'flex', gap: 20, flexWrap: 'wrap' }}>
                <span>DOB: {fmt(teen.dob)}</span>
                <span>22nd birthday: {fmt(teen.birthday_22)}</span>
                <span>Archived: {fmt(teen.archived_at)}</span>
                <span>Reason: {teen.archive_reason?.replace(/_/g, ' ') || '—'}</span>
                <span>Extensions: {teen.extension_count}/2</span>
                {teen.mentor_name && <span>Mentor: {teen.mentor_name}</span>}
              </div>
              {teen.is_permanently_archived && (
                <div style={{ marginTop: 8, background: '#450a0a', borderRadius: 6, padding: '6px 10px', fontSize: 12, color: '#fca5a5' }}>
                  This teen has used both extensions and is permanently archived. No further action is possible.
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* ── Notifications Tab ─────────────────────────────────────────────── */}
      {!loading && tab === 'notifications' && (
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            {sectionHeader('Notifications', unreadNotifs)}
            {unreadNotifs > 0 && (
              <button
                onClick={() => markAllAgeOutNotificationsRead().then(() => load(false))}
                style={{ background: '#334155', color: '#94a3b8', border: 'none', borderRadius: 6, padding: '4px 10px', fontSize: 12, cursor: 'pointer' }}>
                Mark All Read
              </button>
            )}
          </div>
          {notifs.length === 0 && (
            <p style={{ color: '#64748b', textAlign: 'center', padding: 24 }}>No notifications yet.</p>
          )}
          {notifs.map(n => (
            <div key={n.notification_id}
              onClick={() => { if (!n.is_read) markAgeOutNotificationRead(n.notification_id).then(() => load(false)); }}
              style={{
                ...card,
                opacity: n.is_read ? 0.55 : 1,
                borderColor: n.is_read ? '#334155' : '#3b82f6',
                cursor: n.is_read ? 'default' : 'pointer',
              }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
                <div style={{ color: '#f1f5f9', fontSize: 14 }}>{n.message}</div>
                {!n.is_read && <span style={{ color: '#3b82f6', fontSize: 11, whiteSpace: 'nowrap' }}>● Unread</span>}
              </div>
              <div style={{ marginTop: 6, color: '#64748b', fontSize: 12 }}>
                {n.notification_type?.replace(/_/g, ' ')} · {new Date(n.created_at).toLocaleString()}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── Approve Modal ─────────────────────────────────────────────────── */}
      {approveModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
          <div style={{ background: '#1e293b', borderRadius: 12, padding: 28, width: 380, maxWidth: '93vw' }}>
            <h3 style={{ color: '#f1f5f9', marginTop: 0 }}>Approve Extension</h3>
            <label style={{ color: '#94a3b8', fontSize: 13, display: 'block', marginBottom: 6 }}>
              Extension Expiry Date <span style={{ color: '#64748b' }}>(max: {fmt(approveModal.maxDate)})</span>
            </label>
            <input type="date"
              value={approveDate}
              min={new Date().toISOString().slice(0, 10)}
              max={approveModal.maxDate}
              onChange={e => setApproveDate(e.target.value)}
              onFocus={e => openDatePicker(e.currentTarget)}
              onClick={e => openDatePicker(e.currentTarget)}
              onKeyDown={preventManualDateTyping}
              onPaste={preventDatePaste}
              inputMode="none"
              style={{ width: '100%', background: '#0f172a', color: '#f1f5f9', border: '1px solid #334155', borderRadius: 6, padding: '8px 10px', fontSize: 14, boxSizing: 'border-box' }}
            />
            <label style={{ color: '#94a3b8', fontSize: 13, display: 'block', marginTop: 14, marginBottom: 6 }}>Note (optional)</label>
            <input type="text"
              value={approveNote}
              onChange={e => setApproveNote(e.target.value)}
              placeholder="Message to mentor…"
              style={{ width: '100%', background: '#0f172a', color: '#f1f5f9', border: '1px solid #334155', borderRadius: 6, padding: '8px 10px', fontSize: 14, boxSizing: 'border-box' }}
            />
            <div style={{ display: 'flex', gap: 10, marginTop: 20 }}>
              <button onClick={handleApprove} disabled={!approveDate || submitting}
                style={{ flex: 1, background: '#10b981', color: '#fff', border: 'none', borderRadius: 8, padding: '9px 0', fontWeight: 700, fontSize: 14, cursor: 'pointer' }}>
                {submitting ? 'Saving…' : 'Approve'}
              </button>
              <button onClick={() => { setApproveModal(null); setApproveDate(''); setApproveNote(''); }}
                style={{ flex: 1, background: '#334155', color: '#94a3b8', border: 'none', borderRadius: 8, padding: '9px 0', fontSize: 14, cursor: 'pointer' }}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Direct Extend Modal ───────────────────────────────────────────── */}
      {extendModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
          <div style={{ background: '#1e293b', borderRadius: 12, padding: 28, width: 380, maxWidth: '93vw' }}>
            <h3 style={{ color: '#f1f5f9', marginTop: 0 }}>{extendModal.isArchived ? 'Reactivate And Extend' : 'Extend Teen Stay'}</h3>
            <p style={{ color: '#94a3b8', fontSize: 13, marginTop: 0 }}>
              Select the final active date from the calendar. Manual typing is disabled and the limit is capped at 3 months after the 22nd birthday.
            </p>
            <label style={{ color: '#94a3b8', fontSize: 13, display: 'block', marginBottom: 6 }}>
              Active Until <span style={{ color: '#64748b' }}>(max: {fmt(extendModal.maxDate)})</span>
            </label>
            <input type="date"
              value={extendDate}
              min={new Date().toISOString().slice(0, 10)}
              max={extendModal.maxDate}
              onChange={e => setExtendDate(e.target.value)}
              onFocus={e => openDatePicker(e.currentTarget)}
              onClick={e => openDatePicker(e.currentTarget)}
              onKeyDown={preventManualDateTyping}
              onPaste={preventDatePaste}
              inputMode="none"
              style={{ width: '100%', background: '#0f172a', color: '#f1f5f9', border: '1px solid #334155', borderRadius: 6, padding: '8px 10px', fontSize: 14, boxSizing: 'border-box' }}
            />
            <label style={{ color: '#94a3b8', fontSize: 13, display: 'block', marginTop: 14, marginBottom: 6 }}>Note (optional)</label>
            <input type="text"
              value={extendNote}
              onChange={e => setExtendNote(e.target.value)}
              placeholder="Reason for extension…"
              style={{ width: '100%', background: '#0f172a', color: '#f1f5f9', border: '1px solid #334155', borderRadius: 6, padding: '8px 10px', fontSize: 14, boxSizing: 'border-box' }}
            />
            <div style={{ display: 'flex', gap: 10, marginTop: 20 }}>
              <button onClick={handleDirectExtend} disabled={!extendDate || submitting}
                style={{ flex: 1, background: '#10b981', color: '#fff', border: 'none', borderRadius: 8, padding: '9px 0', fontWeight: 700, fontSize: 14, cursor: 'pointer' }}>
                {submitting ? 'Saving…' : 'Extend Stay'}
              </button>
              <button onClick={() => { setExtendModal(null); setExtendDate(''); setExtendNote(''); }}
                style={{ flex: 1, background: '#334155', color: '#94a3b8', border: 'none', borderRadius: 8, padding: '9px 0', fontSize: 14, cursor: 'pointer' }}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Deny Modal ────────────────────────────────────────────────────── */}
      {denyModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
          <div style={{ background: '#1e293b', borderRadius: 12, padding: 28, width: 380, maxWidth: '93vw' }}>
            <h3 style={{ color: '#f1f5f9', marginTop: 0 }}>Deny Extension</h3>
            <label style={{ color: '#94a3b8', fontSize: 13, display: 'block', marginBottom: 6 }}>Reason / Note (optional)</label>
            <input type="text"
              value={denyNote}
              onChange={e => setDenyNote(e.target.value)}
              placeholder="Reason for denial…"
              style={{ width: '100%', background: '#0f172a', color: '#f1f5f9', border: '1px solid #334155', borderRadius: 6, padding: '8px 10px', fontSize: 14, boxSizing: 'border-box' }}
            />
            <div style={{ display: 'flex', gap: 10, marginTop: 20 }}>
              <button onClick={handleDeny} disabled={submitting}
                style={{ flex: 1, background: '#ef4444', color: '#fff', border: 'none', borderRadius: 8, padding: '9px 0', fontWeight: 700, fontSize: 14, cursor: 'pointer' }}>
                {submitting ? 'Saving…' : 'Deny'}
              </button>
              <button onClick={() => { setDenyModal(null); setDenyNote(''); }}
                style={{ flex: 1, background: '#334155', color: '#94a3b8', border: 'none', borderRadius: 8, padding: '9px 0', fontSize: 14, cursor: 'pointer' }}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Reactivate Modal ──────────────────────────────────────────────── */}
      {reactModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
          <div style={{ background: '#1e293b', borderRadius: 12, padding: 28, width: 380, maxWidth: '93vw' }}>
            <h3 style={{ color: '#f1f5f9', marginTop: 0 }}>Reactivate Teen</h3>
            <p style={{ color: '#94a3b8', fontSize: 13, marginTop: 0 }}>
              This grants an extension and reactivates the teen's record. Max date is 3 months after the 22nd birthday.
            </p>
            <label style={{ color: '#94a3b8', fontSize: 13, display: 'block', marginBottom: 6 }}>
              Active Until <span style={{ color: '#64748b' }}>(max: {fmt(reactModal.maxDate)})</span>
            </label>
            <input type="date"
              value={reactDate}
              min={new Date().toISOString().slice(0, 10)}
              max={reactModal.maxDate}
              onChange={e => setReactDate(e.target.value)}
              onFocus={e => openDatePicker(e.currentTarget)}
              onClick={e => openDatePicker(e.currentTarget)}
              onKeyDown={preventManualDateTyping}
              onPaste={preventDatePaste}
              inputMode="none"
              style={{ width: '100%', background: '#0f172a', color: '#f1f5f9', border: '1px solid #334155', borderRadius: 6, padding: '8px 10px', fontSize: 14, boxSizing: 'border-box' }}
            />
            <label style={{ color: '#94a3b8', fontSize: 13, display: 'block', marginTop: 14, marginBottom: 6 }}>Note (optional)</label>
            <input type="text"
              value={reactNote}
              onChange={e => setReactNote(e.target.value)}
              placeholder="Reason for reactivation…"
              style={{ width: '100%', background: '#0f172a', color: '#f1f5f9', border: '1px solid #334155', borderRadius: 6, padding: '8px 10px', fontSize: 14, boxSizing: 'border-box' }}
            />
            <div style={{ display: 'flex', gap: 10, marginTop: 20 }}>
              <button onClick={handleReactivate} disabled={!reactDate || submitting}
                style={{ flex: 1, background: '#10b981', color: '#fff', border: 'none', borderRadius: 8, padding: '9px 0', fontWeight: 700, fontSize: 14, cursor: 'pointer' }}>
                {submitting ? 'Saving…' : 'Reactivate'}
              </button>
              <button onClick={() => { setReactModal(null); setReactDate(''); setReactNote(''); }}
                style={{ flex: 1, background: '#334155', color: '#94a3b8', border: 'none', borderRadius: 8, padding: '9px 0', fontSize: 14, cursor: 'pointer' }}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
