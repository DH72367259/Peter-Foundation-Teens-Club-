#!/bin/bash
# ======================================================
#   Teen's Club Registration System - Mac Server Start
# ======================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo " ======================================================"
echo "   Teen's Club Registration System - Starting Server"
echo " ======================================================"
echo ""

# ─── OPTIONAL: Set a custom iCloud / Google Drive backup path ────────────────
# If auto-detection doesn't find your cloud folder, uncomment and set below:
#
# export GDRIVE_BACKUP_PATH="$HOME/Library/Mobile Documents/com~apple~CloudDocs/TeensClub Backups"
#
# Common paths on macOS:
#   iCloud Drive:       $HOME/Library/Mobile Documents/com~apple~CloudDocs
#   Google Drive:       $HOME/Library/CloudStorage/GoogleDrive-you@gmail.com/My Drive
#   OneDrive:           $HOME/Library/CloudStorage/OneDrive-Personal
#   Local fallback:     $SCRIPT_DIR/backend/data/backups/
# ─────────────────────────────────────────────────────────────────────────────

cd "$SCRIPT_DIR/backend" || { echo " ERROR: backend folder not found."; exit 1; }

# ── Install backend dependencies if missing ──────────────────────────────────
if [ ! -d "node_modules" ]; then
    echo " [SETUP] First-time setup: installing backend packages..."
    echo " This may take 2-3 minutes. Please wait..."
    echo ""
    npm install
    if [ $? -ne 0 ]; then
        echo ""
        echo " ERROR: npm install failed. Make sure Node.js is installed."
        echo " Download from: https://nodejs.org"
        read -p " Press Enter to exit..."
        exit 1
    fi
    echo ""
    echo " [SETUP] Backend packages installed successfully!"
    echo ""
fi

# ── Build backend TypeScript if compiled output is missing ───────────────────
if [ ! -f "dist/server.js" ]; then
    echo " [SETUP] Compiling backend TypeScript..."
    npm run build
    if [ $? -ne 0 ]; then
        echo ""
        echo " ERROR: Backend build failed. Check TypeScript errors above."
        read -p " Press Enter to exit..."
        exit 1
    fi
    echo " [SETUP] Backend compiled successfully!"
    echo ""
fi

# ── Build frontend (React) if dist folder is missing ─────────────────────────
if [ ! -d "$SCRIPT_DIR/frontend/dist" ]; then
    echo " [SETUP] First-time setup: building the UI..."
    cd "$SCRIPT_DIR/frontend" || { echo " ERROR: frontend folder not found."; exit 1; }
    if [ ! -d "node_modules" ]; then
        echo " Installing frontend packages..."
        npm install
    fi
    npm run build
    if [ $? -ne 0 ]; then
        echo " ERROR: Frontend build failed."
        read -p " Press Enter to exit..."
        exit 1
    fi
    echo " [SETUP] UI built successfully!"
    echo ""
    cd "$SCRIPT_DIR/backend" || exit 1
fi

# ── Display network IP so other devices can connect ──────────────────────────
echo " Starting server on port 3001..."
echo " Open your browser and go to: http://localhost:3001"
echo ""
echo " To share with other Macs / devices on the same WiFi:"

# Get local IP address (ignore loopback / docker interfaces)
LOCAL_IP=$(ifconfig | grep "inet " | grep -v "127.0.0.1" | grep -v "169.254" | awk '{print $2}' | head -1)
if [ -n "$LOCAL_IP" ]; then
    echo " Other devices can access: http://$LOCAL_IP:3001"
else
    echo " (Could not detect your local IP — run 'ifconfig en0' to find it)"
fi

echo ""
echo " Keep this Terminal window open while using the app."
echo " To stop the server press Ctrl+C"
echo " ======================================================"
echo ""

# ── Free port 3001 if an older instance is still running ────────────────────
PORT_PIDS=$(lsof -ti tcp:3001 -sTCP:LISTEN 2>/dev/null)
if [ -n "$PORT_PIDS" ]; then
    echo " [INFO] Port 3001 is already in use by PID(s): $(echo "$PORT_PIDS" | tr '\n' ' ')"
    for PID in $PORT_PIDS; do
        RUNNING_CMD=$(ps -p "$PID" -o command= 2>/dev/null)
        if ! echo "$RUNNING_CMD" | grep -q "node"; then
            echo " ERROR: Port 3001 is being used by another application: $RUNNING_CMD"
            echo " Please stop that application or change the port, then run this script again."
            exit 1
        fi
    done

    echo " [INFO] Stopping the existing server process(es) and restarting cleanly..."
    for PID in $PORT_PIDS; do
        kill "$PID" 2>/dev/null
    done

    for _ in 1 2 3 4 5 6 7 8 9 10; do
        if ! lsof -ti tcp:3001 -sTCP:LISTEN >/dev/null 2>&1; then
            break
        fi
        sleep 1
    done

    if lsof -ti tcp:3001 -sTCP:LISTEN >/dev/null 2>&1; then
        echo " [INFO] Existing process is still shutting down. Forcing stop..."
        for PID in $(lsof -ti tcp:3001 -sTCP:LISTEN 2>/dev/null); do
            kill -9 "$PID" 2>/dev/null
        done
        sleep 1
    fi

    if lsof -ti tcp:3001 -sTCP:LISTEN >/dev/null 2>&1; then
        echo " ERROR: Could not free port 3001. Please try again."
        exit 1
    fi
fi

# ── Start the server ─────────────────────────────────────────────────────────
node dist/server.js

echo ""
echo " Server stopped."
