#!/usr/bin/env bash
# ─── Peter Foundation Teens Club — Regression Test Suite ────────────────────
# Usage:  bash test-regression.sh [SERVER_URL]
# Default server: http://localhost:3001

BASE="${1:-http://localhost:3001}/api"
PASS=0; FAIL=0; SKIP=0
ADMIN_TOKEN=""
DE_TOKEN=""
MENTOR_TOKEN=""
SL_TOKEN=""
KID_ID=""
KID_ID2=""
USER_ID_DE=""
USER_ID_MENTOR=""
TSTAMP=$(date +%s)
DE_USER="de_${TSTAMP}"
MENTOR_USER="mn_${TSTAMP}"
SL_USER="sl_${TSTAMP}"
PHONE1="$TSTAMP"
PHONE2="$((TSTAMP + 1))"
PHONE3="$((TSTAMP + 2))"

# ── helpers ──────────────────────────────────────────────────────────────────
green(){ echo -e "\033[32m✅  $1\033[0m"; }
red(){   echo -e "\033[31m❌  $1\033[0m"; }
yellow(){ echo -e "\033[33m⚠️   $1\033[0m"; }

assert_ok(){
  local label="$1" code="$2"
  if [[ "$code" =~ ^[0-9]+$ ]] && [ "$code" -ge 200 ] && [ "$code" -lt 300 ]; then
    green "$label (HTTP $code)"; ((PASS++))
  else
    red "$label (HTTP $code — expected 2xx)"; ((FAIL++))
  fi
}
assert_status(){
  local label="$1" expected="$2" actual="$3"
  if [[ "$actual" =~ ^[0-9]+$ ]] && [ "$actual" -eq "$expected" ]; then
    green "$label (HTTP $actual)"; ((PASS++))
  else
    red "$label (HTTP $actual — expected $expected)"; ((FAIL++))
  fi
}

# GET — returns HTTP code
do_get(){
  curl -s -o /dev/null -w "%{http_code}" \
    -H "Authorization: Bearer $1" \
    "$2"
}
# GET — returns body
do_get_body(){
  curl -s \
    -H "Authorization: Bearer $1" \
    "$2"
}
# POST with JSON body — returns HTTP code
do_post(){
  local token="$1" url="$2" body="$3"
  if [ -z "$body" ]; then body='{}'; fi
  curl -s -o /dev/null -w "%{http_code}" -X POST \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer $token" \
    -d "$body" \
    "$url"
}
# POST with JSON body — returns body
do_post_body(){
  local token="$1" url="$2" body="$3"
  if [ -z "$body" ]; then body='{}'; fi
  curl -s -X POST \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer $token" \
    -d "$body" \
    "$url"
}
# PUT with JSON body — returns HTTP code
do_put(){
  local token="$1" url="$2" body="$3"
  if [ -z "$body" ]; then body='{}'; fi
  curl -s -o /dev/null -w "%{http_code}" -X PUT \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer $token" \
    -d "$body" \
    "$url"
}
# DELETE — returns HTTP code
do_del(){
  local token="$1" url="$2"
  curl -s -o /dev/null -w "%{http_code}" -X DELETE \
    -H "Authorization: Bearer $token" \
    "$url"
}

# ─── Health ──────────────────────────────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════════════════"
echo "  Peter Foundation Teens Club — Regression Tests"
echo "  Server: $BASE"
echo "═══════════════════════════════════════════════════════"
echo ""
echo "── [1] Health check"
code=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/health")
assert_ok "GET /api/health" "$code"

# ─── Auth / Login ────────────────────────────────────────────────────────────
echo ""
echo "── [2] Authentication"

resp=$(curl -s -X POST -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"Admin@1234"}' \
  "$BASE/auth/login")
ADMIN_TOKEN=$(echo "$resp" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('token',''))" 2>/dev/null)
if [ -n "$ADMIN_TOKEN" ]; then
  green "Admin login — token received"; ((PASS++))
else
  red "Admin login FAILED — no token"
  echo "  Response: $resp"
  ((FAIL++))
fi

code=$(curl -s -o /dev/null -w "%{http_code}" -X POST \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"wrongpass"}' \
  "$BASE/auth/login")
assert_status "POST /auth/login with wrong password returns 401" 401 "$code"

# ─── Create Users ────────────────────────────────────────────────────────────
echo ""
echo "── [3] Create users via admin"

resp_de=$(do_post_body "$ADMIN_TOKEN" "$BASE/auth/users" \
  "{\"username\":\"$DE_USER\",\"password\":\"Test@1234\",\"full_name\":\"DE $TSTAMP\",\"role\":\"DATA_ENTRY\"}")
USER_ID_DE=$(echo "$resp_de" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('user_id',''))" 2>/dev/null)
[ -n "$USER_ID_DE" ] && { green "Created DATA_ENTRY user (id=$USER_ID_DE)"; ((PASS++)); } \
  || { red "Create DATA_ENTRY user FAILED: $resp_de"; ((FAIL++)); }

resp_m=$(do_post_body "$ADMIN_TOKEN" "$BASE/auth/users" \
  "{\"username\":\"$MENTOR_USER\",\"password\":\"Test@1234\",\"full_name\":\"MN $TSTAMP\",\"role\":\"MENTOR\"}")
USER_ID_MENTOR=$(echo "$resp_m" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('user_id',''))" 2>/dev/null)
[ -n "$USER_ID_MENTOR" ] && { green "Created MENTOR user (id=$USER_ID_MENTOR)"; ((PASS++)); } \
  || { red "Create MENTOR user FAILED: $resp_m"; ((FAIL++)); }

resp_sl=$(do_post_body "$ADMIN_TOKEN" "$BASE/auth/users" \
  "{\"username\":\"$SL_USER\",\"password\":\"Test@1234\",\"full_name\":\"SL $TSTAMP\",\"role\":\"SPIRITUAL_LEADER\"}")
USER_ID_SL=$(echo "$resp_sl" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('user_id',''))" 2>/dev/null)
[ -n "$USER_ID_SL" ] && { green "Created SPIRITUAL_LEADER user"; ((PASS++)); } \
  || { red "Create SPIRITUAL_LEADER user FAILED: $resp_sl"; ((FAIL++)); }

resp=$(curl -s -X POST -H "Content-Type: application/json" \
  -d "{\"username\":\"$DE_USER\",\"password\":\"Test@1234\"}" "$BASE/auth/login")
DE_TOKEN=$(echo "$resp" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('token',''))" 2>/dev/null)
[ -n "$DE_TOKEN" ] && { green "DATA_ENTRY login OK"; ((PASS++)); } || { red "DATA_ENTRY login FAILED"; ((FAIL++)); }

resp=$(curl -s -X POST -H "Content-Type: application/json" \
  -d "{\"username\":\"$MENTOR_USER\",\"password\":\"Test@1234\"}" "$BASE/auth/login")
MENTOR_TOKEN=$(echo "$resp" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('token',''))" 2>/dev/null)
[ -n "$MENTOR_TOKEN" ] && { green "MENTOR login OK"; ((PASS++)); } || { red "MENTOR login FAILED"; ((FAIL++)); }

resp=$(curl -s -X POST -H "Content-Type: application/json" \
  -d "{\"username\":\"$SL_USER\",\"password\":\"Test@1234\"}" "$BASE/auth/login")
SL_TOKEN=$(echo "$resp" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('token',''))" 2>/dev/null)
[ -n "$SL_TOKEN" ] && { green "SL login OK"; ((PASS++)); } || { red "SL login FAILED"; ((FAIL++)); }

# ─── Registration Workflow ───────────────────────────────────────────────────
echo ""
echo "── [4] Registration Workflow (DATA_ENTRY → Admin approve/deny)"

# Kid 1: age ~18 (DOB 2008-03-15, year 2026)
KID1_PAYLOAD="{\"kid\":{\"first_name\":\"John\",\"last_name\":\"Test\",\"dob\":\"2008-03-15\",\"gender\":\"Male\",\"education_level\":\"Higher Secondary (11-12)\",\"phone\":\"${PHONE1}\"},\"parents\":[],\"hobby_ids\":[],\"interest_ids\":[]}"
resp=$(do_post_body "$DE_TOKEN" "$BASE/kids" "$KID1_PAYLOAD")
KID_ID=$(echo "$resp" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('kid_id',''))" 2>/dev/null)
[ -n "$KID_ID" ] && { green "Create kid (DRAFT) — kid_id=$KID_ID"; ((PASS++)); } \
  || { red "Create kid FAILED: $resp"; ((FAIL++)); }

if [ -n "$KID_ID" ]; then
  code=$(do_post "$DE_TOKEN" "$BASE/kids/$KID_ID/submit")
  assert_ok "Submit kid for approval" "$code"
else
  red "Submit kid for approval (skipped — no kid_id)"; ((FAIL++))
fi

code=$(do_get "$ADMIN_TOKEN" "$BASE/kids/pending-submissions")
assert_ok "GET /kids/pending-submissions (admin)" "$code"

if [ -n "$KID_ID" ]; then
  code=$(do_post "$ADMIN_TOKEN" "$BASE/kids/$KID_ID/approve-submission")
  assert_ok "Admin approve kid" "$code"

  body=$(do_get_body "$ADMIN_TOKEN" "$BASE/kids/$KID_ID")
  status=$(echo "$body" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('submission_status',''))" 2>/dev/null)
  [ "$status" == "APPROVED" ] && { green "Kid status is APPROVED"; ((PASS++)); } \
    || { red "Kid status should be APPROVED, got: '$status'"; ((FAIL++)); }
else
  red "Admin approve kid (skipped)"; ((FAIL++))
  red "Kid status check (skipped)"; ((FAIL++))
fi

# Kid 2: deny workflow
KID2_PAYLOAD="{\"kid\":{\"first_name\":\"Jane\",\"last_name\":\"Deny\",\"dob\":\"2007-06-10\",\"gender\":\"Female\",\"education_level\":\"Degree/Diploma\",\"phone\":\"${PHONE2}\"},\"parents\":[],\"hobby_ids\":[],\"interest_ids\":[]}"
resp2=$(do_post_body "$DE_TOKEN" "$BASE/kids" "$KID2_PAYLOAD")
KID_ID2=$(echo "$resp2" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('kid_id',''))" 2>/dev/null)
[ -n "$KID_ID2" ] && { green "Create 2nd kid for deny test — kid_id=$KID_ID2"; ((PASS++)); } \
  || { red "Create 2nd kid FAILED: $resp2"; ((FAIL++)); }

if [ -n "$KID_ID2" ]; then
  code=$(do_post "$DE_TOKEN" "$BASE/kids/$KID_ID2/submit")
  assert_ok "Submit 2nd kid for approval" "$code"

  code=$(do_post "$ADMIN_TOKEN" "$BASE/kids/$KID_ID2/deny-submission" \
    '{"note":"Missing parent details - test denial"}')
  assert_ok "Admin deny 2nd kid" "$code"
else
  red "Submit 2nd kid (skipped)"; ((FAIL++))
  red "Admin deny 2nd kid (skipped)"; ((FAIL++))
fi

# ─── User Management Workflow ─────────────────────────────────────────────────
echo ""
echo "── [5] User Management (deactivate / delete / restore)"

code=$(do_get "$ADMIN_TOKEN" "$BASE/auth/users")
assert_ok "GET /auth/users (active)" "$code"

if [ -n "$USER_ID_DE" ]; then
  code=$(do_put "$ADMIN_TOKEN" "$BASE/auth/users/$USER_ID_DE/toggle")
  assert_ok "Deactivate DATA_ENTRY user" "$code"

  code=$(do_del "$ADMIN_TOKEN" "$BASE/auth/users/$USER_ID_DE")
  assert_ok "Soft-delete deactivated user" "$code"

  body=$(do_get_body "$ADMIN_TOKEN" "$BASE/auth/users/deleted")
  found=$(echo "$body" | python3 -c "
import sys, json
try:
  users = json.load(sys.stdin)
  uid = '$USER_ID_DE'
  print(any(str(u.get('user_id','')) == uid for u in users))
except Exception as e:
  print('Error:' + str(e))
" 2>/dev/null)
  [ "$found" == "True" ] && { green "Deleted user appears in /auth/users/deleted"; ((PASS++)); } \
    || { red "Deleted user NOT found in deleted list (found=$found)"; ((FAIL++)); }

  yellow "Admin self-delete protection (skipped — requires second admin)"
  ((SKIP++))

  code=$(do_put "$ADMIN_TOKEN" "$BASE/auth/users/$USER_ID_DE/restore")
  assert_ok "Restore soft-deleted user" "$code"

  body=$(do_get_body "$ADMIN_TOKEN" "$BASE/auth/users/deleted")
  found=$(echo "$body" | python3 -c "
import sys, json
try:
  users = json.load(sys.stdin)
  uid = '$USER_ID_DE'
  print(any(str(u.get('user_id','')) == uid for u in users))
except Exception as e:
  print('Error:' + str(e))
" 2>/dev/null)
  [ "$found" == "False" ] && { green "Restored user no longer in deleted list"; ((PASS++)); } \
    || { red "Restored user still in deleted list!"; ((FAIL++)); }
else
  red "User management tests skipped — USER_ID_DE not set"; ((FAIL++))
fi

# ─── Mentor Assignment ────────────────────────────────────────────────────────
echo ""
echo "── [6] Mentor Assignment"

if [ -n "$KID_ID" ] && [ -n "$USER_ID_MENTOR" ]; then
  ASSIGN_PAYLOAD="{\"kid_id\":\"$KID_ID\",\"mentor_id\":\"$USER_ID_MENTOR\"}"
  code=$(do_post "$ADMIN_TOKEN" "$BASE/mentors/assign" "$ASSIGN_PAYLOAD")
  assert_ok "Assign mentor to approved kid" "$code"
else
  red "Assign mentor (skipped — KID_ID or USER_ID_MENTOR missing)"; ((FAIL++))
fi

code=$(do_get "$ADMIN_TOKEN" "$BASE/mentors/list")
assert_ok "GET /mentors/list" "$code"

# ─── Age-Out Endpoints ─────────────────────────────────────────────────────────
echo ""
echo "── [7] Age-Out endpoints"

code=$(do_get "$ADMIN_TOKEN" "$BASE/ageout/approaching")
assert_ok "GET /ageout/approaching (admin)" "$code"

code=$(do_get "$ADMIN_TOKEN" "$BASE/ageout/archived")
assert_ok "GET /ageout/archived (admin)" "$code"

code=$(do_get "$ADMIN_TOKEN" "$BASE/ageout/requests")
assert_ok "GET /ageout/requests (admin)" "$code"

code=$(do_get "$ADMIN_TOKEN" "$BASE/ageout/notifications")
assert_ok "GET /ageout/notifications" "$code"

code=$(do_get "$ADMIN_TOKEN" "$BASE/ageout/notifications/count")
assert_ok "GET /ageout/notifications/count" "$code"

code=$(do_post "$ADMIN_TOKEN" "$BASE/ageout/run-check")
assert_ok "POST /ageout/run-check" "$code"

# ─── Analytics ────────────────────────────────────────────────────────────────
echo ""
echo "── [8] Analytics"

code=$(do_get "$ADMIN_TOKEN" "$BASE/analytics/hobbies")
assert_ok "GET /analytics/hobbies" "$code"

code=$(do_get "$ADMIN_TOKEN" "$BASE/analytics/interests")
assert_ok "GET /analytics/interests" "$code"

# ─── Search ───────────────────────────────────────────────────────────────────
echo ""
echo "── [9] Search"

code=$(do_get "$ADMIN_TOKEN" "$BASE/kids?page=1")
assert_ok "GET /kids?page=1" "$code"

code=$(do_get "$ADMIN_TOKEN" "$BASE/kids/search?q=John")
assert_ok "GET /kids/search?q=John" "$code"

# ─── Role access control ─────────────────────────────────────────────────────
echo ""
echo "── [10] Role-based access control"

code=$(do_get "$DE_TOKEN" "$BASE/auth/users")
assert_status "DATA_ENTRY cannot GET /auth/users (expects 403)" 403 "$code"

code=$(do_get "$MENTOR_TOKEN" "$BASE/mentors/my-kids")
assert_ok "MENTOR can GET /mentors/my-kids" "$code"

code=$(do_get "$SL_TOKEN" "$BASE/auth/users")
assert_status "SL cannot GET /auth/users (expects 403)" 403 "$code"

code=$(do_get "" "$BASE/kids")
assert_status "Unauthenticated request returns 401" 401 "$code"

# ─── DOB age validation backend (15-21 years) ────────────────────────────────
echo ""
echo "── [11] DOB age validation backend (15-21 years)"

code=$(do_post "$ADMIN_TOKEN" "$BASE/kids" \
  '{"kid":{"first_name":"TooYoung","dob":"2025-01-01","gender":"Male","education_level":"Primary (1-5)","phone":"9000000001"},"parents":[],"hobby_ids":[],"interest_ids":[]}')
assert_status "Create kid with age < 15 returns 400" 400 "$code"

code=$(do_post "$ADMIN_TOKEN" "$BASE/kids" \
  '{"kid":{"first_name":"TooOld","dob":"2000-01-01","gender":"Male","education_level":"Degree/Diploma","phone":"9000000002"},"parents":[],"hobby_ids":[],"interest_ids":[]}')
assert_status "Create kid with age > 21 returns 400" 400 "$code"

code=$(do_post "$ADMIN_TOKEN" "$BASE/kids" \
  "{\"kid\":{\"first_name\":\"ValidAge\",\"dob\":\"2008-01-15\",\"gender\":\"Male\",\"education_level\":\"Higher Secondary (11-12)\",\"phone\":\"${PHONE3}\"},\"parents\":[],\"hobby_ids\":[],\"interest_ids\":[]}")
assert_ok "Create kid with valid age 18 succeeds" "$code"

# ─── Summary ─────────────────────────────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════════════════"
echo "  Results: ✅ $PASS passed  |  ❌ $FAIL failed  |  ⚠️  $SKIP skipped"
echo "═══════════════════════════════════════════════════════"
echo ""
[ "$FAIL" -eq 0 ] && echo "🎉 All tests passed!" || echo "⚠️  Some tests failed — check output above."
exit $FAIL
