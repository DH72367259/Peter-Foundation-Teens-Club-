import { Router, Response } from 'express';
import db from '../database/db';
import { authenticate, requireAdmin, AuthRequest } from '../middleware/auth';
import { newUUID } from '../utils/helpers';

const router = Router();
router.use(authenticate);

// ─── Date helpers ─────────────────────────────────────────────────────────────

/** ISO YYYY-MM-DD for today */
function today(): string {
  return new Date().toISOString().slice(0, 10);
}

/** The teen's 22nd birthday as ISO date string */
function calc22ndBirthday(dob: string): string {
  const d = new Date(dob);
  d.setFullYear(d.getFullYear() + 22);
  return d.toISOString().slice(0, 10);
}

/** Max allowed extension date = 22nd birthday + 3 calendar months */
function maxExtensionDate(dob: string): string {
  const d = new Date(dob);
  d.setFullYear(d.getFullYear() + 22);
  d.setMonth(d.getMonth() + 3);
  return d.toISOString().slice(0, 10);
}

/** Calendar days from a (inclusive) to b (exclusive). Negative if b < a. */
function daysBetween(a: string, b: string): number {
  return Math.round((new Date(b).getTime() - new Date(a).getTime()) / 86400000);
}

function validateExpiryDate(expiryDate: string, dob: string): string | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(expiryDate)) {
    return 'A valid extension date is required';
  }
  if (expiryDate < today()) {
    return 'Extension date must be today or later';
  }

  const maxDate = maxExtensionDate(dob);
  if (expiryDate > maxDate) {
    return `Extension cannot extend beyond ${maxDate} (3 months after 22nd birthday)`;
  }

  return null;
}

// ─── Notification helpers ─────────────────────────────────────────────────────

function insertNotif(
  kid_id: string,
  notification_type: string,
  target_user_id: string,
  message: string
) {
  db.prepare(`
    INSERT INTO age_out_notifications
      (notification_id, kid_id, notification_type, target_user_id, message)
    VALUES (?, ?, ?, ?, ?)
  `).run(newUUID(), kid_id, notification_type, target_user_id, message);
}

function notifyAdmins(kid_id: string, type: string, message: string) {
  const admins = db.prepare(
    "SELECT user_id FROM users WHERE role='ADMIN' AND is_active=1"
  ).all() as any[];
  admins.forEach((a: any) => insertNotif(kid_id, type, a.user_id, message));
}

function notifyMentor(kid_id: string, type: string, message: string) {
  const row = db.prepare('SELECT mentor_id FROM kid_mentor WHERE kid_id=?').get(kid_id) as any;
  if (row) insertNotif(kid_id, type, row.mentor_id, message);
}

// ─── Daily age-out check (exported for server.ts scheduler) ──────────────────

export function runAgeOutCheck(): void {
  try {
    const now = today();

    const teens = db.prepare(`
      SELECT kid_id, first_name, last_name, dob,
             is_archived, is_permanently_archived,
             age_out_notified_at, extension_count,
             extension_expires_at, expiry_warning_sent
      FROM kids
      WHERE is_deleted=0
        AND is_permanently_archived=0
        AND dob IS NOT NULL
        AND submission_status='APPROVED'
    `).all() as any[];

    for (const teen of teens) {
      const bday22     = calc22ndBirthday(teen.dob);
      const daysTo22   = daysBetween(now, bday22);
      const fullName   = `${teen.first_name} ${teen.last_name || ''}`.trim();

      // ── Active teen with a running extension ─────────────────────────────────
      if (!teen.is_archived && teen.extension_expires_at) {
        const daysToExpiry = daysBetween(now, teen.extension_expires_at);

        if (daysToExpiry <= 0) {
          // Extension expired
          if (teen.extension_count >= 2) {
            db.prepare(`
              UPDATE kids
              SET is_archived=1, is_permanently_archived=1,
                  archived_at=?, archive_reason='EXTENSION_EXPIRED_PERMANENTLY'
              WHERE kid_id=?
            `).run(now, teen.kid_id);
            const msg = `${fullName}'s 2nd extension has expired. They are now permanently archived.`;
            notifyAdmins(teen.kid_id, 'PERMANENTLY_ARCHIVED', msg);
            notifyMentor(teen.kid_id, 'PERMANENTLY_ARCHIVED', msg);
          } else {
            db.prepare(`
              UPDATE kids
              SET is_archived=1, archived_at=?, archive_reason='EXTENSION_EXPIRED'
              WHERE kid_id=?
            `).run(now, teen.kid_id);
            const msg = `${fullName}'s age-out extension has expired and they have been archived. Admin can reactivate if needed.`;
            notifyAdmins(teen.kid_id, 'ARCHIVED', msg);
            notifyMentor(teen.kid_id, 'ARCHIVED', msg);
          }
          continue;
        }

        // 2-week expiry warning (sent once)
        if (daysToExpiry <= 14 && !teen.expiry_warning_sent) {
          db.prepare('UPDATE kids SET expiry_warning_sent=1 WHERE kid_id=?').run(teen.kid_id);
          const msg = `${fullName}'s age-out extension expires in ${daysToExpiry} day(s) on ${teen.extension_expires_at}. A further extension must be requested and approved before then.`;
          notifyAdmins(teen.kid_id, 'EXPIRY_WARNING', msg);
          notifyMentor(teen.kid_id, 'EXPIRY_WARNING', msg);
        }
        continue; // skip 22nd-birthday logic while extended
      }

      // ── Active teen, no extension ─────────────────────────────────────────────
      if (!teen.is_archived) {
        if (daysTo22 <= 0) {
          // 22nd birthday passed with no extension — archive
          db.prepare(`
            UPDATE kids
            SET is_archived=1, archived_at=?, archive_reason='AGE_OUT'
            WHERE kid_id=?
          `).run(now, teen.kid_id);
          const msg = `${fullName} has turned 22 and has been automatically archived.`;
          notifyAdmins(teen.kid_id, 'ARCHIVED', msg);
          notifyMentor(teen.kid_id, 'ARCHIVED', msg);
        } else if (daysTo22 <= 30 && !teen.age_out_notified_at) {
          // Approaching 22 notification (sent once)
          db.prepare('UPDATE kids SET age_out_notified_at=? WHERE kid_id=?').run(now, teen.kid_id);
          const msg = `${fullName} will turn 22 in ${daysTo22} day(s) (${bday22}). They will be automatically archived unless a mentor requests an extension and admin approves.`;
          notifyAdmins(teen.kid_id, 'APPROACHING_22', msg);
          notifyMentor(teen.kid_id, 'APPROACHING_22', msg);
        }
      }
    }
    console.log(`[AgeOut] Daily check complete — ${teens.length} teen(s) evaluated.`);
  } catch (e: any) {
    console.error('[AgeOut] Check failed:', e.message);
  }
}

// ─── GET /api/ageout/notifications/count ─────────────────────────────────────
router.get('/notifications/count', (req: AuthRequest, res: Response) => {
  const uid = req.user!.user_id;
  const row = db.prepare(`
    SELECT COUNT(*) as count FROM age_out_notifications
    WHERE target_user_id=? AND is_read=0
  `).get(uid) as any;
  res.json({ count: row.count });
});

// ─── GET /api/ageout/notifications ───────────────────────────────────────────
router.get('/notifications', (req: AuthRequest, res: Response) => {
  const uid = req.user!.user_id;
  const rows = db.prepare(`
    SELECT n.*, k.first_name, k.last_name
    FROM age_out_notifications n
    LEFT JOIN kids k ON k.kid_id = n.kid_id
    WHERE n.target_user_id=?
    ORDER BY n.created_at DESC
    LIMIT 100
  `).all(uid) as any[];
  res.json(rows);
});

// ─── PUT /api/ageout/notifications/:id/read ──────────────────────────────────
router.put('/notifications/:id/read', (req: AuthRequest, res: Response) => {
  const uid = req.user!.user_id;
  db.prepare(
    'UPDATE age_out_notifications SET is_read=1 WHERE notification_id=? AND target_user_id=?'
  ).run(req.params.id, uid);
  res.json({ ok: true });
});

// ─── PUT /api/ageout/notifications/read-all ──────────────────────────────────
router.put('/notifications/read-all', (req: AuthRequest, res: Response) => {
  const uid = req.user!.user_id;
  db.prepare(
    'UPDATE age_out_notifications SET is_read=1 WHERE target_user_id=?'
  ).run(uid);
  res.json({ ok: true });
});

// ─── GET /api/ageout/approaching ─────────────────────────────────────────────
// Admin/Mentor: only non-extended teens approaching 22 + archived reactivatable teens.
router.get('/approaching', (req: AuthRequest, res: Response) => {
  const role = req.user!.role;
  const uid  = req.user!.user_id;

  let teens: any[];

  if (role === 'ADMIN') {
    teens = db.prepare(`
      SELECT k.kid_id, k.first_name, k.last_name, k.dob,
             k.is_archived, k.is_permanently_archived,
             k.extension_count, k.extension_expires_at,
             k.age_out_notified_at,
             u.full_name as mentor_name,
             DATE(k.dob, '+22 years') as birthday_22,
             CAST(julianday(DATE(k.dob, '+22 years')) - julianday(DATE('now')) AS INTEGER) as days_to_22
      FROM kids k
      LEFT JOIN kid_mentor km ON km.kid_id = k.kid_id
      LEFT JOIN users u       ON u.user_id = km.mentor_id
      WHERE k.is_deleted=0
        AND k.is_permanently_archived=0
        AND k.submission_status='APPROVED'
        AND k.dob IS NOT NULL
        AND (
          -- approaching within 30 days
          (k.is_archived=0 AND k.extension_expires_at IS NULL
            AND CAST(julianday(DATE(k.dob, '+22 years')) - julianday(DATE('now')) AS INTEGER) BETWEEN -1 AND 30)
          OR
          -- already archived but can be reactivated
          (k.is_archived=1 AND k.extension_count < 2)
        )
      ORDER BY days_to_22 ASC
    `).all() as any[];
  } else if (role === 'MENTOR') {
    teens = db.prepare(`
      SELECT k.kid_id, k.first_name, k.last_name, k.dob,
             k.is_archived, k.is_permanently_archived,
             k.extension_count, k.extension_expires_at,
             k.age_out_notified_at,
             DATE(k.dob, '+22 years') as birthday_22,
             CAST(julianday(DATE(k.dob, '+22 years')) - julianday(DATE('now')) AS INTEGER) as days_to_22
      FROM kids k
      JOIN kid_mentor km ON km.kid_id = k.kid_id AND km.mentor_id = ?
      WHERE k.is_deleted=0
        AND k.is_permanently_archived=0
        AND k.submission_status='APPROVED'
        AND k.dob IS NOT NULL
        AND (
          (k.is_archived=0 AND k.extension_expires_at IS NULL
            AND CAST(julianday(DATE(k.dob, '+22 years')) - julianday(DATE('now')) AS INTEGER) BETWEEN -1 AND 30)
          OR
          (k.is_archived=1 AND k.extension_count < 2)
        )
      ORDER BY days_to_22 ASC
    `).all(uid) as any[];
  } else {
    res.status(403).json({ error: 'Not authorised' }); return;
  }

  // Attach pending request status for each teen
  const result = teens.map((t: any) => {
    const pendingReq = db.prepare(
      "SELECT * FROM age_out_requests WHERE kid_id=? AND status='PENDING' ORDER BY created_at DESC LIMIT 1"
    ).get(t.kid_id) as any;
    return { ...t, pending_request: pendingReq || null };
  });

  res.json(result);
});

// ─── GET /api/ageout/extensions/completed ────────────────────────────────────
// Admin: all active teens currently under an approved extension.
// Mentor: only their assigned active teens currently under an approved extension.
router.get('/extensions/completed', (req: AuthRequest, res: Response) => {
  const role = req.user!.role;
  const uid = req.user!.user_id;

  let rows: any[] = [];
  if (role === 'ADMIN') {
    rows = db.prepare(`
      SELECT k.kid_id, k.first_name, k.last_name, k.dob,
             k.extension_count, k.extension_expires_at,
             DATE(k.dob, '+22 years') as birthday_22,
             u.full_name as mentor_name,
             CAST(julianday(k.extension_expires_at) - julianday(DATE('now')) AS INTEGER) as days_to_extension_expiry
      FROM kids k
      LEFT JOIN kid_mentor km ON km.kid_id = k.kid_id
      LEFT JOIN users u ON u.user_id = km.mentor_id
      WHERE k.is_deleted=0
        AND k.submission_status='APPROVED'
        AND k.is_archived=0
        AND k.extension_expires_at IS NOT NULL
      ORDER BY k.extension_expires_at ASC
    `).all() as any[];
  } else if (role === 'MENTOR') {
    rows = db.prepare(`
      SELECT k.kid_id, k.first_name, k.last_name, k.dob,
             k.extension_count, k.extension_expires_at,
             DATE(k.dob, '+22 years') as birthday_22,
             CAST(julianday(k.extension_expires_at) - julianday(DATE('now')) AS INTEGER) as days_to_extension_expiry
      FROM kids k
      JOIN kid_mentor km ON km.kid_id = k.kid_id AND km.mentor_id = ?
      WHERE k.is_deleted=0
        AND k.submission_status='APPROVED'
        AND k.is_archived=0
        AND k.extension_expires_at IS NOT NULL
      ORDER BY k.extension_expires_at ASC
    `).all(uid) as any[];
  } else {
    res.status(403).json({ error: 'Not authorised' }); return;
  }

  res.json(rows);
});

// ─── GET /api/ageout/archived ─────────────────────────────────────────────────
router.get('/archived', requireAdmin, (_req: AuthRequest, res: Response) => {
  const teens = db.prepare(`
    SELECT k.kid_id, k.registration_id, k.first_name, k.last_name, k.dob,
           k.is_archived, k.is_permanently_archived,
           k.archived_at, k.archive_reason,
           k.extension_count, k.extension_expires_at,
           u.full_name as mentor_name,
           DATE(k.dob, '+22 years') as birthday_22
    FROM kids k
    LEFT JOIN kid_mentor km ON km.kid_id = k.kid_id
    LEFT JOIN users u       ON u.user_id = km.mentor_id
    WHERE k.is_deleted=0 AND k.is_archived=1
    ORDER BY k.archived_at DESC
  `).all() as any[];
  res.json(teens);
});

// ─── GET /api/ageout/requests ─────────────────────────────────────────────────
router.get('/requests', requireAdmin, (_req: AuthRequest, res: Response) => {
  const requests = db.prepare(`
    SELECT r.*,
           k.first_name, k.last_name, k.dob,
           DATE(k.dob, '+22 years') as birthday_22,
           u.full_name as requested_by_name
    FROM age_out_requests r
    JOIN kids  k ON k.kid_id = r.kid_id
    JOIN users u ON u.user_id = r.requested_by
    WHERE NOT (r.status='DENIED' AND r.admin_note='Resolved by direct admin extension')
    ORDER BY r.created_at DESC
  `).all() as any[];
  res.json(requests);
});

// ─── GET /api/ageout/my-requests ─────────────────────────────────────────────
// Mentor: all extension requests they created, split by status in UI.
router.get('/my-requests', (req: AuthRequest, res: Response) => {
  if (req.user!.role !== 'MENTOR') {
    res.status(403).json({ error: 'Mentor access required' }); return;
  }

  const rows = db.prepare(`
    SELECT r.*,
           k.first_name, k.last_name, k.dob,
           DATE(k.dob, '+22 years') as birthday_22,
           k.extension_count, k.extension_expires_at
    FROM age_out_requests r
    JOIN kids k ON k.kid_id = r.kid_id
    WHERE r.requested_by=?
    ORDER BY r.created_at DESC
  `).all(req.user!.user_id) as any[];

  res.json(rows);
});

// ─── POST /api/ageout/:kidId/request-extension ───────────────────────────────
// Mentor (or admin) requests an extension for a teen
router.post('/:kidId/request-extension', (req: AuthRequest, res: Response) => {
  const role = req.user!.role;
  if (role !== 'MENTOR' && role !== 'ADMIN') {
    res.status(403).json({ error: 'Only mentors (or admin) can request extensions' }); return;
  }

  const { kidId } = req.params;
  const { requested_expiry_date } = req.body;

  if (!requested_expiry_date) {
    res.status(400).json({ error: 'requested_expiry_date is required' }); return;
  }

  const kid = db.prepare(
    'SELECT kid_id, first_name, last_name, dob, is_archived, is_permanently_archived, extension_count, extension_expires_at FROM kids WHERE kid_id=? AND is_deleted=0'
  ).get(kidId) as any;
  if (!kid) { res.status(404).json({ error: 'Teen not found' }); return; }

  // Mentor must be assigned to this kid
  if (role === 'MENTOR') {
    const assigned = db.prepare('SELECT 1 FROM kid_mentor WHERE kid_id=? AND mentor_id=?').get(kidId, req.user!.user_id);
    if (!assigned) { res.status(403).json({ error: 'You are not assigned to this teen' }); return; }
  }

  if (kid.is_permanently_archived) {
    res.status(400).json({ error: 'This teen is permanently archived and cannot receive extensions' }); return;
  }
  if (kid.extension_count >= 2) {
    res.status(400).json({ error: 'Maximum 2 extensions allowed per teen' }); return;
  }

  const now = today();
  if (!kid.is_archived && kid.extension_expires_at) {
    const daysToExpiry = daysBetween(now, kid.extension_expires_at);
    if (daysToExpiry > 7) {
      res.status(400).json({ error: `A new extension request is allowed only within 7 days of expiry (${kid.extension_expires_at})` }); return;
    }
  }

  const dateError = validateExpiryDate(requested_expiry_date, kid.dob);
  if (dateError) {
    res.status(400).json({ error: dateError }); return;
  }

  // Only one pending request at a time
  const existing = db.prepare(
    "SELECT 1 FROM age_out_requests WHERE kid_id=? AND status='PENDING'"
  ).get(kidId);
  if (existing) {
    res.status(409).json({ error: 'A pending extension request already exists for this teen' }); return;
  }

  const requestId = newUUID();
  db.prepare(`
    INSERT INTO age_out_requests
      (request_id, kid_id, requested_by, requested_expiry_date, status)
    VALUES (?, ?, ?, ?, 'PENDING')
  `).run(requestId, kidId, req.user!.user_id, requested_expiry_date);

  // Notify admins
  const fullName = `${kid.first_name} ${kid.last_name || ''}`.trim();
  const msg = `${req.user!.full_name} has requested an age-out extension for ${fullName} until ${requested_expiry_date}.`;
  notifyAdmins(kidId, 'EXTENSION_REQUESTED', msg);

  res.status(201).json({ ok: true, request_id: requestId });
});

// ─── PUT /api/ageout/requests/:requestId/approve ─────────────────────────────
router.put('/requests/:requestId/approve', requireAdmin, (req: AuthRequest, res: Response) => {
  const { requestId } = req.params;
  const { approved_expiry_date, admin_note } = req.body;

  if (!approved_expiry_date) {
    res.status(400).json({ error: 'approved_expiry_date is required' }); return;
  }

  const request = db.prepare(
    "SELECT * FROM age_out_requests WHERE request_id=? AND status='PENDING'"
  ).get(requestId) as any;
  if (!request) { res.status(404).json({ error: 'Pending request not found' }); return; }

  const kid = db.prepare(
    'SELECT kid_id, first_name, last_name, dob, extension_count, is_permanently_archived FROM kids WHERE kid_id=?'
  ).get(request.kid_id) as any;
  if (!kid) { res.status(404).json({ error: 'Teen not found' }); return; }

  if (kid.is_permanently_archived || kid.extension_count >= 2) {
    res.status(400).json({ error: 'This teen cannot receive any further extensions' }); return;
  }

  const dateError = validateExpiryDate(approved_expiry_date, kid.dob);
  if (dateError) {
    res.status(400).json({ error: dateError }); return;
  }

  const now = today();
  db.transaction(() => {
    // Approve the request
    db.prepare(`
      UPDATE age_out_requests
      SET status='APPROVED', approved_expiry_date=?, admin_note=?, reviewed_by=?, reviewed_at=?
      WHERE request_id=?
    `).run(approved_expiry_date, admin_note || null, req.user!.user_id, now, requestId);

    // Deny all other pending requests for this kid
    db.prepare(`
      UPDATE age_out_requests SET status='DENIED', reviewed_by=?, reviewed_at=?
      WHERE kid_id=? AND status='PENDING' AND request_id != ?
    `).run(req.user!.user_id, now, request.kid_id, requestId);

    // Activate extension on kid
    const newExtensionCount = (kid.extension_count || 0) + 1;
    db.prepare(`
      UPDATE kids
      SET is_archived=0, archived_at=NULL, archive_reason=NULL,
          extension_count=?, extension_expires_at=?,
          expiry_warning_sent=0
      WHERE kid_id=?
    `).run(newExtensionCount, approved_expiry_date, request.kid_id);

    // Notify mentor
    const fullName = `${kid.first_name} ${kid.last_name || ''}`.trim();
    const msg = `Extension approved for ${fullName} until ${approved_expiry_date}. This is extension ${newExtensionCount} of 2.${admin_note ? ' Note: ' + admin_note : ''}`;
    notifyMentor(request.kid_id, 'EXTENSION_APPROVED', msg);
    notifyAdmins(request.kid_id, 'EXTENSION_APPROVED', `Admin approved an extension for ${fullName} until ${approved_expiry_date} (extension ${newExtensionCount}/2).`);
  })();

  res.json({ ok: true });
});

// ─── PUT /api/ageout/requests/:requestId/deny ────────────────────────────────
router.put('/requests/:requestId/deny', requireAdmin, (req: AuthRequest, res: Response) => {
  const { requestId } = req.params;
  const { admin_note } = req.body;

  const request = db.prepare(
    "SELECT * FROM age_out_requests WHERE request_id=? AND status='PENDING'"
  ).get(requestId) as any;
  if (!request) { res.status(404).json({ error: 'Pending request not found' }); return; }

  const kid = db.prepare('SELECT first_name, last_name FROM kids WHERE kid_id=?').get(request.kid_id) as any;
  const now = today();

  db.prepare(`
    UPDATE age_out_requests
    SET status='DENIED', admin_note=?, reviewed_by=?, reviewed_at=?
    WHERE request_id=?
  `).run(admin_note || null, req.user!.user_id, now, requestId);

  const fullName = `${kid?.first_name || ''} ${kid?.last_name || ''}`.trim();
  const msg = `Your extension request for ${fullName} was denied.${admin_note ? ' Reason: ' + admin_note : ''}`;
  notifyMentor(request.kid_id, 'EXTENSION_DENIED', msg);

  res.json({ ok: true });
});

// ─── PUT /api/ageout/:kidId/extend ───────────────────────────────────────────
// Admin directly extends an active or archived teen without waiting for a request
router.put('/:kidId/extend', requireAdmin, (req: AuthRequest, res: Response) => {
  const { kidId } = req.params;
  const { expiry_date, admin_note } = req.body;

  if (!expiry_date) {
    res.status(400).json({ error: 'expiry_date is required' }); return;
  }

  const kid = db.prepare(
    'SELECT kid_id, first_name, last_name, dob, is_archived, is_permanently_archived, extension_count, extension_expires_at FROM kids WHERE kid_id=? AND is_deleted=0'
  ).get(kidId) as any;
  if (!kid) { res.status(404).json({ error: 'Teen not found' }); return; }

  if (kid.is_permanently_archived) {
    res.status(400).json({ error: 'This teen is permanently archived and cannot be extended' }); return;
  }
  if (kid.extension_count >= 2) {
    res.status(400).json({ error: 'Maximum 2 extensions already used for this teen' }); return;
  }

  const now = today();
  const pendingReq = db.prepare(
    "SELECT request_id FROM age_out_requests WHERE kid_id=? AND status='PENDING' ORDER BY created_at DESC LIMIT 1"
  ).get(kidId) as any;
  if (!kid.is_archived && kid.extension_expires_at) {
    const daysToExpiry = daysBetween(now, kid.extension_expires_at);
    if (daysToExpiry > 7 && !pendingReq) {
      res.status(400).json({ error: `Direct extension is allowed only within 7 days of expiry (${kid.extension_expires_at}) unless a mentor request is pending` }); return;
    }
  }

  const dateError = validateExpiryDate(expiry_date, kid.dob);
  if (dateError) {
    res.status(400).json({ error: dateError }); return;
  }

  const newExtensionCount = (kid.extension_count || 0) + 1;

  db.transaction(() => {
    db.prepare(`
      UPDATE age_out_requests
      SET status='APPROVED', approved_expiry_date=?, admin_note=COALESCE(admin_note, ?), reviewed_by=?, reviewed_at=?
      WHERE kid_id=? AND status='PENDING'
    `).run(expiry_date, admin_note || 'Approved via direct admin extension', req.user!.user_id, now, kidId);

    db.prepare(`
      UPDATE kids
      SET is_archived=0, archived_at=NULL, archive_reason=NULL,
          extension_count=?, extension_expires_at=?,
          expiry_warning_sent=0
      WHERE kid_id=?
    `).run(newExtensionCount, expiry_date, kidId);
  })();

  const fullName = `${kid.first_name} ${kid.last_name || ''}`.trim();
  const action = kid.is_archived ? 'reactivated and extended' : 'extended';
  const mentorMsg = `${fullName} has been ${action} by admin until ${expiry_date}. This is extension ${newExtensionCount} of 2.${admin_note ? ' Note: ' + admin_note : ''}`;
  const adminMsg = `Admin extended ${fullName}'s stay until ${expiry_date} (extension ${newExtensionCount}/2).${admin_note ? ' Note: ' + admin_note : ''}`;
  notifyMentor(kidId, 'STAY_EXTENDED', mentorMsg);
  notifyAdmins(kidId, 'STAY_EXTENDED', adminMsg);

  res.json({ ok: true });
});

// ─── PUT /api/ageout/:kidId/reactivate ───────────────────────────────────────
// Admin manually reactivates an archived teen (counts as an extension)
router.put('/:kidId/reactivate', requireAdmin, (req: AuthRequest, res: Response) => {
  const { kidId } = req.params;
  const { expiry_date, admin_note } = req.body;

  if (!expiry_date) {
    res.status(400).json({ error: 'expiry_date is required' }); return;
  }

  const kid = db.prepare(
    'SELECT kid_id, first_name, last_name, dob, is_archived, is_permanently_archived, extension_count FROM kids WHERE kid_id=? AND is_deleted=0'
  ).get(kidId) as any;
  if (!kid) { res.status(404).json({ error: 'Teen not found' }); return; }

  if (kid.is_permanently_archived) {
    res.status(400).json({ error: 'This teen is permanently archived and cannot be reactivated' }); return;
  }
  if (!kid.is_archived) {
    res.status(400).json({ error: 'This teen is not archived' }); return;
  }
  if (kid.extension_count >= 2) {
    res.status(400).json({ error: 'Maximum 2 extensions already used; teen cannot be reactivated' }); return;
  }

  const dateError = validateExpiryDate(expiry_date, kid.dob);
  if (dateError) {
    res.status(400).json({ error: dateError }); return;
  }

  const newExtensionCount = (kid.extension_count || 0) + 1;
  const now = today();

  db.prepare(`
    UPDATE kids
    SET is_archived=0, archived_at=NULL, archive_reason=NULL,
        extension_count=?, extension_expires_at=?,
        expiry_warning_sent=0
    WHERE kid_id=?
  `).run(newExtensionCount, expiry_date, kidId);

  const fullName = `${kid.first_name} ${kid.last_name || ''}`.trim();
  const msg = `${fullName} has been manually reactivated by admin until ${expiry_date}. Extension ${newExtensionCount} of 2.${admin_note ? ' Note: ' + admin_note : ''}`;
  notifyMentor(kidId, 'REACTIVATED', msg);
  notifyAdmins(kidId, 'REACTIVATED', `Admin reactivated ${fullName} until ${expiry_date} (extension ${newExtensionCount}/2).${admin_note ? ' Note: ' + admin_note : ''}`);

  res.json({ ok: true });
});

// ─── POST /api/ageout/run-check (admin only, for manual trigger) ──────────────
router.post('/run-check', requireAdmin, (_req: AuthRequest, res: Response) => {
  runAgeOutCheck();
  res.json({ ok: true, message: 'Age-out check completed' });
});

export default router;
