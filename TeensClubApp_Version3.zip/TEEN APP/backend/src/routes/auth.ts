import { Router, Response } from 'express';
import bcrypt from 'bcryptjs';
import db from '../database/db';
import { authenticate, requireAdmin, generateToken, AuthRequest } from '../middleware/auth';
import { newUUID } from '../utils/helpers';
import { runBackup, lastBackup, findCloudDir } from '../utils/backup';

const router = Router();

// POST /api/auth/login
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password required' });
  }

  const user = db.prepare(
    "SELECT * FROM users WHERE username = ?"
  ).get(username) as any;

  if (!user) {
    return res.status(401).json({ error: 'Invalid username or password' });
  }

  if (!user.is_active) {
    return res.status(401).json({ error: 'Your account is deactivated. Please contact admin for more details.' });
  }

  if (!bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Invalid username or password' });
  }

  const token = generateToken({
    user_id: user.user_id,
    username: user.username,
    role: user.role,
    full_name: user.full_name,
  });

  return res.json({
    token,
    user: { user_id: user.user_id, username: user.username, role: user.role, full_name: user.full_name }
  });
});

// GET /api/auth/users  — Admin only (active + inactive, excludes soft-deleted)
router.get('/users', authenticate, requireAdmin, (_req: AuthRequest, res: Response) => {
  const users = db.prepare(
    "SELECT user_id, username, full_name, role, is_active, created_at FROM users WHERE is_deleted=0 ORDER BY created_at DESC"
  ).all();
  res.json(users);
});

// GET /api/auth/users/deleted  — Admin only: soft-deleted archive
router.get('/users/deleted', authenticate, requireAdmin, (_req: AuthRequest, res: Response) => {
  const users = db.prepare(
    "SELECT user_id, username, full_name, role, is_active, created_at, deleted_at FROM users WHERE is_deleted=1 ORDER BY deleted_at DESC"
  ).all();
  res.json(users);
});

// POST /api/auth/users  — Admin only: create sub user
router.post('/users', authenticate, requireAdmin, (req: AuthRequest, res: Response) => {
  const { username, password, full_name, role } = req.body;
  if (!username || !password || !full_name) {
    res.status(400).json({ error: 'username, password, full_name required' });
    return;
  }
  const validRoles = ['ADMIN', 'DATA_ENTRY', 'MENTOR', 'SUB', 'SPIRITUAL_LEADER'];
  const allowedRole = validRoles.includes(role) ? role : 'DATA_ENTRY';

  // Unique full_name check
  const nameDup = db.prepare("SELECT 1 FROM users WHERE lower(full_name) = lower(?)").get(full_name);
  if (nameDup) {
    res.status(409).json({ error: 'A user with this full name already exists' }); return;
  }
  const hash = bcrypt.hashSync(password, 10);
  const id = newUUID();
  try {
    db.prepare(`
      INSERT INTO users (user_id, username, password_hash, full_name, role, created_by)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(id, username, hash, full_name, allowedRole, req.user?.user_id);
    res.status(201).json({ message: 'User created', user_id: id });
  } catch (e: any) {
    if (e.message?.includes('UNIQUE')) {
      res.status(409).json({ error: 'Username already exists' });
    } else {
      res.status(500).json({ error: e.message });
    }
  }
});

// PUT /api/auth/users/:id/toggle  — Admin only
router.put('/users/:id/toggle', authenticate, requireAdmin, (req: AuthRequest, res: Response) => {
  const { id } = req.params;
  if (req.user!.user_id === id) {
    res.status(400).json({ error: 'You cannot deactivate your own account' }); return;
  }
  const user = db.prepare("SELECT * FROM users WHERE user_id = ? AND is_deleted=0").get(id) as any;
  if (!user) { res.status(404).json({ error: 'User not found' }); return; }
  db.prepare("UPDATE users SET is_active = ? WHERE user_id = ?").run(user.is_active ? 0 : 1, id);
  res.json({ message: 'Updated', is_active: !user.is_active });
});

// DELETE /api/auth/users/:id  — Admin only: soft-delete (must be deactivated first, cannot self-delete)
router.delete('/users/:id', authenticate, requireAdmin, (req: AuthRequest, res: Response) => {
  const { id } = req.params;
  if (req.user!.user_id === id) {
    res.status(400).json({ error: 'You cannot delete your own account' }); return;
  }
  const user = db.prepare("SELECT * FROM users WHERE user_id = ? AND is_deleted=0").get(id) as any;
  if (!user) { res.status(404).json({ error: 'User not found' }); return; }
  if (user.is_active) {
    res.status(400).json({ error: 'You must deactivate the user before deleting them' }); return;
  }
  db.prepare("UPDATE users SET is_deleted=1, deleted_at=datetime('now') WHERE user_id=?").run(id);
  res.json({ message: 'User moved to deleted archive' });
});

// PUT /api/auth/users/:id/restore  — Admin only: restore a soft-deleted user
router.put('/users/:id/restore', authenticate, requireAdmin, (req: AuthRequest, res: Response) => {
  const { id } = req.params;
  const user = db.prepare("SELECT * FROM users WHERE user_id = ? AND is_deleted=1").get(id) as any;
  if (!user) { res.status(404).json({ error: 'Deleted user not found' }); return; }
  db.prepare("UPDATE users SET is_deleted=0, deleted_at=NULL, is_active=1 WHERE user_id=?").run(id);
  res.json({ message: 'User restored and reactivated' });
});

// PUT /api/auth/users/:id/password  — Admin only
router.put('/users/:id/password', authenticate, requireAdmin, (req: AuthRequest, res: Response) => {
  const { password } = req.body;
  if (!password) { res.status(400).json({ error: 'password required' }); return; }
  const hash = bcrypt.hashSync(password, 10);
  db.prepare("UPDATE users SET password_hash = ? WHERE user_id = ?").run(hash, req.params.id);
  res.json({ message: 'Password updated' });
});

// GET /api/auth/backup/status  — Admin only: last backup info + cloud detection
router.get('/backup/status', authenticate, requireAdmin, (_req, res: Response) => {
  const cloud = findCloudDir();
  res.json({
    lastBackup,
    cloudService:    cloud?.service ?? null,
    cloudConfigured: !!cloud,
    cloudDir:        cloud ? cloud.dir + '/TeensClub Backups' : null,
  });
});

// POST /api/auth/backup  — Admin only: trigger a manual backup immediately
router.post('/backup', authenticate, requireAdmin, async (_req, res: Response) => {
  const result = await runBackup();
  if (result.success) {
    res.json({ message: 'Backup completed successfully', ...result });
  } else {
    res.status(500).json({ error: result.error || 'Backup failed', ...result });
  }
});

export default router;
